
console.log("kbot loaded");

/*

function buildElements(){
  var container = document.createElement('div');
  container.className = "container";
  var entryPoint = document.createElement('div');
  entryPoint.className = "entryPoint";
  var formGroup = document.createElement('div');
  formGroup.className = "form-group";
  var inputGroup = document.createElement('div');
  inputGroup.className = "input-group mb-3";
  var inputField = document.createElement('input');
  inputField.className = "form-control";
  inputField.className = "questionText";
  var inputButton = document.createElement('button');
  inputButton.className = "btn";
  inputButton.id = "submitQuestion";

}

*/





//(() => { dataBrain = new QAData (); })();

var userInput = "";
var container;
var entryPoint;
var formGroup;
var inputGroup;
var inputField;
var submitButton;
var dataBrain;

window.onload = function() {
  dataBrain = new QAData ();
   userInput = "";
   container = document.createElement('div');
  container.className = "container";
   entryPoint = document.createElement('div');
  entryPoint.className = "entryPoint";
   formGroup = document.createElement('div');
  formGroup.className = "form-group";
   inputGroup = document.createElement('div');
  inputGroup.className = "input-group mb-3";
   inputField = document.createElement('input');
  inputField.className = "form-control";
  inputField.className = "questionText";
  //var inputButton = document.createElement('BUTTON');
  //inputButton.className = "btn";
  //inputButton.id = "submitQuestion";
  inputField = document.getElementById('questionText');
  
   submitButton = document.getElementById("submitQuestion");
  entryPoint =  document.getElementById("entryPoint");
  
   dataBrain;
  
  console.log(submitButton);
  
  //event listener on submit question button
  submitButton.addEventListener("click", postQuestion);
  
  
  
  //event listener for keyup on Enter key
  inputField.addEventListener("keyup", function(event) {
   
      if (event.key === "Enter") {
       
        postQuestion();
      }
    });

};


function postQuestion() {
   
    var textLine = document.createElement('div');
    textLine.className = "questionLine";
    
    var triangle = document.createElement('span');
    triangle.className = 'triangle-left fade-in';
    
    var span = document.createElement("span");
    span.className = 'questionSpan fade-in';
    triangle.before(span);
    textLine.appendChild(triangle);

    var textBlurb = document.createElement('div');
    textBlurb.className = 'questionBlurb  p-2';
    textBlurb.innerText = inputField.value;
    
    textLine.appendChild(textBlurb);


    //textLine.insertBefore(triangle, textBlurb);
    
    entryPoint.appendChild(textLine); 

    dataBrain.setQuestion(inputField.value);
    //dataBrain = new QAData (inputField.value);
    //theData =  dataBrain.getQAdata(textLine);
    var theData =  dataBrain.getQAdata();
    
    var strippedQuestion;
    if(theData === ""|| theData === undefined || theData === null){
      
      strippedQuestion  = dataBrain.stripper(inputField.value);
      console.log(strippedQuestion + " stripped question");
      dataBrain.setQuestion(strippedQuestion);
      theData =  dataBrain.getQAdata();
      console.log(theData + " the data");
    }
    //console.log("strippedQuestion");
    //console.log(strippedQuestion);

    //thequestion = new QAData (strippedQuestion);
    //theData =  thequestion.getQAdata();

    inputField.value = "";

    console.log(theData);

    answerQuestion(theData);
}




function answerQuestion(theData){
       
    var textLine = document.createElement('div');
    textLine.className = ".d-flex answerQuestion";
    entryPoint.appendChild(textLine); 

    
    
    var textBlurb = document.createElement('div');
    textBlurb.className = 'answerBlurb d-inline-flex p-2 fade-in';

    if(theData != ""){textBlurb.innerText = theData;}

    if(theData === ""){textBlurb.innerText = "Sorry, I don't know how to answer that.";}
    if(theData === undefined){textBlurb.innerText = "Sorry, I don't know how to answer that.";}
    if(theData === null){textBlurb.innerText = "Sorry, I don't know how to answer that.";}

    
    
    textLine.appendChild(textBlurb); 
    
    var triangle = document.createElement('span');
    triangle.className = 'triangle-right fade-in';
    
    var span = document.createElement("span");
    span.className = 'questionSpan';
    triangle.after(span);
    textLine.appendChild(triangle);
    
}

class QAData{

  constructor(question){
      
      //this.question = question;

      this.data = QAdata;
      
  };
  setQuestion(question){
      this.question = question;
  }
  getQuestion(){
     return this.question;
  }


stripper(phrase){
  console.log("stripper");
  phrase = phrase.toLowerCase();
  phrase = phrase.replace(/[.,\/#!$%\^&\*;:{}=\-_`'~()?]/g,"")
  var x = 1;
  //phrase = phrase + new Array(x + 1).join(' ')
  phrase = ' '.repeat(x) + phrase;
  phrase = phrase + ' '.repeat(x);
  
  console.log(phrase);
  
  phrase = phrase.replace(/ who /g,' ');
  phrase = phrase.replace(/ whos /g,' ');
  phrase = phrase.replace(/ what /g,' ');
  phrase = phrase.replace(/ whats /g,' ');
  phrase = phrase.replace(/ where /g,' ');
  phrase = phrase.replace(/ whers /g,' ');
  phrase = phrase.replace(/ why /g,' ');
  phrase = phrase.replace(/ how /g,' ');
  phrase = phrase.replace(/ hows /g,' ');
  phrase = phrase.replace(/ is /g,' ');
  phrase = phrase.replace(/ the /g,' ');
  phrase = phrase.replace( / a /g ,' ');                                                  
  phrase = phrase.replace(/ your /g,' ');
  phrase = phrase.replace(/ are /g,' ');
  phrase = phrase.replace(/ tell /g,' ');
  phrase = phrase.replace(/ question /g,' ');
  phrase = phrase.replace(/ i /g,' ');
  phrase = phrase.replace(/ that /g,' ');
  phrase = phrase.replace(/ this /g,' ');
  phrase = phrase.replace(/ me /g,' ');
  phrase = phrase.replace(/ does /g,' ');
  phrase = phrase.replace(/ mean /g,' ');
  phrase = phrase.replace(/ means /g,' ');
  phrase = phrase.replace(/ meaning /g,' ');
  phrase = phrase.replace(/ about /g,' ');
  phrase = phrase.replace(/ know /g,' ');
  phrase = phrase.replace(/ happen /g,' ');
  phrase = phrase.replace(/ explain /g,' ');
  phrase = phrase.replace(/ to /g,' ');
  phrase = phrase.replace(/ do /g,' ');
  phrase = phrase.replace(/ could /g,' ');
  phrase = phrase.replace(/ would /g,' ');
  phrase = phrase.replace(/ want /g,' ');
  phrase = phrase.replace(/ need /g,' ');
  phrase = phrase.replace(/ please /g,' ');
  phrase = phrase.replace(/ about /g,' ');
  phrase = phrase.replace(/ can /g,' ');
  phrase = phrase.replace(/ explain /g,' ');
  phrase = phrase.replace(/ describe /g,' ');
  phrase = phrase.replace(/ inform /g,' ');
  phrase = phrase.replace(/ disclose /g,' ');
  phrase = phrase.replace(/ define /g,' ');
  phrase = phrase.replace(/ information /g,' ');
  phrase = phrase.replace(/ for /g,' ');
  phrase = phrase.replace(/ give /g,' ');
  phrase = phrase.replace(/ regarding /g,' ');
  phrase = phrase.replace(/ apprise /g,' ');
  phrase = phrase.replace(/ teach /g,' ');
  phrase = phrase.replace(/ you /g,' ');
  phrase = phrase.replace(/ find /g,' ');
  phrase = phrase.replace(/ search /g,' ');
  phrase = phrase.replace(/ locate /g,' ');
  phrase = phrase.replace(/ location /g,' ');
  

  phrase = phrase.trim();
  
  //phrase = phrase.replace(/^\s+/g, '');
  return phrase;
}



getQAdata(){
var arrayOfObjectAnswers = this.data.arrayOfAnswers
      


var question = this.question;
var answer = null;

arrayOfObjectAnswers.forEach(function (arrayItem) {
  var questionMatch = false; 
  var obj = arrayItem;
  
  //this loops through the keys, when it finds a match it assigns an anser to the next  key value in the object
  for (var key in obj) {
      //console.log(key + " -> " + obj[key]);

          question = question.toLowerCase();
          //stripper(question);

          var keyString = obj[key];
          keyString = keyString.toLowerCase();

          
          
          if(questionMatch === true){
              answer = ((obj[key]));
              //return (obj[key]);
          }
          
      
          if(question === keyString){
              questionMatch = true;
              
          }
      
          
  }


});



return answer; 
  
};

  


}

QAdata = {
  "arrayOfAnswers": [
      {
          "Term:": "phone number",
          "Definition:": "614-277-3663."

      },{
          "Term:": "phone",
          "Definition:": "614-277-3663."

      },
      {
          "Term:": "fax number",
          "Definition:": "First Floor Fax 614-274-8063, Second Floor Fax 614-317-9608"

      },
      {
          "Term:": "fax",
          "Definition:": "First Floor Fax 614-274-8063, Second Floor Fax 614-317-9608"

      },
      {
          "Term:": "check voicemail",
          "Definition:": "Step 1: Press intercom 300 this will take you into the voicemail.  Step 2: It will prompt you to enter your user ID (this is your phone extension).   Step 3: It will ask you to enter your password this is usually also your phone extension but you do have the option to change it by following the instructions.    Step 4: It will say how many messages you have and will start to play automatically."

      },
      {
          "Term:": "check voice mail",
          "Definition:": "Step 1: Press intercom 300 this will take you into the voicemail.  Step 2: It will prompt you to enter your user ID (this is your phone extension).   Step 3: It will ask you to enter your password this is usually also your phone extension but you do have the option to change it by following the instructions.     Step 4: It will say how many messages you have and will start to play automatically."

      },
      {
          "Term:": "forward voicemail",
          "Definition:": "Your message will play as normal. After it is finished if you want to forward the message to another employee do the following steps:      Step 1: Press 5 (ignore prompts)      Step 2: Press 7” then “enter phone ext.” aka user id      Step 3: Prior to having the voicemail forwarded press 2 to leave a message or press 1 not to leave a message (The voicemail system calls it message prefix.)     Step 4: Then you can press 4 to erase message It will either move directly onto the next message or it will state no more messages."

      },{
          "Term:": "forward voice mail",
          "Definition:": "Your message will play as normal. After it is finished if you want to forward the message to another employee do the following steps:     Step 1: Press 5 (ignore prompts)     Step 2: Press 7” then “enter phone ext.” aka user id    Step 3: Prior to having the voicemail forwarded press 2 to leave a message or press 1 not to leave a message (The voicemail system calls it message prefix.)    Step 4: Then you can press 4 to erase message It will either move directly onto the next message or it will state no more messages."

      },
      {
          "Term:": "set up voicemail",
          "Definition:": "Step 1: Press the Intercom button, then type in 300 on the keypad (This will put you into the voicemail system)     Step 2: It will then say type in the password for user id example 401.  This is usually your 3 digit phone extension number.     Step 3: Press 9 Step 4: Press 7 Follow the detailed instructions from there."

      },
      {
          "Term:": "set up voice mail",
          "Definition:": "Step 1: Press the Intercom button, then type in 300 on the keypad (This will put you into the voicemail system)     Step 2: It will then say type in the password for user id example 401.  This is usually your 3 digit phone extension number.     Step 3: Press 9 Step 4: Press 7 Follow the detailed instructions from there."

      },
      {
          "Term:": "community room A",
          "Definition:": "Known as Wolfe Associates Inc. Community Room A, it is located beside the lobby"

      },
      {
          "Term:": "where is community room A",
          "Definition:": "Known as Wolfe Associates Inc. Community Room A, it is located beside the lobby"

      },
      {
          "Term:": "find community room A",
          "Definition:": "Known as Wolfe Associates Inc. Community Room A, it is located beside the lobby"

      },
      {
          "Term:": "community room B",
          "Definition:": "Known as Wolfe Associates Inc. Community Room B, it is located beside the kitchen ont he first floor."

      },
      {
          "Term:": "meeting room A",
          "Definition:": "Known as the Columbus Foundation Conference Room, it is located on the first floor near the elevator."

      },
      {
          "Term:": "meeting room D",
          "Definition:": "Known as the Huntington Meeting Room, it is the large meeting room closest to the front door near the elevator on the first floor."

      },
      {
          "Term:": "Conference room D",
          "Definition:": "Known as the Huntington Meeting Room, it is the large meeting room closest to the front door near the elevator on the first floor."

      },
      {
          "Term:": "meeting room E",
          "Definition:": "Meeting room E is the large meeting room closest to the front door near the elevator on the first floor."

      },
      {
          "Term:": "Conference room E",
          "Definition:": "Meeting room E is the large meeting room closest to the front door near the elevator on the first floor."

      },
      {
          "Term:": "Conference room F",
          "Definition:": "This is the CEO's conference room conected to their office."

      },
      {
          "Term:": "meeting room F",
          "Definition:": "This is the CEO's conference room conected to their office."

      },
      {
          "Term:": "Conference Room G",
          "Definition:": "The conference room near the mailboxes on the second floor in the office area."

      },
      {
          "Term:": "meeting Room G",
          "Definition:": "The conference room near the mailboxes on the second floor in the office area."

      },
              {
                  "Term:": "Advertising",
                  "Definition:": "The act or practice of shifting or influencing behavior through paid announcements in print, digital, outdoor, broadcast, etc."
              },
              {
                  "Term:": "Advocacy",
                  "Definition:": "The act or process of supporting something, typically policy in our line of work. Getting the support of the public."
              },
              {
                  "Term:": "Agency Pick Up",
                  "Definition:": "The area agencies (food pantries) are able to pick up products from Mid-Ohio Foodbank."
              },
              {
                  "Term:": "Agricultural Clearance Program",
                  "Definition:": "Directs surplus agricultural products from more than 100 Ohio farmers, growers, and producers to Ohio’s 12 Feeding America foodbanks."
              },
              {
                  "Term:": "Annual Poundage Report",
                  "Definition:": "Summarizes the Quarterly Poundage Report (QPR) amounts and types of products moved in and out of each Feeding America member warehouse or location during a calendar year."
              },
              {
                  "Term:": "Association of Fundraising Professionals",
                  "Definition:": "Recognized as the premier resource for development and fundraising professionals, providing outstanding educational programs for those seeking professional development and career advancement opportunities."
              },
              
              {
                  "Term:": "Better Business Bureau",
                  "Definition:": "An organization whose mission is to be the leader in advancing marketplace trust by helping people find businesses, brands, and charities they can trust. BBB’s vision is an ethical marketplace where buyers and sellers can trust each other."
              },
              {
                  "Term:": "Bill of Lading",
                  "Definition:": "A detailed list of a shipment of goods in the form of a receipt given by the carrier to the person consigning the goods."
              },
              {
                  "Term:": "Brand",
                  "Definition:": "Brand is who we are + what we do + what we promise = how we want our stakeholders to perceive us."
              },
              {
                  "Term:": "Certified Fund Raising Executive",
                  "Definition:": "A valid and reliable certification process for philanthropic fundraising professionals that have demonstrated recognizable personal and professional achievement and commitment."
              },
              {
                  "Term:": "Charitable Gift Annuity",
                  "Definition:": "A contract between a donor and a charity where a donor makes a sizable gift to charity using cash, securities, or possibly other assets and in return becomes eligible to take a partial tax deduction and receive a fixed stream of income from the charity for the rest of their life."
              },
              {
                  "Term:": "Collaborating for Clients",
                  "Definition:": "(now known as SSTC, but same initiative) The South Side Thrive Collaborative seeks to align community partners around a set of goals, outcomes, and indicators that will ultimately create positive results within the (south side Columbus) community."
              },
              {
                  "Term:": "Columbus Metropolitan Club",
                  "Definition:": "A 501c3 nonprofit that connects people and ideas through community conversation."
              },
              {
                  "Term:": "Communications",
                  "Definition:": "In the simplest terms, communications is about getting information from Person A to Person B. In strategic communications or business communications, we focus on sharing information based on clearly defined outcomes or goals, audiences, channels and exacting language."
              },
              {
                  "Term:": "Internal communications",
                  "Definition:": "Aim at the audience inside an organization. Obviously, therefore, external communications are for audiences outside the organization."
              },
              
              {
                  "Term:": "Community Relations",
                  "Definition:": "Community relations is the relationship an organization has with the people who live within the area they directly serve. This is done by promoting the organization's image in a positive and community-oriented way."
              },
              {
                  "Term:": "Copy Writing",
                  "Definition:": "Copywriters have the ability to think in abstract terms; can make connections between unrelated notions and can formulate innovative ideas. Copywriters are responsible for the text on brochures, billboards, websites, emails, advertisements, catalogs, and more. This text is known as “copy.”"
              },
              {
                  "Term:": "Creative",
                  "Definition:": "Relating to or involving the imagination or original ideas, especially in the production of artistic work. Also used to reference the person responsible for the work, or the final delivered piece."
              },
              {
                  "Term:": "Delivered",
                  "Definition:": "A way to signify that the products have been delivered to the correct agency."
              },
              {
                  "Term:": "Department of Agriculture",
                  "Definition:": "Federal executive department responsible for developing and executing federal laws related to farming, agriculture, forestry, and food. Also known as the United States Department of Agriculture (USDA)."
              },
              {
                  "Term:": "Department of Transportation",
                  "Definition:": "A department of the federal executive branch responsible for the national highways and for railroad and airline safety."
              },
              {
                  "Term:": "Direct Retail Pick Up",
                  "Definition:": "Strategic initiative that allows partner agencies direct access to free, highly nutritious perishables and increases emergency food distribution by partnering with local retailers."
              },
              {
                  "Term:": "Distribution Center",
                  "Definition:": "A warehouse that is stocked with products (food) to be redistributed to retailers, consumers, or in our case, food pantries."
              },
              {
                  "Term:": "Shop Thru",
                  "Definition:": "Produce distribution initiative that allows agencies to acquire fresh produce directly from the Foodbank warehouse."
              },
              {
                  "Term:": "Donor Advised Fund",
                  "Definition:": "A philanthropic vehicle established at a public charity that allows donors to make a charitable contribution, receive an immediate tax benefit, and then recommend grants from the fund over time."
              },
              {
                  "Term:": "Double Your Donation Day",
                  "Definition:": "One-day media supported match event where donors go online or call our phone bank to make donations that will be matched through previously secured gifts."
              },
              {
                  "Term:": "Federal Emergency Management Agency",
                  "Definition:": "A federal agency that coordinates the response to a disaster that has occurred in the United States and that overwhelms the resources of local and state authorities."
              },
              {
                  "Term:": "Food Insecurity Nutrition Incentive",
                  "Definition:": "A grant program that supports projects like South Side Roots to increase the purchase of fruits and vegetables among low-income consumers participating in the Supplemental Nutrition Assistance Program (SNAP) by providing incentives at the point of purchase."
              },
              {
                  "Term:": "Earned Media",
                  "Definition:": "Any publicity you haven’t paid for that’s owned and created by a third party."
              },
              {
                  "Term:": "Electronic Benefits Transfer",
                  "Definition:": "The method by which food stamps and other benefits are distributed via an electronic debit card. Some states also use EBT to distribute benefits under Women, Infants and Children (WIC), and other programs."
              },
              {
                  "Term:": "Electronic Newsletter",
                  "Definition:": "This indicates that the donor prefers email communications."
              },
              {
                  "Term:": "Email Solicitation",
                  "Definition:": "An electronic promotional message sent to a consumer."
              },
              {
                  "Term:": "Emergency Food and Shelter Program",
                  "Definition:": "A federally-funded program administrated by the Federal Emergency Management Agency (FEMA) whose purpose is to supplement and expand the ongoing work of local social service organizations to provide shelter, food, and supportive services to individuals and families who have economic emergencies."
              },
              {
                  "Term:": "External Affairs",
                  "Definition:": "Being able to establish and manage relationships with stakeholders outside of your own organization."
              },
              {
                  "Term:": "Feeding America",
                  "Definition:": "A nationwide network of more than 200 food banks that feed more than 46 million people through food pantries, soup kitchens, shelters, and other community-based agencies. Mid-Ohio Foodbank is a part of Feeding America."
              },
              {
                  "Term:": "Feeding America University",
                  "Definition:": "Online learning system accessed via HungerNet, which offers more than 100 online training courses across four categories."
              },
              {
                  "Term:": "Fiscal Year To Date",
                  "Definition:": "A period starting from the beginning of the current fiscal year and continuing up to the present day."
              },
              {
                  "Term:": "Food Advocacy Network",
                  "Definition:": "A network of individuals working together to achieve Mid-Ohio Foodbank’s goal of impacting public policy decisions and creating positive change by engaging public policy decision-makers and constituents alike in the hunger conversation."
              },
              {
                  "Term:": "Food Assistance Outreach",
                  "Definition:": "A team at Mid-Ohio Foodbank that goes into the community to pre-screen individuals, connect them to resources in the Ohio Benefit Bank, and enroll those eligible for SNAP/food stamps."
              },
              
              {
                  "Term:": "Food Pantry Network of Licking County",
                  "Definition:": "A cooperative associated with Mid-Ohio Foodbank that coordinates the acquisition and distribution of emergency food supplies by working through its member food agencies."
              },
              {
                  "Term:": "Foods to Encourage",
                  "Definition:": "Feeding America’s approach to accurately evaluate and describe the nutritional contributions of the food categories in network foodbanks’ inventories."
              },
              {
                  "Term:": "Freight On Board (or Free On Board)",
                  "Definition:": "A designation that is used to indicate when liability and ownership of goods is transferred from a seller to a buyer."
              },
              {
                  "Term:": "Fresh Food Partner",
                  "Definition:": "A FFP is eligible to pick up produce weekly at MOF. There is no minimum requirement of poundage for this program and is suitable for smaller programs wanting to connect their clients to fresh food."
              },
              {
                  "Term:": "Frozen",
                  "Definition:": "Indicates this product is a frozen good."
              },
              {
                  "Term:": "Full-Cost Recovery program",
                  "Definition:": "Ensuring that all costs involved in running a project are recovered, through securing funding which includes a relevant proportion of organizational costs."
              },
              {
                  "Term:": "Full Truck Load",
                  "Definition:": "Transport of goods that fill up a full truck."
              },
              {
                  "Term:": "Graphic Design",
                  "Definition:": "The art or skill of communicating through text and visual elements in advertisements, magazines, books or digitally."
              },
              {
                  "Term:": "Grassroots",
                  "Definition:": "The common person or general public, as opposed to the grasstops. People at the local or low level, who often will organize the masses to achieve influence and change."
              },
              {
                  "Term:": "Grasstops",
                  "Definition:": "Activists or members of a group that have a high professional or public profile and can influence and raise public awareness about certain issues through their established connections."
              },
              {
                  "Term:": "Holiday Purchase Program",
                  "Definition:": "Program to purchase holiday food products for that time of year."
              },
              {
                  "Term:": "Hunger Action Month",
                  "Definition:": "A national “Skip Lunch to Fight Hunger” campaign held during the month of September. The campaign asks Americans to donate their lunch money to the Feeding America network."
              },
              {
                  "Term:": "In Honor Of",
                  "Definition:": "Indicates the donation/ item has been given in honor of a certain individual or group."
              },
              {
                  "Term:": "In Memory Of",
                  "Definition:": "Indicates the donation/ item has been given in memory of a deceased individual."
              },
              {
                  "Term:": "Information Technology",
                  "Definition:": "Use of computers to store, retrieve, transmit and manipulate data or information."
              },
              {
                  "Term:": "Integrated Response to Hunger",
                  "Definition:": "The process to develop a blueprint for a client-centric response to hunger that is based on client feedback and experience, alignment with community needs, and advancement of Mid-Ohio Foodbank’s mission."
              },
              {
                  "Term:": "Key Performance Indicator",
                  "Definition:": "A measurable value that demonstrates how effectively a company is achieving key business objectives."
              },
              {
                  "Term:": "Lapsed Donor",
                  "Definition:": "Donors who used to give to your organization, but for one reason or another, they have stopped giving for more than one year."
              },
              {
                  "Term:": "Less Than Truckload",
                  "Definition:": "Transport of goods that do not fill up a full truck."
              },
              {
                  "Term:": "Marketing",
                  "Definition:": "The action of raising awareness, promoting and selling products or services, including market research and advertising to external audiences."
              },
              {
                  "Term:": "Media",
                  "Definition:": "Traditional and/or mainstream media are newspapers, magazines and TV/radio news channels as well as their online components. New media includes blogs, vlogs, some social media channels and other digital-only outlets. Many of these are partisan or aimed at a specific constituency."
              },
              {
                  "Term:": "Merchandising",
                  "Definition:": "Merchandising promotes the sale of (branded) products that an organization pushes out through various channels to encourage the public to purchase."
              },
              {
                  "Term:": "Messaging",
                  "Definition:": "Messaging is the development of key, strategic statements or talking points designed to frame consistent takeaways from an interview, public relations campaign or event. Sometimes you hear this referred to as “staying on message.”"
              },
              {
                  "Term:": "Mid Ohio Foodbank",
                  "Definition:": "A Nonprofit organization with a mission to end hunger one nourishing meal at a time while co-creating communities where everyone thrives."
              },
              {
                  "Term:": "MOFC",
                  "Definition:": "A Nonprofit organization with a mission to end hunger one nourishing meal at a time while co-creating communities where everyone thrives."
              },
              {
                  "Term:": "Mobile Market",
                  "Definition:": "Monthly deliveries of fresh foods to senior residences, daycares and health clinics in underserved communities."
              },
              {
                  "Term:": "Monthly Poundage Report",
                  "Definition:": "The MPR has only one section, Receipts, the same section as the Quarterly Poundage Report (QPR). Information reported in the MPR enables the national office to monitor trends in a timely manner and quickly respond to emerging needs."
              },
              {
                  "Term:": "National Institute of Food and Agriculture",
                  "Definition:": "A federal body whose purpose is to stimulate and fund the research and technological innovations that will make American agriculture more productive and environmentally sustainable while also providing funding for initiatives such as South Side Roots."
              },
              
              {
                  "Term:": "Natural Resources Conservation Service",
                  "Definition:": "A federal agency that provides technical assistance to farmers and other private landowners and managers and provides funding for initiatives such as Urban Farms of Central Ohio."
              },
              {
                  "Term:": "Neighbor to Neighbor",
                  "Definition:": "A network of volunteers who are Mid-Ohio Foodbank ambassadors that steward the Mid-Ohio Foodbank brand and given tools and information needed when attending/presenting at community speaking engagements."
              },
              
              {
                  "Term:": "Network Activity Report",
                  "Definition:": "An annual report we complete for Feeding America."
              },
              {
                  "Term:": "News Advisory",
                  "Definition:": "Notification of who/what/where/when, designed to secure media coverage."
              },
              {
                  "Term:": "No Salt Added",
                  "Definition:": "Indicates there has been no salt added to the product."
              },
              {
                  "Term:": "Occupational Safety and Health Act",
                  "Definition:": "The mission of the U.S. Occupational Safety and Health Administration (OSHA) is to save lives, prevent injuries, and protect the health of U.S. workers."
              },
              {
                  "Term:": "Occupational Safety and Health Administration",
                  "Definition:": "The mission of the U.S. Occupational Safety and Health Administration (OSHA) is to save lives, prevent injuries, and protect the health of U.S. workers."
              },
              {
                  "Term:": "Ohio Association of Foodbanks",
                  "Definition:": "A nonprofit that assists Ohio’s 12 Feeding America foodbanks in providing food and other resources to people in need and to pursue areas of common interest for the benefit of people in need."
              },
              {
                  "Term:": "Ohio Benefit Bank",
                  "Definition:": "A public-private partnership through the Ohio Association of Foodbanks that provides a service connecting low-income individuals and families to the resources they need through government-funded programs and other services offered throughout the community."
              },
              {
                  "Term:": "Ohio Department of Jobs and Family Services",
                  "Definition:": "The state agency which develops and oversees programs that provide health coverage, employment, economic assistance, child support, and services to families and children. The programs and services offered are designed to help Ohioans be healthy and safe, while gaining and maintaining independence, and are delivered at the local level in a manner that recognizes and preserves individual rights, responsibilities and dignity."
              },
              {
                  "Term:": "ODJFS",
                  "Definition:": "The state agency which develops and oversees programs that provide health coverage, employment, economic assistance, child support, and services to families and children. The programs and services offered are designed to help Ohioans be healthy and safe, while gaining and maintaining independence, and are delivered at the local level in a manner that recognizes and preserves individual rights, responsibilities and dignity."
              },
             
              {
                  "Term:": "Ohio Food Purchase Program",
                  "Definition:": "Funded by the Ohio Department of Job and Family Services through an annual grant for the purchase and distribution of food products by the Ohio Association of Second Harvest Foodbanks to eligible households through the Ohio foodbank network."
              },
             
              {
                  "Term:": "Operation Feed",
                  "Definition:": "A campaign done once a year to raise critically needed resources through a community-wide drive often joining forces with local businesses, schools, civic groups, and individuals."
              },
              {
                  "Term:": "Pledge Partner Solicitation",
                  "Definition:": "Sending out letters to encourage individuals to become a recognized Pledge Partners, a group of dedicated donors who provide monthly gifts."
              },
              {
                  "Term:": "Press Release",
                  "Definition:": "A press release is a document issued to promote a specific piece of information with the goal of news media coverage."
              },
              {
                  "Term:": "Pretty Darn Quick",
                  "Definition:": "Indicates task needs to be done as soon as possible."
              },
              {
                  "Term:": "PDQ",
                  "Definition:": "Indicates task needs to be done as soon as possible."
              },
              {
                  "Term:": "Preventive Maintenance",
                  "Definition:": "Maintenance that is regularly performed on a piece of equipment to lessen the likelihood of it failing."
              },
              {
                  "Term:": "Produce Express",
                  "Definition:": "A fresh produce delivery program that services our supplemental and emergency food sites and soup kitchens which allows our partner agencies the ability to provide fresh fruits, vegetables, and some non-perishable items to food insecure families and individuals on a regular basis."
              },
             
              {
                  "Term:": "Produce Express Pickup",
                  "Definition:": "Regular deliveries of pre-determined amounts of mixed produce are delivered to agencies who incorporate the product into their existing pantry, soup kitchen, or other feeding programs. In Franklin and adjacent counties, deliveries are made directly to agencies. In rural counties, deliveries are made to a centralized location where agencies are expected to pick up and take back to their location."
              },
              {
                  "Term:": "Produce Market",
                  "Definition:": "Free community events sponsored by Mid-Ohio Foodbank and facilitated by select partnering agencies where a Foodbank truck delivers about 10,000 pounds of fresh produce and bakery items to a pre-selected community location."
              },
              {
                  "Term:": "Produce Market Pickup",
                  "Definition:": "Produce Market Pick-up is similar to the produce market program, but the produce is picked up by the partnering agency. Agencies must pick- up a minimum of 2 pallets."
              },
              {
                  "Term:": "Produce Pickup Wednesday",
                  "Definition:": "Produce Pick Up Wednesday (PPW) is a concentrated effort to make more fresh produce available to our partner agencies in our network. Partners, in good standing within our network, are allowed to take all the produce that can be used at their agency from our fresh produce offerings. All agencies are required to register online for PPW."
              },
              {
                  "Term:": "PPW",
                  "Definition:": "Produce Pick Up Wednesday (PPW) is a concentrated effort to make more fresh produce available to our partner agencies in our network. Partners, in good standing within our network, are allowed to take all the produce that can be used at their agency from our fresh produce offerings. All agencies are required to register online for PPW."
              },
              {
                  "Term:": "Promotions",
                  "Definition:": "Promotions are events, giveaways or other methods of engagement intended to share a message about or draw attention to an organization or issue."
              },
              {
                  "Term:": "Public Affairs",
                  "Definition:": "Building relationships between an organization and politicians, government o officials, and other decision-makers. May also include public relations."
              },
              {
                  "Term:": "Public Policy",
                  "Definition:": "The means by which a government maintains order or addresses the needs of its citizens through actions defined by its constitution. Public policy is generally not a tangible thing but rather is a term used to describe a collection of laws, mandates, or regulations established through a political process."
              },
              {
                  "Term:": "Public Relations",
                  "Definition:": "Public relations is the overall strategy aimed at shifting attitudes about products, services or individuals/organizations. Sometimes people refer to press releases or general positive sentiment as “PR” or “good PR.”"
              },
              {
                  "Term:": "Purchase Order",
                  "Definition:": "Uniquely identifies a purchase order that is generally defined by the buyer."
              },
              {
                  "Term:": "Quarterly Poundage Report",
                  "Definition:": "A set of two detailed reports prepared quarterly by members that track poundage received and distributed."
              },
              {
                  "Term:": "Refrigerated",
                  "Definition:": "Indicates this product is a refrigerated good."
              },
              {
                  "Term:": "Social",
                  "Definition:": "Social media began as a purely personal tool to interact in online communities. It still provides that function, but it also has become a powerful communications tool for businesses, nonprofits and news organizations."
              },
              
              {
                  "Term:": "South Side Roots",
                  "Definition:": "South Side Roots is a market and café that provides a welcoming environment for those needing access to healthy food."
              },
              {
                  "Term:": "Summer Food Service Program",
                  "Definition:": "Summer Food Service Programs are those that serve meals and snacks to children in the summer months or during school breaks when school is not in session."
              },
              {
                  "Term:": "Supplemental Nutrition Assistance Program",
                  "Definition:": "Formerly known as food stamps; a federal program that helps low-income families and individuals buy the food they need for good health."
              },
              {
                  "Term:": "South Side Thrive Collaborative",
                  "Definition:": "An innovative coalition of leaders and residents coming together to develop a plan to collectively address the root causes of poverty and it’s intersecting symptoms."
              },
              {
                  "Term:": "Temporary Assistance for Needy Families",
                  "Definition:": "Federal block grant that replaced Aid to Families with Dependent Children (AFDC) in 1996. TANF provides short-term, transitional assistance to needy families with the goal of promoting work and moving families to self-sufficiency."
              },
              {
                  "Term:": "The Emergency Food Assistance Program",
                  "Definition:": "A program of the Food and Nutrition Service (FNS) at the U.S. Department of Agriculture (USDA) that provides food commodities at no cost to low income Americans in need of short-term hunger relief."
              },
              {
                  "Term:": "Take Home Grocery",
                  "Definition:": "A program intended to supplement the weekend nutritional needs of children in low income homes who are participants in after school education and enrichment programs."
              },
              {
                  "Term:": "Third Party Fundraising Events",
                  "Definition:": "Fundraising initiative brought forward by an individual, community group, service club, or business external who wishes to raise money through a planned activity that is designed, managed, and financially resourced by external participants."
              },
              {
                  "Term:": "United States Department of Agriculture",
                  "Definition:": "Federal executive department responsible for developing and executing federal laws related to farming, agriculture, forestry, and food. Also known as the Department of Agriculture (DOA)."
              },
              {
                  "Term:": "United Way of Central Ohio",
                  "Definition:": "A nonprofit organization that improves the lives of others by mobilizing the caring power of our community and bringing together more than 80,000 donors, advocates, and volunteers."
              },
              {
                  "Term:": "Urban Farms of Central Ohio",
                  "Definition:": "An initiative rooted in Mid-Ohio Foodbank that is dedicated to transforming vacant sites in under-served neighborhoods into productive, sustainable urban farms that provide food insecure residents access to fresh, local produce, jobs and job training, and opportunities for civic engagement."
              },
              {
                  "Term:": "Value Added Product",
                  "Definition:": "Any product or action that helps raise the value of products or business or something added to a product that enables an increase in profit margin. (or Processing/Packaging)"
              },
             
              {
                  "Term:": "Visitor Experience",
                  "Definition:": "Visitor experience is the impact/interaction an organization has on a person’s expectations based on the things they do/think/sense/feel."
              },
              {
                  "Term:": "Visual",
                  "Definition:": "A picture, piece of film, or display used to illustrate or accompany something."
              },
              {
                  "Term:": "Voice",
                  "Definition:": "Voice encompasses the unique qualities used by individuals or organizations such as attitude or speech patterns. Understanding voice is particularly important when speaking for the organization."
              },
              {
                  "Term:": "Volunteer Hub",
                  "Definition:": "The website used to attract and schedule volunteers."
              },
              {
                  "Term:": "Volunteers in Service to America",
                  "Definition:": "Federal volunteer program similar to the Peace Corps, however the volunteers work in the United States."
              },
              {
                  "Term:": "Vendor Purchased Produce",
                  "Definition:": "Produce purchased from a vendor to ensure a variety of produce."
              },
              {
                  "Term:": "Web-Based Supply",
                  "Definition:": "An integrated, Internet-based system that includes commodity acquisition, distribution, and tracking system that supports domestic and international food and nutrition programs administered by four United States Department of Agriculture (USDA) agencies. "
              },
              
              {
                  "Term:": "Year To Date",
                  "Definition:": "Refers to the period beginning the first day of the current calendar year up to the current date."
              },
          
              
              {
                  "Term:": "APU",
                  "Definition:": "The area agencies (food pantries) are able to pick up products from Mid-Ohio Foodbank."
              },
              {
                  "Term:": "ACP",
                  "Definition:": "Directs surplus agricultural products from more than 100 Ohio farmers, growers, and producers to Ohio’s 12 Feeding America foodbanks."
              },
              {
                  "Term:": "APR",
                  "Definition:": "Summarizes the Quarterly Poundage Report (QPR) amounts and types of products moved in and out of each Feeding America member warehouse or location during a calendar year."
              },
              {
                  "Term:": "AFP",
                  "Definition:": "Recognized as the premier resource for development and fundraising professionals, providing outstanding educational programs for those seeking professional development and career advancement opportunities"
              },
              {
                  "Term:": "BBB",
                  "Definition:": "An organization whose mission is to be the leader in advancing marketplace trust by helping people find businesses, brands, and charities they can trust. BBB’s vision is an ethical marketplace where buyers and sellers can trust each other."
              },
              {
                  "Term:": "BOL",
                  "Definition:": "A detailed list of a shipment of goods in the form of a receipt given by the carrier to the person consigning the goods."
              },
              
              {
                  "Term:": "CFRE",
                  "Definition:": "A valid and reliable certification process for philanthropic fundraising professionals that have demonstrated recognizable personal and professional achievement and commitment."
              },
              {
                  "Term:": "CGA",
                  "Definition:": "A contract between a donor and a charity where a donor makes a sizable gift to charity using cash, securities, or possibly other assets and in return becomes eligible to take a partial tax deduction and receive a fixed stream of income from the charity for the rest of their life."
              },
              {
                  "Term:": "C4C",
                  "Definition:": "(now known as SSTC, but same initiative) The South Side Thrive Collaborative seeks to align community partners around a set of goals, outcomes, and indicators that will ultimately create positive results within the (south side Columbus) community."
              },
              {
                  "Term:": "CMC",
                  "Definition:": "A 501c3 nonprofit that connects people and ideas through community conversation."
              },
              
              
              {
                  "Term:": "DLVD",
                  "Definition:": "A way to signify that the products have been delivered to the correct agency."
              },
              {
                  "Term:": "DOA",
                  "Definition:": "Federal executive department responsible for developing and executing federal laws related to farming, agriculture, forestry, and food. Also known as the United States Department of Agriculture (USDA)."
              },
              {
                  "Term:": "DOT",
                  "Definition:": "A department of the federal executive branch responsible for the national highways and for railroad and airline safety."
              },
              {
                  "Term:": "DRP",
                  "Definition:": "Strategic initiative that allows partner agencies direct access to free, highly nutritious perishables and increases emergency food distribution by partnering with local retailers."
              },
              {
                  "Term:": "DC",
                  "Definition:": "A warehouse that is stocked with products (food) to be redistributed to retailers, consumers, or in our case, food pantries."
              },
              {
                  "Term:": "DIST",
                  "Definition:": "Produce distribution initiative that allows agencies to acquire fresh produce directly from the Foodbank warehouse."
              },
              {
                  "Term:": "DAF",
                  "Definition:": "A philanthropic vehicle established at a public charity that allows donors to make a charitable contribution, receive an immediate tax benefit, and then recommend grants from the fund over time."
              },
              {
                  "Term:": "DYDD",
                  "Definition:": "One-day media supported match event where donors go online or call our phone bank to make donations that will be matched through previously secured gifts."
              },
              
              {
                  "Term:": "FINI",
                  "Definition:": "A grant program that supports projects like South Side Roots to increase the purchase of fruits and vegetables among low-income consumers participating in the Supplemental Nutrition Assistance Program (SNAP) by providing incentives at the point of purchase."
              },
              {
                  "Term:": "EBT",
                  "Definition:": "The method by which food stamps and other benefits are distributed via an electronic debit card. Some states also use EBT to distribute benefits under Women, Infants and Children (WIC), and other programs."
              },
              {
                  "Term:": "EPREF",
                  "Definition:": "This indicates that the donor prefers email communications."
              },
              {
                  "Term:": "ESOL",
                  "Definition:": "An electronic promotional message sent to a consumer."
              },
              {
                  "Term:": "EFSP",
                  "Definition:": "A federally-funded program administrated by the Federal Emergency Management Agency (FEMA) whose purpose is to supplement and expand the ongoing work of local social service organizations to provide shelter, food, and supportive services to individuals and families who have economic emergencies."
              },
              
              {
                  "Term:": "FA",
                  "Definition:": "A nationwide network of more than 200 food banks that feed more than 46 million people through food pantries, soup kitchens, shelters, and other community-based agencies. Mid-Ohio Foodbank is a part of Feeding America."
              },
              {
                  "Term:": "FAU",
                  "Definition:": "Online learning system accessed via HungerNet, which offers more than 100 online training courses across four categories."
              },
              {
                  "Term:": "FYTD",
                  "Definition:": "A period starting from the beginning of the current fiscal year and continuing up to the present day."
              },
              {
                  "Term:": "FAN",
                  "Definition:": "A network of individuals working together to achieve Mid-Ohio Foodbank’s goal of impacting public policy decisions and creating positive change by engaging public policy decision-makers and constituents alike in the hunger conversation."
              },
              {
                  "Term:": "FAO",
                  "Definition:": "A team at Mid-Ohio Foodbank that goes into the community to pre-screen individuals, connect them to resources in the Ohio Benefit Bank, and enroll those eligible for SNAP/food stamps."
              },
              
              {
                  "Term:": "FPNLC",
                  "Definition:": "A cooperative associated with Mid-Ohio Foodbank that coordinates the acquisition and distribution of emergency food supplies by working through its member food agencies."
              },
              {
                  "Term:": "FTE",
                  "Definition:": "Feeding America’s approach to accurately evaluate and describe the nutritional contributions of the food categories in network foodbanks’ inventories."
              },
              {
                  "Term:": "FOB",
                  "Definition:": "A designation that is used to indicate when liability and ownership of goods is transferred from a seller to a buyer."
              },
              {
                  "Term:": "FFP",
                  "Definition:": "A FFP is eligible to pick up produce weekly at MOF. There is no minimum requirement of poundage for this program and is suitable for smaller programs wanting to connect their clients to fresh food."
              },
              {
                  "Term:": "FRZ",
                  "Definition:": "Indicates this product is a frozen good."
              },
              {
                  "Term:": "PUR",
                  "Definition:": "Ensuring that all costs involved in running a project are recovered, through securing funding which includes a relevant proportion of organizational costs."
              },
              {
                  "Term:": "FTL",
                  "Definition:": "Transport of goods that fill up a full truck."
              },
             
              {
                  "Term:": "HOL",
                  "Definition:": "Program to purchase holiday food products for that time of year."
              },
              {
                  "Term:": "HAM",
                  "Definition:": "A national “Skip Lunch to Fight Hunger” campaign held during the month of September. The campaign asks Americans to donate their lunch money to the Feeding America network."
              },
              {
                  "Term:": "HON",
                  "Definition:": "Indicates the donation/ item has been given in honor of a certain individual or group."
              },
              {
                  "Term:": "IMO",
                  "Definition:": "Indicates the donation/ item has been given in memory of a deceased individual."
              },
              {
                  "Term:": "IT",
                  "Definition:": "Use of computers to store, retrieve, transmit and manipulate data or information."
              },
              {
                  "Term:": "IRTH",
                  "Definition:": "The process to develop a blueprint for a client-centric response to hunger that is based on client feedback and experience, alignment with community needs, and advancement of Mid-Ohio Foodbank’s mission."
              },
              {
                  "Term:": "KPI",
                  "Definition:": "A measurable value that demonstrates how effectively a company is achieving key business objectives."
              },
              {
                  "Term:": "LNOTE",
                  "Definition:": "Donors who used to give to your organization, but for one reason or another, they have stopped giving for more than one year."
              },
              {
                  "Term:": "LTL",
                  "Definition:": "Transport of goods that do not fill up a full truck."
              },
              
              {
                  "Term:": "MOF",
                  "Definition:": "Nonprofit organization with a mission to end hunger one nourishing meal at a time while co-creating communities where everyone thrives."
              },
              {
                  "Term:": "MMK",
                  "Definition:": "Monthly deliveries of fresh foods to senior residences, daycares and health clinics in underserved communities."
              },
              {
                  "Term:": "MPR",
                  "Definition:": "The MPR has only one section, Receipts, the same section as the Quarterly Poundage Report (QPR). Information reported in the MPR enables the national office to monitor trends in a timely manner and quickly respond to emerging needs."
              },
              {
                  "Term:": "NIFA",
                  "Definition:": "A federal body whose purpose is to stimulate and fund the research and technological innovations that will make American agriculture more productive and environmentally sustainable while also providing funding for initiatives such as South Side Roots."
              },
              
              {
                  "Term:": "NRCS",
                  "Definition:": "A federal agency that provides technical assistance to farmers and other private landowners and managers and provides funding for initiatives such as Urban Farms of Central Ohio."
              },
              {
                  "Term:": "N2N",
                  "Definition:": "A network of volunteers who are Mid-Ohio Foodbank ambassadors that steward the Mid-Ohio Foodbank brand and given tools and information needed when attending/presenting at community speaking engagements."
              },
              
              {
                  "Term:": "NAR",
                  "Definition:": "An annual report we complete for Feeding America."
              },
             
              {
                  "Term:": "NSA",
                  "Definition:": "Indicates there has been no salt added to the product."
              },
              {
                  "Term:": "OSHA",
                  "Definition:": "The mission of the U.S. Occupational Safety and Health Administration (OSHA) is to save lives, prevent injuries, and protect the health of U.S. workers."
              },
              {
                  "Term:": "OAF",
                  "Definition:": "A nonprofit that assists Ohio’s 12 Feeding America foodbanks in providing food and other resources to people in need and to pursue areas of common interest for the benefit of people in need."
              },
              {
                  "Term:": "OAOF",
                  "Definition:": "A nonprofit that assists Ohio’s 12 Feeding America foodbanks in providing food and other resources to people in need and to pursue areas of common interest for the benefit of people in need."
              },
              {
                  "Term:": "OBB",
                  "Definition:": "A public-private partnership through the Ohio Association of Foodbanks that provides a service connecting low-income individuals and families to the resources they need through government-funded programs and other services offered throughout the community."
              },
              {
                  "Term:": "ODJFS",
                  "Definition:": "The state agency which develops and oversees programs that provide health coverage, employment, economic assistance, child support, and services to families and children. The programs and services offered are designed to help Ohioans be healthy and safe, while gaining and maintaining independence, and are delivered at the local level in a manner that recognizes and preserves individual rights, responsibilities and dignity."
              },
              
              {
                  "Term:": "OFP",
                  "Definition:": "Funded by the Ohio Department of Job and Family Services through an annual grant for the purchase and distribution of food products by the Ohio Association of Second Harvest Foodbanks to eligible households through the Ohio foodbank network."
              },
              
              {
                  "Term:": "OPFEED",
                  "Definition:": "A campaign done once a year to raise critically needed resources through a community-wide drive often joining forces with local businesses, schools, civic groups, and individuals."
              },
              {
                  "Term:": "PPSOL",
                  "Definition:": "Sending out letters to encourage individuals to become a recognized Pledge Partners, a group of dedicated donors who provide monthly gifts."
              },
              {
                  "Term:": "Press Release",
                  "Definition:": "A press release is a document issued to promote a specific piece of information with the goal of news media coverage."
              },
              {
                  "Term:": "PDQ",
                  "Definition:": "Indicates task needs to be done as soon as possible."
              },
              {
                  "Term:": "PM",
                  "Definition:": "Maintenance that is regularly performed on a piece of equipment to lessen the likelihood of it failing."
              },
              {
                  "Term:": "PX",
                  "Definition:": "A fresh produce delivery program that services our supplemental and emergency food sites and soup kitchens which allows our partner agencies the ability to provide fresh fruits, vegetables, and some non-perishable items to food insecure families and individuals on a regular basis."
              },
              {
                  "Term:": "PXP",
                  "Definition:": "Regular deliveries of pre-determined amounts of mixed produce are delivered to agencies who incorporate the product into their existing pantry, soup kitchen, or other feeding programs. In Franklin and adjacent counties, deliveries are made directly to agencies. In rural counties, deliveries are made to a centralized location where agencies are expected to pick up and take back to their location."
              },
              {
                  "Term:": "PM",
                  "Definition:": "Free community events sponsored by Mid-Ohio Foodbank and facilitated by select partnering agencies where a Foodbank truck delivers about 10,000 pounds of fresh produce and bakery items to a pre-selected community location."
              },
              {
                  "Term:": "PMP",
                  "Definition:": "Produce Market Pick-up is similar to the produce market program, but the produce is picked up by the partnering agency. Agencies must pick- up a minimum of 2 pallets."
              },
              {
                  "Term:": "PPW",
                  "Definition:": "Produce Pick Up Wednesday (PPW) is a concentrated effort to make more fresh produce available to our partner agencies in our network. Partners, in good standing within our network, are allowed to take all the produce that can be used at their agency from our fresh produce offerings. All agencies are required to register online for PPW."
              },
              {
                  "Term:": "Promotions",
                  "Definition:": "Promotions are events, giveaways or other methods of engagement intended to share a message about or draw attention to an organization or issue."
              },
              
              {
                  "Term:": "PO",
                  "Definition:": "Uniquely identifies a purchase order that is generally defined by the buyer."
              },
              {
                  "Term:": "PO number",
                  "Definition:": "Uniquely identifies a purchase order that is generally defined by the buyer."
              },
              {
                  "Term:": "QPR",
                  "Definition:": "A set of two detailed reports prepared quarterly by members that track poundage received and distributed."
              },
              {
                  "Term:": "REF",
                  "Definition:": "Indicates this product is a refrigerated good."
              },
              
              {
                  "Term:": "SSR",
                  "Definition:": "South Side Roots is a market and café that provides a welcoming environment for those needing access to healthy food."
              },
              {
                  "Term:": "SFSP",
                  "Definition:": "Summer Food Service Programs are those that serve meals and snacks to children in the summer months or during school breaks when school is not in session."
              },
              {
                  "Term:": "SNAP",
                  "Definition:": "Formerly known as food stamps; a federal program that helps low-income families and individuals buy the food they need for good health."
              },
              {
                  "Term:": "SSTC",
                  "Definition:": "An innovative coalition of leaders and residents coming together to develop a plan to collectively address the root causes of poverty and it’s intersecting symptoms."
              },
              {
                  "Term:": "TANF",
                  "Definition:": "Federal block grant that replaced Aid to Families with Dependent Children (AFDC) in 1996. TANF provides short-term, transitional assistance to needy families with the goal of promoting work and moving families to self-sufficiency."
              },
              {
                  "Term:": "TEFAP",
                  "Definition:": "A program of the Food and Nutrition Service (FNS) at the U.S. Department of Agriculture (USDA) that provides food commodities at no cost to low income Americans in need of short-term hunger relief."
              },
              {
                  "Term:": "THG",
                  "Definition:": "A program intended to supplement the weekend nutritional needs of children in low income homes who are participants in after school education and enrichment programs."
              },
              {
                  "Term:": "3Fund",
                  "Definition:": "Fundraising initiative brought forward by an individual, community group, service club, or business external who wishes to raise money through a planned activity that is designed, managed, and financially resourced by external participants."
              },
              {
                  "Term:": "USDA",
                  "Definition:": "Federal executive department responsible for developing and executing federal laws related to farming, agriculture, forestry, and food. Also known as the Department of Agriculture (DOA)."
              },
              {
                  "Term:": "UWCO",
                  "Definition:": "A nonprofit organization that improves the lives of others by mobilizing the caring power of our community and bringing together more than 80,000 donors, advocates, and volunteers."
              },
              {
                  "Term:": "UFCO",
                  "Definition:": "An initiative rooted in Mid-Ohio Foodbank that is dedicated to transforming vacant sites in under-served neighborhoods into productive, sustainable urban farms that provide food insecure residents access to fresh, local produce, jobs and job training, and opportunities for civic engagement."
              },
              {
                  "Term:": "VAP",
                  "Definition:": "Any product or action that helps raise the value of products or business or something added to a product that enables an increase in profit margin."
              },
              {
                  "Term:": "VHUB",
                  "Definition:": "Visitor experience is the impact/interaction an organization has on a person’s expectations based on the things they do/think/sense/feel."
              },
              
              {
                  "Term:": "VISTA",
                  "Definition:": "Federal volunteer program similar to the Peace Corps, however the volunteers work in the United States."
              },
              {
                  "Term:": "VPP",
                  "Definition:": "Produce purchased from a vendor to ensure a variety of produce."
              },
              {
                  "Term:": "WBSCM",
                  "Definition:": "An integrated, Internet-based system that includes commodity acquisition, distribution, and tracking system that supports domestic and international food and nutrition programs administered by four United States Department of Agriculture (USDA) agencies."
              },
              {
                  "Term:": "WMS",
                  "Definition:": "An integrated, Internet-based system that includes commodity acquisition, distribution, and tracking system that supports domestic and international food and nutrition programs administered by four United States Department of Agriculture (USDA) agencies."
              },
              {
                  "Term:": "YTD",
                  "Definition:": "Refers to the period beginning the first day of the current calendar year up to the current date."
              },
      

      
      {
          "Term:": "170(e)(3)",
          "Definition:": "The U.S. Internal Revenue Code section that explains the tax deduction available to corporations for donations out of inventory.  Generally, the maximum tax deduction is equal to the cost of the goods plus one-half the mark up.  Feeding America members handle donated goods in accordance with the provisions of Section 170(e)(3), as amplified by the Gray Area Task Force Report and the Feeding America Member Contract."
      },
      {
          "Term:": "170e3",
          "Definition:": "The U.S. Internal Revenue Code section that explains the tax deduction available to corporations for donations out of inventory.  Generally, the maximum tax deduction is equal to the cost of the goods plus one-half the mark up.  Feeding America members handle donated goods in accordance with the provisions of Section 170(e)(3), as amplified by the Gray Area Task Force Report and the Feeding America Member Contract."
      },
      {
          "Term:": "501(c)(3)",
          "Definition:": "The U.S. Internal Revenue Code Section that defines a private not-for- profit corporation with charitable intent.  Section 501(c) has several dozen subsections, but Section 170(e)(3) restricts the distribution of donated goods by members to only those described under subsection 501(c)(3)."
      },
      {
          "Term:": "501c3",
          "Definition:": "The U.S. Internal Revenue Code Section that defines a private not-for- profit corporation with charitable intent.  Section 501(c) has several dozen subsections, but Section 170(e)(3) restricts the distribution of donated goods by members to only those described under subsection 501(c)(3)."
      },
      
      {
          "Term:": "A La Carte",
          "Definition:": "In schools, à la carte refers to food and beverages sold to students in the cafeteria, in addition to the meals and snacks served through the federally- reimbursed child nutrition programs."
      },
      {
          "Term:": "Able-Bodied Adults Without Dependents",
          "Definition:": "The term ABAWDs is applied to jobless individuals aged 18 to 50 without dependents.  These individuals are limited to three months of Supplemental Nutrition Assistance Program (food stamp benefits) in a 36- month period, unless there is an exemption.  An individual is exempt if he or she is employed or participating in an approved work or training program at least half time, or participating in federal workforce programs for the required number of hours.  States can apply for a waiver to this rule for areas where the unemployment rate exceeds 10 percent, or where an insufficient number of jobs exist to provide employment for these individuals."
      },
      
      {
          "Term:": "ABAWD",
          "Definition:": "The term ABAWDs is applied to jobless individuals aged 18 to 50 without dependents.  These individuals are limited to three months of Supplemental Nutrition Assistance Program (food stamp benefits) in a 36- month period, unless there is an exemption.  An individual is exempt if he or she is employed or participating in an approved work or training program at least half time, or participating in federal workforce programs for the required number of hours.  States can apply for a waiver to this rule for areas where the unemployment rate exceeds 10 percent, or where an insufficient number of jobs exist to provide employment for these individuals."
      },
      {
          "Term:": "Academic Activities",
          "Definition:": "Activities that include tutoring, homework assistance, or educational computer classes."
      },
      {
          "Term:": "ACPN",
          "Definition:": "Agency Capacity, Programs and Nutrition Conference"
      },
      {
          "Term:": "Action Alert",
          "Definition:": "A message, sent only at key times in the legislative and budget process, which is intended to mobilize stakeholders to influence public policies around an important topic of interest to them."
      },
      {
          "Term:": "Administrative Costs",
          "Definition:": "Costs incurred by a sponsor related to planning, organizing and managing a food service under the program, and excluding interest and operating costs.  See Sponsor; Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "ADR Organization",
          "Definition:": "(As defined in the Feeding America Member Contract) JAMS (formally Judicial Arbitration & Mediation Services), or its successor, or in the event there is no JAMS facility within 200 miles of either party, the American Arbitration Association, or such other organization as the parties to a dispute may mutually agree upon."
      },
      
     
      {
          "Term:": "Adulterated",
          "Definition:": "Any purposeful change (such as soil, dirt, mold, yeast, bacteria, insects, pesticides, unsanitary conditions, unapproved additives) that alters the product composition or the meaning of the name under which it is sold. See Correction."
      },
      {
          "Term:": "Adulteration",
          "Definition:": "To make imperfect by adding extraneous, improper, or inferior ingredients."
      },
      {
          "Term:": "Advance Payments",
          "Definition:": "Financial assistance made available to a sponsor for its operating costs and/or administrative costs prior to the end of the month in which such costs will be incurred.  See Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Advanced Level Outreach",
          "Definition:": "Food banks conducting an advanced level of Supplemental Nutrition Assistance Program (SNAP) outreach (i.e., a worker who performs application assistance).  http://www.fns.usda.gov/snap/"
      },
     
      {
          "Term:": "AfterSchool Snack Program",
          "Definition:": "A “Snack Program” provides healthy, nutritious snacks for children at least 15 times per year.  A “snack” consists of at least two of the five food groups of the recommended USDA MyPyramid (fruit, vegetable, grain, protein and dairy).  All snacks must be offered free of charge.  If a food bank operates a Snack program, the national office should have a signed program agreement on file."
      },
     
      {
          "Term:": "Agency",
          "Definition:": "(As defined in the Feeding America Member Contract) A nonprofit organization or its legal equivalent that receives food from a member. In Ceres, if a member provides food to another member food bank, a non- member food bank (SDO) or a related organization (such as Meals on Wheels) they are set up as agencies since an agency is essentially a customer to which product is “sold” and invoiced. Therefore, agencies have a more expanded definition in Ceres — everyone who gets invoiced is an agency."
      },
      
      {
          "Term:": "Agency Capacity Building",
          "Definition:": "Agencies are the charitable organizations supplied with grocery products by a Feeding America member that provides food directly to needy clients through various types of programs. Building agency capacity helps increase agencies’ effectiveness and therefore enables them to optimize food distribution to people at risk of hunger. State funds used for agency capacity building are relatively flexible and can be used for a multitude of projects from increasing refrigerator and freezer space to supporting hunger relief programs at the agencies."
      },
      
      {
          "Term:": "Agency Survey",
          "Definition:": "Of the two survey components of the Hunger Study, the Agency Survey is a census of all active agencies a participating food bank has at the time of the study.  Unlike the Client Survey, the Agency Survey utilized a paper survey and collected information about the food programs they operated.  In addition, the Agency Survey included emergency and non-emergency feeding programs."
      },
     
      {
          "Term:": "Agency Express",
          "Definition:": "An internet based online ordering system that allows agencies to place orders with member food banks. Member food banks post inventory available for agencies to view, order, and schedule for pick-up or delivery. Agency Express is designed specifically for Feeding America and for use with Ceres, the Microsoft Dynamics NAV system created for the Feeding America network."
      },
      {
          "Term:": "Agency Relations",
          "Definition:": "The customer services division of a network member; the myriad of activities related to members finding, recruiting, monitoring and serving the agencies that they supply with grocery products."
      },
      {
          "Term:": "Agency Relations Council",
          "Definition:": "A group of member agency relations professionals whose main purpose is to maximize the effectiveness of agency relations staff throughout the network and provide guidance and leadership in the development of the annual Agency Relations and Programs Conference."
      },
      {
          "Term:": "AHPC",
          "Definition:": "Anti-Hunger Policy Conference"
      },
      {
          "Term:": "Allergen",
          "Definition:": "Certain proteins that cause an immune system response in allergic persons. Examples include milk, eggs, peanuts, tree nuts (walnuts, almonds, pecans, hazelnuts/filberts, pistachios, cashews, pine nuts, coconut, macadamia nuts, and brazil nuts), fish, shellfish (crab, crawfish, lobster, shrimp, mussels, and oysters), wheat, soybeans, and sesame seeds.  Food Allergen Labeling and Consumer Protection Act of 2004 (Public Law 108-282, Title II)"
      },
      {
          "Term:": "American Meat Institute (AMI)",
          "Definition:": "The nation’s oldest and largest meat trade association.  AMI is dedicated to increasing the efficiency, profitability and safety of meat trade worldwide."
      },
      {
          "Term:": "American Public Human Services Association (APHSA)",
          "Definition:": "APHSA is a nonprofit organization of state and local human service agencies and individuals with the goal of developing and promoting policies and practices that improve the health and well‐being of families, children, and adults.  http://www.aphsa.org/Home/home_news.asp"
      },
      
      {
          "Term:": "Annual Poundage Report (APR)",
          "Definition:": "Annual Poundage Report summarizes the Quarterly Poundage Report (QPR) amounts and types of products moved in and out of each Feeding America member warehouse or location during a calendar year."
      },
      {
          "Term:": "Annuity",
          "Definition:": "A contract (legal obligation) to pay specified amounts over a period of time to a specified individual(s), in exchange for cash, securities, or other tangible property."
      },
      {
          "Term:": "APHIS",
          "Definition:": "Animal and Plant Health Inspection Service"
      },
      {
          "Term:": "Appreciated Assets",
          "Definition:": "Assets that have a higher marker value than their basis or tax-purpose value.  Such assets would, if sold by an individual or non-charitable organization at a price higher than their basis, potentially generate a taxable capital gain (either long-term or short-term depending on the holding period)."
      },
      {
          "Term:": "ARC",
          "Definition:": "American Red Cross"
      },
      {
          "Term:": "Area Eligibility",
          "Definition:": "Determined using census or school data that captures the percentage of children qualifying for free or reduced-price lunches at the neighborhood elementary school; based on the percentage of children in families with income at or below 185 percent of the Federal Poverty Level in a given area.  Within the child nutrition programs, all children in schools and child care settings in an eligible area qualify for free or reduced-price meals; also, child care providers participating in the Child and Adult Care Food Program (CACFP) qualify for the highest reimbursement level per meal."
      },
      
     
      {
          "Term:": "Asset Limit",
          "Definition:": "The value of household assets that cannot be exceeded in order for a household to be eligible for food stamps.  The current asset limit is $2,000, unless there is at least one person in the household who is disabled or aged 60+, in which case the asset limit is $3,000.  Not all assets are included in the calculation of asset limit.  See Supplemental Nutrition"
      },
      {
          "Definition:": "Assistance Program (SNAP).  http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "AwardVision",
          "Definition:": "Fund management software that works within the framework of the Finance general ledger.  It is a financial reporting and compliance tool used to track the financial activity of donor restricted awards."
      },
      {
          "Term:": "Baby",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Baby Food/Formula."
      },
      {
          "Term:": "Backhaul",
          "Definition:": "Goods carried by a truck on its return journey after making a primary delivery, or the carrying of those goods (used as noun or verb)."
      },
      {
          "Term:": "BackPack Carrier",
          "Definition:": "See Carrier."
      },
      {
          "Term:": "Backpack Program",
          "Definition:": "A national program of Feeding America that is designed to meet the needs of hungry children at times when other resources are not available, such as weekends and school vacations. Through this program, children are given backpacks filled with food to take home.  If a food bank operates a BackPack program, the national office should have a signed program agreement on file."
      },
      
      {
          "Term:": "Bar Code",
          "Definition:": "An electronic inventory control system that identifies products by scanning a series of printed bars.  Using bar codes improves the speed and accuracy of inventory counts."
      },
      {
          "Term:": "Barcode",
          "Definition:": "An electronic inventory control system that identifies products by scanning a series of printed bars.  Using bar codes improves the speed and accuracy of inventory counts."
      },
      {
          "Term:": "Barter Commodities",
          "Definition:": "See Stocks-for-Food Initiative."
      },
      {
          "Term:": "Benchmark",
          "Definition:": "A set of measurements used to establish goals, operating targets and productivity programs.  Used to measure progress against best practices."
      },
      {
          "Term:": "Beneficiary",
          "Definition:": "An individual or entity named to receive an asset."
      },
      {
          "Term:": "Bequest",
          "Definition:": "A direction in a will to pay over or distribute personal property."
      },
      {
          "Term:": "Best If Used By Date",
          "Definition:": "Product should be used by this date to experience the highest quality."
      },
      {
          "Term:": "Best Practices",
          "Definition:": "Best practices are the products of benchmarking.  They are the innovative methods, policies, or programs of other top-performing organizations that make them successful.  They must be based on business practices that have been effectively replicated over time, with measurable and positive results."
      },
      
      {
          "Term:": "Beverage",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Coffee, Tea, Soda, Drinks."
      },
      {
          "Term:": "Bill of Lading",
          "Definition:": "An itemized statement that lists goods in a shipment and establishes a contract of carriage between the consignor (donor) and consignee (member)."
      },
      {
          "Term:": "BL ",
          "Definition:": "Bill of Lading, An itemized statement that lists goods in a shipment and establishes a contract of carriage between the consignor (donor) and consignee (member)."
      },
      
      {
          "Term:": "Bioterrorism Act",
          "Definition:": "Regulation that requires key components to protect the nation’s food supply chain from acts of intentional contamination."
      },
      {
          "Term:": "Blue Receipt",
          "Definition:": "A receipt that must be generated by a food bank and sent to the national office whenever a national partner donates to a local food bank directly (rather than working through Feeding America in Chicago)."
      },
      {
          "Term:": "Board Designated Net Assets",
          "Definition:": "(As defined by the CFO best practices team on Operating Reserves) Unrestricted net assets that the Board of Directors has set aside either by vote or according to policy to use for a specific purpose, such as: Disaster Relief:  Reserves set aside by the organization’s Board to cover costs of a disaster or sudden disruption in operations. An example might be a disruption in operations or cash flows from a flood, fire, earthquake, power outage, or other catastrophe which may result in the sudden loss of revenues, grant funding, personnel, property or equipment. Capital Replacement:  The net investment in capital assets infrastructure should not be eroded and should, at least, be maintained.  A capital replacement fund, calculated using replacement costs and expected life cycles for capital assets, should be designated and used to maintain capital assets in support of the organization’s mission. Capacity Building:  A capacity building fund is a reserve set aside to cover projects that expand the food bank’s programs.  Examples include a pilot program, seed funds for a capital campaign, new construction, remodeling, new equipment or other new ventures. Board-designated funds are excluded from available unrestricted net assets in the reserves calculation."
      },
      
      {
          "Term:": "Board of Directors",
          "Definition:": "Group of elected or appointed people who, by law, have ultimate responsibility for an organization.  Generally, boards set policy, raise funds, approve budgets and hold staff accountable for day-to-day operations."
      },
      {
          "Term:": "Box Truck",
          "Definition:": "Box trucks have separate, box-like cargo areas that sit on the frame and  are totally separate from the cab (cannot be accessed from the cab).  Some box trucks have a cargo area that is grafted to the cab. The cargo area in some box trucks built like that can be accessed from the cab.   Most box trucks have a roll-up rear door that is similar to a garage door. Box trucks are generally used by companies that need to haul large items such as furniture, appliances, and large boxes. They are frequently used as rental moving vans by companies such as U-Haul and Ryder. Box trucks come in all sizes."
      },
      
      {
          "Term:": "Branch",
          "Definition:": "Facility owned and operated by a member at a location separate from the owning member’s main facility."
      },
      {
          "Term:": "Brand",
          "Definition:": "Manufacturer’s identification or trademark of product.  For example, Pampers is a brand of Procter & Gamble; Cheerios is a brand of General Mills."
      },
      {
          "Term:": "Branded Product",
          "Definition:": "Product produced and marketed to consumers under a given name. Consumers expect a certain level of quality and integrity from items that are sold under a given brand name."
      },
      {
          "Term:": "Bread Products",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Bread, Biscuits, Rolls, Batter, Tortillas, Pie Crusts."
      },
      {
          "Term:": "Briefing Worksheet",
          "Definition:": "Outlines details for cultivation and solicitation visits"
      },
      {
          "Term:": "Brites",
          "Definition:": "An unlabeled can that must be labeled in accordance with FDA requirements before being distributed. See Shiners."
      },
      {
          "Term:": "Broker",
          "Definition:": "An agent who arranges business transactions for a commission.  Brokers are common in all facets of logistics, such as selling product, arranging trucking or leasing equipment."
      },
      {
          "Term:": "Brown Bag Program",
          "Definition:": "A program that provides boxes or bags of food to needy families. The food is usually distributed to families on an as-needed basis, but some programs provide a regular supply of supplemental food to families/senior citizens via formally organized Brown Bag Clubs."
      },
      
      {
          "Term:": "Budget Document",
          "Definition:": "A budget document relates to proposed legislation, current legislation, or legislative fiscal notes. Budget documents may reflect a cost, benefit, budget projection, fiscal impact, or proposal."
      },
      
      {
          "Term:": "Budget Manager",
          "Definition:": "A staff member who oversees programs and expenses. In the context of Donor Fund Management, a budget manager may charge expenses to specific grants that are restricted by the donor to fund specific programs."
      },
      {
          "Term:": "Bulk Bin",
          "Definition:": "A shipping container that holds large amounts of product.  Most containers are pallet-size in length and width and are three to four feet high.  Also known as totes or gaylords."
      },
      {
          "Term:": "Bulk Purchasing",
          "Definition:": "Groups (primarily network members) that pool their purchased goods (generally products for distribution) to buy at a volume discount price."
      },
      {
          "Term:": "Bulkhead",
          "Definition:": "A wall or divider that is installed in a truck to separate products requiring different handling temperatures—such as frozen and refrigerated goods."
      },
      {
          "Term:": "Business Continuity Plan",
          "Definition:": "A set of procedures that defines how an organization will resume its critical business functions in the event of an unplanned disruption to normal processing.  The Business Continuity Plan is not intended to be an Operations Manual.  It is intended to be a guide to recover operations by employees that are knowledgeable about the individual Business Units."
      },
      {
          "Term:": "Campaign Priorities",
          "Definition:": "Fundraising priorities for the Campaign for a Hunger-Free America defined by the Philanthropy department as outlined in Feeding America's Strategic Plan: Broaden the Base; Retail Store Donation; FMCE; Child Hunger; SNAP Outreach; Produce Subsidy; Mobile Pantries; and Technology."
      },
      {
          "Term:": "Camps",
          "Definition:": "Residential summer camps and nonresidential day camps that offer regularly scheduled food service as part of an organized program for enrolled children.  Nonresidential camp sites must offer a continuous schedule of organized cultural or recreational programs between meal services.  See Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
     
      {
          "Term:": "Philanthropic capacity",
          "Definition:": "Philanthropic capacity is a suggested possible total amount an individual might be expected to give to a charitable cause, based on research of wealth and personal/business assets."
      },
      
      {
          "Term:": "Capital Building Funds",
          "Definition:": "State appropriations for capital building funds are often used for food bank and/or partner distribution organization and/or agency infrastructure improvements, such as increasing warehouse capacity and/or refrigerated or freezer storage space."
      },
      {
          "Term:": "Capital Gains Tax",
          "Definition:": "The tax imposed on profits realized from the sale of financial assets that have increased in value since they were acquired."
      },
      {
          "Term:": "Cargo Container",
          "Definition:": "A shipping container that can be put on wheels and hauled by a truck, put on a flat car and hauled by a train or stacked on a ship."
      },
      {
          "Term:": "Carrier",
          "Definition:": "This term has two distinct definitions: a.Individuals, partners or corporations engaged in the business of transporting goods, such as a trucking company. a.    Individuals, partners or corporations engaged in the business of transporting goods, such as a trucking company. b. (As defined by the BackPack Program) The pack unit containing food for distribution.  For example, both backpacks and plastic bags are carriers for the BackPack Program."
      },
      
      {
          "Term:": "Case Count",
          "Definition:": "The number of cased goods in a shipment."
      },
      {
          "Term:": "Case Cube",
          "Definition:": "Measurement of case dimensions that is used to determine handling costs and the volume of lightweight product a truck can hold."
      },
      {
          "Term:": "Case Pack",
          "Definition:": "The number of units in a case, such as 24 jars per case."
      },
      {
          "Term:": "Case Weight",
          "Definition:": "The gross weight of the cased product, including contents and the case itself."
      },
      {
          "Term:": "Case-Lot Picking",
          "Definition:": "Selection of full cases of a product when the order is less than a full pallet load."
      },
      {
          "Term:": "Categorical Eligibility",
          "Definition:": "Provision of the Food Stamp Act, which declares participants receiving benefits under certain programs that include an income resources test are also automatically eligible to receive food stamps.  Qualifying programs include Title IV-A of the Social Security Act and Temporary Assistance for Needy Families (TANF).  See Supplemental Nutrition Assistance Program (SNAP).  http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "Cause Marketing",
          "Definition:": "Links a company product or brand to a social cause or issue in order to drive sales, increase consumer loyalty and build brand image.  Usually a predetermined percentage of sales, income or profit is designated to support the cause. Cause marketing differs from corporate giving (philanthropy) because it does not generally involve a tax-deductible donation (as a philanthropic donation does).  It does, however, require a consumer action of some kind."
      },
      
      {
          "Term:": "CBO",
          "Definition:": "Community-Based Organization"
      },
      {
          "Term:": "CDC",
          "Definition:": "Centers for Disease Control and Prevention"
      },
      {
          "Term:": "Center on Budget and Policy Priorities (CBPP)",
          "Definition:": "The CBPP is one of the nation’s premier policy organizations working at the federal and state levels on fiscal policy and public programs that affect low- and moderate-income families and individuals."
      },
      
      {
          "Term:": "Centralized  Cluster",
          "Definition:": "A cluster of members where all products donated in less than truckloads (LTL) and full truckloads (FTL) are offered, allocated and receipted through the cluster head.  See Cluster Head; Decentralized Cluster."
      },
      {
          "Term:": "Centralized Donor",
          "Definition:": "A company with a policy that states all decisions to donate must come from the corporate headquarters and be channeled through the Feeding America national office."
      },
      {
          "Term:": "Cereal",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Hot and Cold Cereal."
      },
      {
          "Term:": "Ceres",
          "Definition:": "A warehouse, inventory and financial management system tailored for food banking. Ceres is based on Microsoft Dynamics NAV and was created specifically for Feeding America to meet the unique needs of food banking."
      },
      {
          "Term:": "Certified in Food Resources",
          "Definition:": "Service marked title which indicates that a national office employee or network staff member has successfully completed all three levels of the CFR curriculum which resides on Feeding America University."
      },
      {
          "Term:": "CFR",
          "Definition:": "This term has two distinct definitions: a. Code of Federal Regulations or b. Certified in Food Resources"
      },
      
      {
          "Term:": "CGA",
          "Definition:": "Charitable Gift Annuity"
      },
      {
          "Term:": "Charitable Gift Annuity (CGA)",
          "Definition:": "A gift vehicle that falls in the category of Planned Giving. It involves a contract between a donor and a charity, whereby the donor transfers cash or property to the charity in exchange for a partial tax deduction and a lifetime stream of annual income from the charity. When the donor dies, the charity keeps the gift.  The amount of the income stream is determined by many factors, including the donor's age and the policy of the charity."
      },
      {
          "Term:": "CGA",
          "Definition:": "A gift vehicle that falls in the category of Planned Giving. It involves a contract between a donor and a charity, whereby the donor transfers cash or property to the charity in exchange for a partial tax deduction and a lifetime stream of annual income from the charity. When the donor dies, the charity keeps the gift.  The amount of the income stream is determined by many factors, including the donor's age and the policy of the charity."
      },
      {
          "Term:": "Charitable Lead Trust (CLT)",
          "Definition:": "Charitable lead trusts make payments, either of a fixed amount or a percentage of trust principal, to a charity during its term. At the end of the trust term, the remainder can either go back to the donor or to heirs named by the donor. The donor may sometimes claim a charitable income tax deduction or a gift/estate tax deduction for making a lead trust gift, depending on the type of a charitable lead trust."
      },
      {
          "Term:": "CLT",
          "Definition:": "Charitable lead trusts make payments, either of a fixed amount or a percentage of trust principal, to a charity during its term. At the end of the trust term, the remainder can either go back to the donor or to heirs named by the donor. The donor may sometimes claim a charitable income tax deduction or a gift/estate tax deduction for making a lead trust gift, depending on the type of a charitable lead trust."
      },
      {
          "Term:": "Charitable Remainder Trust ",
          "Definition:": "A trust funded with assets by a donor, with an income beneficiary and a remainder beneficiary. The donor (or other designated individual) is the income beneficiary, and receives an income stream for life (or a term of years), based on the value of trust assets and the pay-out rate. The nonprofit is the remainder beneficiary and receives the remainder of the trust upon the death of the income beneficiary, or at the end of the term of years."
      },
      {
          "Term:": "CRT",
          "Definition:": "Charitable Remainder Trust. A trust funded with assets by a donor, with an income beneficiary and a remainder beneficiary. The donor (or other designated individual) is the income beneficiary, and receives an income stream for life (or a term of years), based on the value of trust assets and the pay-out rate. The nonprofit is the remainder beneficiary and receives the remainder of the trust upon the death of the income beneficiary, or at the end of the term of years."
      },
      {
          "Term:": "CHEP Pallet",
          "Definition:": "A pallet owned by the CHEP company and is the responsibility of the possessor.  The pallet must be used for shipment to another CHEP pallet enroller or be returned.  Also known as a blue pallet."
      },
      {
          "Term:": "Child and Adult Care Food Program ",
          "Definition:": "A federal program that provides meals and snacks to children in public or private nonprofit child care centers and Head Start programs; and also to adults in nonresidential adult day care centers.  CACFP also provides meals to children residing in homeless shelters, as well as snacks and suppers through after school care programs. http://www.fns.usda.gov/cnd/Care/CACFP/cacfpfaqs.htm"
      },
      {
          "Term:": "CACFP",
          "Definition:": "A federal program that provides meals and snacks to children in public or private nonprofit child care centers and Head Start programs; and also to adults in nonresidential adult day care centers.  CACFP also provides meals to children residing in homeless shelters, as well as snacks and suppers through after school care programs. http://www.fns.usda.gov/cnd/Care/CACFP/cacfpfaqs.htm"
      },
      {
          "Term:": "Child Nutrition Act",
          "Definition:": "The Child Nutrition Act and the National School Lunch Act are the two pieces of authorizing legislation for the child nutrition and Women, Infants and Children (WIC) programs.  http://www.usda.gov/wps/portal/usda/usdahome"
      },
     
      {
          "Term:": "Child Nutrition Programs",
          "Definition:": "The five U.S. Department of Agriculture (USDA) domestic food assistance programs that primarily serve the nutritional needs of children.  These programs include the National School Lunch Program, the School Breakfast Program, the Summer Food Service Program, the Child and Adult Care Food Program, and the Special Milk Program. Child nutrition programs focus on increasing access to nutritious food such as fresh fruits and vegetables, and milk for low-income children. Frequently, state funded child nutrition programs involve increasing access to these foods at schools or farmers’ markets. State funds may also be appropriated to supplement federal child nutrition programs. http://www.usda.gov/wps/portal/usda/usdahome"
      },
     
      {
          "Term:": "Choice System",
          "Definition:": "An online site exclusive to Feeding America network  members where the national office posts all available product loads to its members.  Members are able to login and bid on the loads they want to purchase. Auctions are held twice daily to determine winning members."
      },
      {
          "Term:": "Clean",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Household Cleaning Products such as Detergent, Cleanser, Bleach, Fabric Softener."
      },
      {
          "Term:": "Cleaning Chemicals",
          "Definition:": "Chemical formulations used to remove biological, chemical, or physical contaminants."
      },
      {
          "Term:": "Client Survey",
          "Definition:": "Of the two survey components of the Hunger Study, the Client Survey focuses on obtaining data on emergency food recipients through face-to- face interviews at emergency feeding programs.  For each sampled program of a participating food bank, data collectors interview clients selected through a randomization procedure developed specifically for that program by the research firm."
      },
     
      {
          "Term:": "CLT",
          "Definition:": "Charitable Lead Trust"
      },
      {
          "Term:": "Closed BackPack Site",
          "Definition:": "A closed site has ceased operations forever under current management."
      },
      {
          "Term:": "Closed Dated",
          "Definition:": "An expiration date that is displayed and legible to consumers."
      },
      {
          "Term:": "Closed Enrolled Site",
          "Definition:": "A site that is open only to enrolled children, as opposed to the community at large, and where at least 50 percent of the enrolled children at the site are eligible for free or reduced-price school meals under the National School Lunch Program (NSLP) or the School Breakfast Program (SBP).  See Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Cluster",
          "Definition:": "A group of members that voluntarily agree to form a coalition to handle processing of products donated in less than truckloads (LTL) and full truckloads (FTL). Donations are offered, allocated and receipted through the cluster head.  See Cluster Head; Centralized Cluster; Decentralized Cluster. (From the Member Purchasing Program Manual)  The formalized term for a network member group as described in the member contract.  The cluster structure and formality is associated with donations and the Choice system.  We have deliberately moved away from this term when referring to joint purchasing (Food Sharing Cooperatives or FSCs), in order to emphasize the absence of formality required when collaboratively purchasing.  No inter-food bank contracts or commitments are required to split a full load order via the national office or with any other vendor."
      },
      
      {
          "Term:": "Cluster Head",
          "Definition:": "The member or individual within a cluster of food banks that is responsible for the cluster’s product donation communication and paperwork."
      },
      {
          "Term:": "Code",
          "Definition:": "(As defined in the Feeding America Member Contract) Internal Revenue Code."
      },
      {
          "Term:": "Code Dating",
          "Definition:": "Coded information on product containers that includes date of packaging."
      },
      {
          "Term:": "Collaboration",
          "Definition:": "A cooperative arrangement in which two or more individuals work together towards a common goal."
      },
      {
          "Term:": "Commissary",
          "Definition:": "A Commissary is a 501(c)(3) agency involved in the centralized preparation of meals from donated product provided by a Feeding America network member, for direct distribution to another 501(c)(3) agency that serves the clients."
      },
     
      {
          "Term:": "Commodities",
          "Definition:": "Shorthand for U.S. Department of Agriculture (USDA) commodities that are distributed to people in need through programs such as The Emergency Food Assistance Program (TEFAP), the Food Distribution Program on Indian Reservations (FDPIR), and the Commodity Supplemental Food Program (CSFP).  http://www.usda.gov/wps/portal/usdahome"
      },
      {
          "Term:": "Commodity Supplemental Food Program",
          "Definition:": "A federal program that targets specific at-risk populations.  CSFP works to improve the health of low-income pregnant and breastfeeding women, other mothers up to one year postpartum, infants, children up to age six, and elderly people at least 60 years of age, by providing supplementary U.S. Department of Agriculture (USDA) commodity foods containing nutrients typically lacking in the diets of the target populations. Administered by CSFP state agencies and Indian Tribal Organizations (ITOs) that receive commodity foods and funds for administrative costs from the USDA.  http://www.fns.usda.gov/fdd/programs/csfp"
      },
      {
          "Term:": "CSFP",
          "Definition:": "Commodity Supplemental Food Program. A federal program that targets specific at-risk populations.  CSFP works to improve the health of low-income pregnant and breastfeeding women, other mothers up to one year postpartum, infants, children up to age six, and elderly people at least 60 years of age, by providing supplementary U.S. Department of Agriculture (USDA) commodity foods containing nutrients typically lacking in the diets of the target populations. Administered by CSFP state agencies and Indian Tribal Organizations (ITOs) that receive commodity foods and funds for administrative costs from the USDA.  http://www.fns.usda.gov/fdd/programs/csfp"
      },
      {
          "Term:": "Community Food and Nutrition Program",
          "Definition:": "A federal grant program administered by the Department of Health and Human Services (HHS) that funds activities such as coordinating private and public food assistance resources to better serve low-income populations, assisting low-income communities in identifying potential sponsors of child nutrition programs, and developing innovative state and local approaches to meet the nutrition needs of low-income people.  http://www.hhs.gov/"
      },
      {
          "Term:": "CFNP",
          "Definition:": "A federal grant program administered by the Department of Health and Human Services (HHS) that funds activities such as coordinating private and public food assistance resources to better serve low-income populations, assisting low-income communities in identifying potential sponsors of child nutrition programs, and developing innovative state and local approaches to meet the nutrition needs of low-income people.  http://www.hhs.gov/"
      },
      {
          "Term:": "Common Carrier",
          "Definition:": "A carrier that transports goods at any time to a location for any shipper."
      },
      {
          "Term:": "Community Kitchen",
          "Definition:": "A training program that provides culinary and job-skills training to unemployed or underemployed low-income men and women and assists them with job placement.  Training is in food safety and sanitation, using a recognized curriculum, and offers the opportunity to take the local health department or ServSafe® certification exam. Food prepared in the program is used to feed the needy, with meals prepared by the students."
      },
      
      {
          "Term:": "Communities of Practice (CoP)",
          "Definition:": "A network of peers with diverse skills and experience in an area of practice or profession.  These groups are formed to allow their members to share information and learn from one another."
      },
      {
          "Term:": "CoP",
          "Definition:": "Communities of Practice. A network of peers with diverse skills and experience in an area of practice or profession.  These groups are formed to allow their members to share information and learn from one another."
      },
      {
          "Term:": "Competitive Foods",
          "Definition:": "Refers to food and beverages available in schools that are not served through federally-reimbursed child nutrition programs. These foods include items available through à la carte lines, vending machines, snack bars, student stores and fundraisers."
      },
      {
          "Term:": "Competitive Grants",
          "Definition:": "Grants that require members to compete against each other for limited funds by submitting a proposal or application to be considered."
      },
      {
          "Term:": "Condiments",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Spice/Condiment/Sauce such as Herbs, Salt, Sugar, Mixes, Vinegar, Sauces, Extracts, Mustard, Syrup, Gravy, Jelly, Salad Oil."
      },
      {
          "Term:": "Congregate Meal Program",
          "Definition:": "A program that serves meals at a community location, such as a senior center or a soup kitchen.  Congregate meal programs are often supported by nutrition programs for the elderly, and some states also use funds from the Social Services Block Grant to support congregate meal programs."
      },
      {
          "Term:": "Congregate Site",
          "Definition:": "A facility that serves meals on its premises.  Includes senior meal sites, day care centers, group homes and soup kitchens."
      },
      {
          "Term:": "Contamination",
          "Definition:": "Process by which dust, dirt, chemicals, filth, birds, insects, rodents or other physical objects come in contact with a product, rendering it unclean or impure and therefore unfit for human consumption."
      },
      {
          "Term:": "Continuous School Calendar",
          "Definition:": "A situation in which all or part of the student body of a school is: On vacation for periods of 15 continuous school days or more during October through April, and In attendance at regularly scheduled classes during most of the period of May through September. See Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      
      {
          "Term:": "Contract Carrier",
          "Definition:": "A carrier that does not serve the general public, but conducts its business on a selective basis, charging customized rates for its services. It generally serves a limited number of shippers under specific contractual arrangements."
      },
      {
          "Term:": "Cooler",
          "Definition:": "A category of products typically merchandised with or close to the dairy department and that are warehoused and distributed through the retailer or wholesaler warehousing system, rather than coming from a producing plant."
      },
      {
          "Term:": "Constituent Relationship Management",
          "Definition:": "A system for managing relationships with third-parties. The system often includes contact information, chronological notes, mailing list  management and relationship mapping.  Specific versions may be designed for donor management, advocate management and vendor management. Also known as Customer Relationship Management."
      },
      {
          "Term:": "CRM",
          "Definition:": "Constituent Relationship Management. A system for managing relationships with third-parties. The system often includes contact information, chronological notes, mailing list  management and relationship mapping.  Specific versions may be designed for donor management, advocate management and vendor management. Also known as Customer Relationship Management."
      },
      {
          "Term:": "Consumer Packaged Goods",
          "Definition:": "A manufacturer of dry, refrigerated or frozen product that may or may not be in the food and grocery industry.  For example, both General Mills (Cheerios, Old El Paso, Green Giant) and Panasonic (batteries, headphones, CDs) are CPG manufacturers."
      },
      {
          "Term:": "CPG",
          "Definition:": "A manufacturer of dry, refrigerated or frozen product that may or may not be in the food and grocery industry.  For example, both General Mills (Cheerios, Old El Paso, Green Giant) and Panasonic (batteries, headphones, CDs) are CPG manufacturers."
      },
      {
          "Term:": "Core Budget",
          "Definition:": "The core budget represents our most basic expense needs and is our highest priority for fundraising.  Budget managers have permission to spend as needed (unless there is an executive team decision to reduce budgets).  The core budget typically includes costs for Feeding America operations, and expenses are likely to be carried over year to year."
      },
      {
          "Term:": "Core Budget Plus",
          "Definition:": "The core plus budget includes expenses that are aligned with our strategic plan and campaign priorities but are incremental to our core budget, typically programmatic expenses and member grants.  Core plus spending is contingent on fundraising, and fundraisers have permission to raise these funds.  Until funds are raised, core plus expenses cannot be incurred. Only the executive team can release core plus funds for spending."
      },
      
      {
          "Term:": "Corporate Inspection Team",
          "Definition:": "A volunteer group of food industry inspectors who monitor Feeding America members and report its findings to Feeding America.  Also known as the GMA (Grocery Manufacturers Association) Food Bank Committee."
      },
      {
          "Term:": "CIT",
          "Definition:": "Corporate Inspection Team. A volunteer group of food industry inspectors who monitor Feeding America members and report its findings to Feeding America.  Also known as the GMA (Grocery Manufacturers Association) Food Bank Committee."
      },
      {
          "Term:": "Correction",
          "Definition:": "The food bank’s modification, relabeling, or destruction of adulterated or misbranded product.  See Adulterated."
      },
      {
          "Term:": "Corrections Partnerships",
          "Definition:": "Corrections partnerships can help food banks save on labor costs as well as provide vocational training for inmates. Food banks can partner with corrections institutions on a variety of initiatives, such as cannery programs, planting and harvesting crops on state owned land, and gleaning fields after the first harvest."
      },
      {
          "Term:": "Cost",
          "Definition:": "Expenses incurred to provide a service or product to a customer. For example, picking and packing is a cost incurred by a wholesaler to deliver a mixed load to a food bank.  (In the Member Purchasing Program Manual, cost refers to the “delivered” cost of food.)"
      },
      
      {
          "Term:": "Costs of Obtaining Food",
          "Definition:": "Costs related to obtaining food for consumption by children (in the Summer Food Service Program). Such costs may include, in addition to the purchase price of agricultural commodities and other food, the cost of processing, distributing, transporting, storing, or handling any food purchased for, or donated to, the program. http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Council On Volunteerism",
          "Definition:": "A committee of volunteer administrators from around the network that develops and integrates volunteer programs."
      },
      {
          "Term:": "COV",
          "Definition:": "Council On Volunteerism. A committee of volunteer administrators from around the network that develops and integrates volunteer programs."
      },
      {
          "Term:": "CRC",
          "Definition:": "Campaign Resource Center"
      },
      {
          "Term:": "Critical Control Point",
          "Definition:": "A step where food safety hazards are eliminated, or reduced to acceptable levels; those for which control is essential for food safety."
      },
      {
          "Term:": "Critical Limits",
          "Definition:": "Measurable values based on scientific criteria that establish food safety parameters."
      },
      {
          "Term:": "Cross Contamination",
          "Definition:": "The transfer of contaminants (physical, chemical, or biological) from one surface or food to another."
      },
      {
          "Term:": "Cross Docking",
          "Definition:": "A practice in logistics of unloading materials from an incoming truck and re-loading these materials on an outbound truck for distribution, with little or no use of warehouse storage."
      },
      
      
      {
          "Term:": "Cube Utilization",
          "Definition:": "Refers to the use of space within a defined storage area (trailer, container); generally calculated as a percentage of total useable space.  For example, if someone were to say “the trailer is 90% cubed out,” he/she would be stating that 90% of the useable space of the trailer is currently occupied.  It is really known as a cubic foot. The formula for a cubic foot is:  length x width x height."
      },
      
      {
          "Term:": "Cultivation",
          "Definition:": "Step three in the relationship management cycle. Cultivation entails the sometimes lengthy process of establishing a plan to strengthen the relationship between a donor or prospect and the Feeding America network."
      },
      {
          "Term:": "Current Income",
          "Definition:": "Income received during the month prior to application for free meals. If such income does not accurately reflect the household’s annual income, income must be based on the projected annual household income. If the prior year’s income provides an accurate reflection of the household’s current annual income, the prior year may be used as a base for the projected annual income.  See Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
     
      {
          "Term:": "Dairy",
          "Definition:": "·     A place that produces milk and milk by-products, or Product Type code for Yogurt, Cheese, Milk, Butter, Sour cream Ice Cream"
      },
     
      {
          "Term:": "Damage Recovery System (DRS)",
          "Definition:": "A company that recoups damaged grocery products from retailers and primarily sells the damaged goods to the secondary market."
      },
      {
          "Term:": "DRS",
          "Definition:": "Damage Recovery System. A company that recoups damaged grocery products from retailers and primarily sells the damaged goods to the secondary market."
      },
      {
          "Term:": "Dead Head",
          "Definition:": "Moving an empty truck or container."
      },
      {
          "Term:": "Deadstack",
          "Definition:": "Cases of product that are loaded onto a truck from floor to ceiling, to fit as much product as possible.  Also known as “cubing out” the trailer.  This method is used specifically for lightweight, high volume products such as potato chips."
      },
      {
          "Term:": "Decentralized Cluster",
          "Definition:": "A group of members that voluntarily agree to form a coalition to handle the processing of donated products, in which the size of the offer determines the process.  Donations of less than truckloads (LTL) are offered, allocated and receipted by the local member.  All full truckloads (FTL) are offered, allocated and receipted by the cluster head.  See Cluster, Cluster Head; Centralized Cluster."
      },
     
      {
          "Term:": "Decentralized Donor",
          "Definition:": "A company that allows its plants or distribution centers to make product donation decisions."
      },
      {
          "Term:": "Delivered Pricing",
          "Definition:": "A price offered by a seller when freight costs to the buyer’s or food bank’s location are included.  This differs from Free on Board (F.O.B.) pricing, where pick up is required by either a food bank truck or third-party freight provider."
      },
      {
          "Term:": "Delivery Fee",
          "Definition:": "Effective August 2008, the delivery fee will be capped at 10 cents per pound, up from the previous cap of 6 cents per pound."
      },
      {
          "Term:": "Demonstration Project",
          "Definition:": "Demonstration projects are opportunities to test new approaches to increase SNAP participation that fall outside of the federal regulations that govern the SNAP program.  Regional FNS offices work with state agencies and community-based partners to develop these projects, but final authority to issue the waiver required to implement a demonstration project rests with FNS Headquarters.  These are generally time-limited pilots that require detailed data collection throughout the duration of the project and a formal program evaluation at its close."
      },
      {
          "Term:": "Depth of Recall",
          "Definition:": "The level of product distribution to which the recall is to extend. The agency and client or user level includes the consumer in addition to any intermediate distribution level."
      },
      {
          "Term:": "Designated Net Assets",
          "Definition:": "(As defined by the CFO best practices team on Operating Reserves) Equal to the asset book value, less accumulated depreciation and any related long-term debt.  These assets are excluded from available unrestricted net assets in the reserves calculation."
      },
      {
          "Term:": "Designation",
          "Definition:": "An internal decision by Feeding America national office staff regarding how a gift will be allocated.  Unrestricted gifts may be designated to projects where the funds are most needed. Restricted gifts may be designated for specific projects that are within the boundaries of the conditions or purposes that the donor directs."
      },
      {
          "Term:": "Dessert",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Cakes, Pies, Pudding, Frozen Confections."
      },
      {
          "Term:": "Direct Accounts",
          "Definition:": "(As defined in the Food Safety and Handling Manual, Recall Program) Those parties who received shipments of the recalled product directly from the recalling firm (i.e., the food bank)."
      },
      {
          "Term:": "Direct Certification",
          "Definition:": "A process by which categorically eligible children are automatically certified to receive free meals and snacks through the child nutrition programs."
      },
     
      {
          "Term:": "Direct Mail",
          "Definition:": "Fundraising and marketing through the U.S. postal system, targeting specific locations and audiences."
      },
      {
          "Term:": "Direct Service",
          "Definition:": "Programs administered by the member that directly serve the individual by providing food and grocery products and/or client support services, at the member location, rather than at one of the associated charitable human service agencies."
      },
      {
          "Term:": "Direct Store Delivery (DSD)",
          "Definition:": "Product that is delivered directly to retail stores by the manufacturer, bypassing the retailer’s distribution center.  Soda, chips and bread vendors are often DSD suppliers."
      },
      {
          "Term:": "DSD",
          "Definition:": "Product that is delivered directly to retail stores by the manufacturer, bypassing the retailer’s distribution center.  Soda, chips and bread vendors are often DSD suppliers."
      },
      {
          "Term:": "Disaster Contact Information",
          "Definition:": "A form that is mailed out annually by the Feeding America national office to capture updated contact information from each member, and to collect data on network staff that could be deployed to another location to assist during times of large-scale disaster response. This information is highly confidential and is used only for major disasters."
      },
      {
          "Term:": "Disaster Event",
          "Definition:": "An event that is considered catastrophic in nature and disrupts normal operations for an extended period of time. Typically, a disaster event can be permanent or last up to a period of several months. During a disaster, business operations usually have to be recovered at an off-site location. Examples of a disaster event include fires, tornadoes, hurricanes, etc."
      },
      
      {
          "Term:": "Disaster Food Stamp Program",
          "Definition:": "Special food stamp program whereby benefits are provided to persons who suffer certain losses due to natural or man‐made disasters. Normal eligibility rules are relaxed and benefits are provided at the maximum household rate for one month.  http://www.fns.usda.gov/snap/"
      },
      
      {
          "Term:": "Disaster Recovery Plan",
          "Definition:": "A set of activities and programs designed to restore the entity’s critical Information Technology (IT) capabilities. The Disaster Recovery Plan is intended to be an Operations Manual for IT recovery. It contains detailed recovery procedures based on designated disruption levels and specific Disaster Recovery teams. It also contains all the necessary contact and call tree information needed to facilitate the plan."
      },
      {
          "Term:": "Disaster Relief Plan",
          "Definition:": "A documented process for how an organization plans to respond in the event of a disaster. The plan should cover preparedness, planning, response, and recovery functions of the organization."
      },
      {
          "Term:": "Disclosure",
          "Definition:": "Individual children’s program eligibility information obtained through the free and reduced price meal eligibility process that is revealed or used for a purpose other than that for which the information was obtained. The term refers to access, release, or transfer of personal data about children by means of print, tape, microfilm, microfiche, electronic communication or any other means."
      },
      
      {
          "Term:": "Discussion Forum",
          "Definition:": "An in-person or electronic forum for staff or individuals to exchange ideas, post questions, and offer answers and help on a topic of common interest."
      },
      {
          "Term:": "Distribution Center",
          "Definition:": "A warehouse for finished goods; a facility from which orders are filled."
      },
      {
          "Term:": "DC",
          "Definition:": "Distribution Center. A warehouse for finished goods; a facility from which orders are filled."
      },
      {
          "Term:": "Distributor",
          "Definition:": "A business that is in the middle of a supply channel.  Distributors buy and sell finished goods."
      },
      {
          "Term:": "Dock",
          "Definition:": "The sorting or staging platform where shipments are loaded or unloaded."
      },
      
      {
          "Term:": "Donate",
          "Definition:": "From the Bill Emerson Good Samaritan Food Donation Act: Donate:  The term \"donate\" means to give without requiring anything of monetary value from the recipient, except that the term shall include giving by a nonprofit organization to another nonprofit organization, notwithstanding that the donor organization has charged a nominal fee to the donor organization, if the ultimate recipient or user is not required anything of monetary value."
      },
      
      {
          "Term:": "Donor",
          "Definition:": "Those who make product/financial donations on a local, regional or national level, including manufacturers, retailers, wholesalers, distributors, and agricultural companies, or (From the Relationship Management Handbook) An individual or family foundation that makes a financial commitment to the Feeding America network"
      },
     
      {
          "Term:": "Donor File",
          "Definition:": "A file containing all information about a donor, including history of past donations and correspondence. All forms of contact should be placed in the file for future reference."
      },
      {
          "Term:": "Donor Intent",
          "Definition:": "(As defined in the Donor Fund Management Handbook) The explicit intentions of a donor regarding how their gift to Feeding America should be used. (As defined in the Product Sourcing initial glossary) Used when discussing product donations that are unique, require special handling or work per the donor, and other donor stewardship situations."
      },
      
      {
          "Term:": "Drop",
          "Definition:": "A stop required by a commercial trailer for loading and unloading purposes.  There is usually an additional fee charged for each drop."
      },
      {
          "Term:": "Drop Point",
          "Definition:": "A facility or lot used by a member that is delivering goods to multiple agencies in an outlying area.  Agencies are responsible for the pick up from the drop point, rather than from the member warehouse."
      },
     
      {
          "Term:": "Dough",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Uncooked Dough."
      },
      {
          "Term:": "Dressing",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Salad dressing, Mayonnaise."
      },
      {
          "Term:": "Drug Enforcement Administration",
          "Definition:": "The mission of the Drug Enforcement Administration (DEA) is to enforce the U.S. controlled substances laws and regulations, and to bring to the criminal and civil justice system, or any other competent jurisdiction, those organizations and principal members of organizations involved in growing, manufacturing, or distributing controlled substances appearing in or destined for illicit traffic in the U.S.  The DEA also recommends and supports non-enforcement programs aimed at reducing the availability of illicit controlled substances on the domestic and international markets."
      },
      {
          "Term:": "DEA",
          "Definition:": "Drug Enforcement Administration. The mission of the Drug Enforcement Administration (DEA) is to enforce the U.S. controlled substances laws and regulations, and to bring to the criminal and civil justice system, or any other competent jurisdiction, those organizations and principal members of organizations involved in growing, manufacturing, or distributing controlled substances appearing in or destined for illicit traffic in the U.S.  The DEA also recommends and supports non-enforcement programs aimed at reducing the availability of illicit controlled substances on the domestic and international markets."
      },
      {
          "Term:": "Dry",
          "Definition:": "Product that does not need to be refrigerated or frozen.  Also known as shelf-stable or ambient."
      },
      {
          "Term:": "D-SNAP",
          "Definition:": "Disaster Supplemental Nutrition Assistance Program"
      },
      {
          "Term:": "Earned Income Tax Credit",
          "Definition:": "A tax credit that low-income households receive when they file their federal tax return.  Low-income households are eligible to receive a  portion of their payroll and income taxes paid during the year.  The benefits are calculated based on household size and income.  For the 2007 tax year, a household with one qualifying child could receive a maximum of $2,853; a household with two or more qualifying children could receive a maximum of $4,716; persons and couples with no qualifying children could receive a maximum of $428."
      },
      {
          "Term:": "EITC",
          "Definition:": "Earned Income Tax Credit. A tax credit that low-income households receive when they file their federal tax return.  Low-income households are eligible to receive a  portion of their payroll and income taxes paid during the year.  The benefits are calculated based on household size and income.  For the 2007 tax year, a household with one qualifying child could receive a maximum of $2,853; a household with two or more qualifying children could receive a maximum of $4,716; persons and couples with no qualifying children could receive a maximum of $428."
      },
      {
          "Term:": "Economic Research Service",
          "Definition:": "The division within the U.S. Department of Agriculture (USDA) that conducts research on programs and issues under the USDA’s jurisdiction. In terms of hunger, the ERS conducts research and analysis on food security levels as well as various aspects of administration and implementation of federal nutrition and commodity distribution programs. http://www.ers.usda.gov/"
      },
      {
          "Term:": "ERS",
          "Definition:": "Economic Research Service. The division within the U.S. Department of Agriculture (USDA) that conducts research on programs and issues under the USDA’s jurisdiction. In terms of hunger, the ERS conducts research and analysis on food security levels as well as various aspects of administration and implementation of federal nutrition and commodity distribution programs. http://www.ers.usda.gov/"
      },
      {
          "Term:": "Effectiveness Check Level",
          "Definition:": "(As defined in the Food Safety and Handling Manual, Recall Program)  An alphabetical term representing the extent to which effectiveness checks will be made within the distribution chain. Level A – 100% of the total number of parties to be contacted: Level B – any percentage of the total number of parties to be contacted is greater than 10% and less than 100%; this is determined on a case-by-case basis: Level C – 10% of the total number of parties to be contacted: Level D – 2% of the total number of parties to be contacted: Level E – No checks"
      },
     
      {
          "Term:": "Effectiveness Checks",
          "Definition:": "(As defined in the Food Safety and Handling Manual, Recall Program)  The actions taken to verify that all parties, at the recall depth specified by the program, have been notified and taken the appropriate action. The food bank may contact parties by phone calls, letters, and/or personal visits."
      },
     
      
      {
          "Term:": "Electronic Benefits Transfer",
          "Definition:": "The method by which food stamps and other benefits are distributed via an electronic debit card.  Some states also use EBT to distribute benefits under Women, Infants and Children (WIC) and other programs."
      },
      {
          "Term:": "Emergency Bag",
          "Definition:": "An assortment of food products distributed by food pantries to assist people in the event of a crisis."
      },
      {
          "Term:": "Emergency Box",
          "Definition:": "An assortment of food products distributed by food pantries to assist people in the event of a crisis."
      },
      {
          "Term:": "Emergency Food and Shelter Program",
          "Definition:": "Commonly referred to as the “FEMA Program.”  The Emergency Food and Shelter Program was created by Congress in 1983 to help meet the needs of hungry and homeless people throughout the U.S. and its territories by allocating funds for the provision of food and shelter. The program is governed by a National Board which uses a formula involving population, poverty, and unemployment data to determine the eligibility of a civil jurisdiction to receive EFSP funds. http://www.fema.gov/government/grant/efs.shtm"
      },
      {
          "Term:": "EFSP",
          "Definition:": "Commonly referred to as the “FEMA Program.”  The Emergency Food and Shelter Program was created by Congress in 1983 to help meet the needs of hungry and homeless people throughout the U.S. and its territories by allocating funds for the provision of food and shelter. The program is governed by a National Board which uses a formula involving population, poverty, and unemployment data to determine the eligibility of a civil jurisdiction to receive EFSP funds. http://www.fema.gov/government/grant/efs.shtm"
      },
      {
          "Term:": "Emergency Food Programs",
          "Definition:": "Charitable feeding programs whose services are provided to clients that are typically in short-term need of emergency assistance."
      },
      {
          "Term:": "Emergency Food Pantries",
          "Definition:": "Charitable feeding programs that distribute non-prepared foods and other grocery products to needy clients, who then prepare and use these items where they live.  Food is distributed on a short-term or emergency basis until clients are able to meet their food needs."
      },
      {
          "Term:": "Emergency Food Stamps",
          "Definition:": "Food stamp benefits issued to persons with no income or assets. These benefits are issued within seven days, rather than the standard thirty days. http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "Emergency Operations Center (EOC)",
          "Definition:": "A protected facility where emergency response agencies gather to coordinate an emergency response. The EOC is responsible for coordinating and supporting the efforts of on-site responders, monitoring a developing situation, and collecting and disseminating critical information for government officials, other emergency managers, and the general public."
      },
      {
          "Term:": "EOC",
          "Definition:": "Emergency Operations Center. A protected facility where emergency response agencies gather to coordinate an emergency response. The EOC is responsible for coordinating and supporting the efforts of on-site responders, monitoring a developing situation, and collecting and disseminating critical information for government officials, other emergency managers, and the general public."
      },
      {
          "Term:": "Emergency Shelters",
          "Definition:": "Charitable program that provides shelter and serves one or more meals a day on a short-term basis to low-income clients in need.  The shelter may be the primary or secondary purpose of the service."
      },
     
      {
          "Term:": "Emergency Situation",
          "Definition:": "An emergency situation is either an interruption event or a disaster event that disrupts normal business operations.  See Interruption Event; Disaster Event; Business Continuity Plan."
      },
     
      {
          "Term:": "Emergency Soup Kitchens",
          "Definition:": "Charitable feeding programs that provide prepared meals served at the kitchen to needy clients who do not reside on the premises.  In some instances, kitchens may also provide lighter meals or snacks, such as sandwiches, for clients to take with them when the kitchen is closed."
      },
      {
          "Term:": "Emergency Support Function",
          "Definition:": "The Emergency Support Function of the Federal Emergency Management Agency (FEMA) National Response Framework that addresses human services, mass care, emergency assistance, and housing issues during times of disaster.  FEMA is primarily responsible for the coordination of this function.  The Southern Baptists Convention, the American Red Cross, the Salvation Army and Feeding America all play critical roles as support agencies within this annex to the National Response Framework."
      },
      {
          "Term:": "ESF",
          "Definition:": "Emergency Support Function The Emergency Support Function of the Federal Emergency Management Agency (FEMA) National Response Framework that addresses human services, mass care, emergency assistance, and housing issues during times of disaster.  FEMA is primarily responsible for the coordination of this function.  The Southern Baptists Convention, the American Red Cross, the Salvation Army and Feeding America all play critical roles as support agencies within this annex to the National Response Framework."
      },
      {
          "Term:": "End User (or Client)",
          "Definition:": "The recipient of products from the Feeding America network and agencies."
      },
      {
          "Term:": "Client",
          "Definition:": "The recipient of products from the Feeding America network and agencies."
      },
      {
          "Term:": "Enrichment Activities",
          "Definition:": "Activities that increase the well-being of a child with the addition of different program ingredients. These include educational, recreational and socialization activities provided for children at a Kids Cafe site."
      },
      
      {
          "Term:": "Entry Level Outreach",
          "Definition:": "Food banks conducting minimal Supplemental Nutrition Assistance Program (SNAP) outreach (i.e., distributing materials). http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "Ephedrine",
          "Definition:": "This drug is a member of a large family of pharmacological compounds called sympathomimetics.  Sympathomimetics mimic the effects of epinephrine and norepinephrine, which occur naturally in the human body. Multiple studies demonstrate that dietary supplements containing ephedrine alkaloids, like other sympathomimetics, raise blood pressure and increase heart rate. These products expose users to several risks, including the consequences of increased blood pressure (e.g., serious adverse events such as stroke, heart attack, and death) and increased morbidity and mortality from worsened heart failure and pro-arrhythmic effects."
      },
      {
          "Term:": "ephedrine",
          "Definition:": "This drug is a member of a large family of pharmacological compounds called sympathomimetics.  Sympathomimetics mimic the effects of epinephrine and norepinephrine, which occur naturally in the human body. Multiple studies demonstrate that dietary supplements containing ephedrine alkaloids, like other sympathomimetics, raise blood pressure and increase heart rate. These products expose users to several risks, including the consequences of increased blood pressure (e.g., serious adverse events such as stroke, heart attack, and death) and increased morbidity and mortality from worsened heart failure and pro-arrhythmic effects."
      },
      {
          "Term:": "ephedra",
          "Definition:": "This drug is a member of a large family of pharmacological compounds called sympathomimetics.  Sympathomimetics mimic the effects of epinephrine and norepinephrine, which occur naturally in the human body. Multiple studies demonstrate that dietary supplements containing ephedrine alkaloids, like other sympathomimetics, raise blood pressure and increase heart rate. These products expose users to several risks, including the consequences of increased blood pressure (e.g., serious adverse events such as stroke, heart attack, and death) and increased morbidity and mortality from worsened heart failure and pro-arrhythmic effects."
      },
      {
          "Term:": "ERP",
          "Definition:": "Enterprise Resource Planning"
      },
      
      {
          "Term:": "Estate Tax",
          "Definition:": "A tax on the value of the property held by an individual at death."
      },
      {
          "Term:": "Estimated Time of Arrival (ETA)",
          "Definition:": "The time when a shipment is expected to reach its destination."
      },
      {
          "Term:": "ETA",
          "Definition:": "Estimated Time of Arrival. The time when a shipment is expected to reach its destination."
      },
      {
          "Term:": "Expanded Food and Nutrition Education Program",
          "Definition:": "A nutrition education program administered through the Cooperative State Research, Education, and Extension agency (CSREES) at the U.S. Department of Agriculture (USDA), which provides low-income individuals with the knowledge and skills to improve their nutritional well-being on a limited budget.   http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "EFNEP",
          "Definition:": "A nutrition education program administered through the Cooperative State Research, Education, and Extension agency (CSREES) at the U.S. Department of Agriculture (USDA), which provides low-income individuals with the knowledge and skills to improve their nutritional well-being on a limited budget.   http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "Experienced Site",
          "Definition:": "A site which, as determined by the state agency, has successfully participated in the program in the prior year.  See Summer Food Service Program (SFSP).  http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Experienced Sponsor",
          "Definition:": "A sponsor who, as determined by the state agency, has successfully participated in the program in the prior year.  See Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Expiration Date",
          "Definition:": "Date at which a perishable product should no longer be consumed."
      },
      {
          "Term:": "Fact Sheet",
          "Definition:": "A printed presentation of data, formatted in a simple and easy to use manner, which concisely covers the key, relevant points of a program, proposal, or idea."
      },
      {
          "Term:": "Family",
          "Definition:": "A group of related or nonrelated individuals who are not residents of an institution or boarding house, but who are living as one economic unit."
      },
      {
          "Term:": "FANS",
          "Definition:": "Feeding America Network Summit"
      },
      {
          "Term:": "Fair Market Value",
          "Definition:": "Food stamp program rules count the fair market value of household assets in determining eligibility for the program.  A fair market value is the price a willing buyer would pay to a willing seller for a piece of property.  It varies with changing economic conditions.  See Supplemental Nutrition Assistance Program."
      },
      {
          "Term:": "FMV",
          "Definition:": "Food stamp program rules count the fair market value of household assets in determining eligibility for the program.  A fair market value is the price a willing buyer would pay to a willing seller for a piece of property.  It varies with changing economic conditions.  See Supplemental Nutrition Assistance Program."
      },
      {
          "Term:": "FBO",
          "Definition:": "Faith-Based Organization"
      },
      {
          "Term:": "Farm Bill",
          "Definition:": "The U.S. Farm Bill is the primary agricultural and food policy tool of the U.S. federal government.  The comprehensive omnibus bill is passed every several years by Congress and deals with agriculture and all other affairs under the purview of the U.S. Department of Agriculture (USDA).  The current farm bill, known as the Food, Conservation, and Energy Act of 2008, replaced the last farm bill, which expired in September 2007. Farms bills can be highly controversial and can impact international trade, environmental preservation, food safety, and the well-being of rural communities internationally.  http://www.usda.gov/wps/portal/usda/usdahome"
      },
      
     
      {
          "Term:": "FB",
          "Definition:": "Food Bank"
      },
      {
          "Term:": "FDPIR Household",
          "Definition:": "Any individual or group of individuals who are currently certified to receive assistance as a household under the Food Distribution Program on Indian Reservations."
      },
      {
          "Term:": "Federal Emergency Management Agency (FEMA)",
          "Definition:": "Now known as the Response and Recovery Directorate of the Department of Homeland Security, FEMA is a directorate within the Department of Homeland Security. FEMA’s mission is to support our citizens and first responders to ensure that as a nation we work together to build, sustain, and improve our capability to prepare for, protect against, respond to, recover from, and mitigate all hazards.  http://www.fema.gov/"
      },
      {
          "Term:": "FEMA",
          "Definition:": "Federal Emergency Management Agency. Now known as the Response and Recovery Directorate of the Department of Homeland Security, FEMA is a directorate within the Department of Homeland Security. FEMA’s mission is to support our citizens and first responders to ensure that as a nation we work together to build, sustain, and improve our capability to prepare for, protect against, respond to, recover from, and mitigate all hazards.  http://www.fema.gov/"
      },
      {
          "Term:": "Federal Employer Identification Number",
          "Definition:": "An ID number assigned to each employer by the IRS to identify that employer’s tax activity and liability."
      },
      {
          "Term:": "FIN",
          "Definition:": "An ID number assigned to each employer by the IRS to identify that employer’s tax activity and liability."
      },
      {
          "Term:": "EIN",
          "Definition:": "An ID number assigned to each employer by the IRS to identify that employer’s tax activity and liability."
      },
     
      {
          "Term:": "Federal Fiscal Year",
          "Definition:": "The federal fiscal year (FFY) runs from October 1-September 30."
      },
      {
          "Term:": "FFY",
          "Definition:": "The federal fiscal year (FFY) runs from October 1-September 30."
      },
      {
          "Term:": "Federal Poverty Level (FPL)",
          "Definition:": "A measure used to determine the household income level for a family to be considered in poverty.  The measurement was developed in 1965 by multiplying the U.S. Department of Agriculture’s economy food plan (predecessor to the Thrifty Food Plan) by three.  The measurement is updated each year based on price increases reflected in the Consumer Price Index.  Also referred to as the poverty level.  http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "FPL",
          "Definition:": "Federal Poverty Level. A measure used to determine the household income level for a family to be considered in poverty.  The measurement was developed in 1965 by multiplying the U.S. Department of Agriculture’s economy food plan (predecessor to the Thrifty Food Plan) by three.  The measurement is updated each year based on price increases reflected in the Consumer Price Index.  Also referred to as the poverty level.  http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "Federal Register",
          "Definition:": "The official daily publication for rules, proposed rules, and notices of Federal agencies and organizations, as well as executive orders and other presidential documents.  http://www.gpoaccess.gov/fr/index.html"
      },
      {
          "Term:": "Feeding America",
          "Definition:": "Online learning system accessed via HungerNet.  FAU provides access to approximately 105 network-specific courses, as well as 86 professional development courses free of charge to both national office staff and network members."
      },
      {
          "Term:": "FA",
          "Definition:": "Feeding America. Online learning system accessed via HungerNet.  FAU provides access to approximately 105 network-specific courses, as well as 86 professional development courses free of charge to both national office staff and network members."
      },
      {
          "Term:": "Feeding America University",
          "Definition:": "Online learning system accessed via HungerNet, which offers more than 100 online training courses across four categories: NAV Ceres, Certification in Food Resource, Disaster Relief, Microsoft products, etc."
      },
      {
          "Term:": "FAU",
          "Definition:": "Feeding America University Online learning system accessed via HungerNet, which offers more than 100 online training courses across four categories: NAV Ceres, Certification in Food Resource, Disaster Relief, Microsoft products, etc."
      },
      {
          "Term:": "Firm Initiated Recall",
          "Definition:": "A recall that is initiated by the food bank without a formal request from a regulatory agency."
      },
      {
          "Term:": "First In First Out (FIFO)",
          "Definition:": "A best management practice for product inventories to ensure stock rotation, where the first unit received of an item is the first one shipped. This helps ensure that the oldest inventory of an item is always the first used."
      },
      {
          "Term:": "FIFO",
          "Definition:": "First In First Out. A best management practice for product inventories to ensure stock rotation, where the first unit received of an item is the first one shipped. This helps ensure that the oldest inventory of an item is always the first used."
      },
      {
          "Term:": "First Line Product",
          "Definition:": "Top quality, manufactured product that is intended for sale to a consumer."
      },
      {
          "Term:": "Fiscal Year",
          "Definition:": "Any 12-month period that an organization uses for accounting purposes. The fiscal year may or may not be the same as the calendar year.  The national office’s fiscal year runs from July 1-June 30.  The federal fiscal year runs from October 1-September 30."
      },
      {
          "Term:": "Fixed Income",
          "Definition:": "Payments received on a regular basis that are not subject to change."
      },
      {
          "Term:": "Flash Frozen",
          "Definition:": "Applies to a product that is frozen quickly and instantly from the production line.  See Individually Quick Frozen."
      },
      {
          "Term:": "Flexible Funds",
          "Definition:": "Flexible funds are state appropriations that food banks and/or state associations of food banks can use as general operating funds. These funds can be spent as the food bank and/or state association deems necessary."
      },
      
      {
          "Term:": "Floor Loaded",
          "Definition:": "Product loaded onto the floor of a truck, as opposed to being placed on a pallet and then loaded."
      },
      
      {
          "Term:": "FOB Pricing",
          "Definition:": "The cost of goods to purchase at the supplier’s location.  The term means “Free on board” or “Freight on board” meaning that the seller will load the goods “on-board” your vessel.  It is an old shipping term (when the vessel was a ship).  The product passed over the rail of the ship on board the buyer’s vessel.  Today, our vessel for food bank deliveries is typically a truck."
      },
      {
          "Term:": "Food",
          "Definition:": "From the Bill Emerson Good Samaritan Food Donation Act: The term \"food\" means any raw, cooked, processed, or prepared edible substance, ice, beverage, or ingredient used or intended for use in whole or in part for human consumption."
      },
     
      {
          "Term:": "Food and Drug Administration",
          "Definition:": "An agency of the U.S. Government, the FDA oversees the safe handling of all food products in the United States except for meat, poultry and egg products, which are regulated by the U.S. Department of Agriculture’s"
      },
      {
          "Term:": "FDA",
          "Definition:": "Food and Drug Administration. Food Safety Inspection Service.  http://www.fda.gov/. An agency of the U.S. Government, the FDA oversees the safe handling of all food products in the United States except for meat, poultry and egg products, which are regulated by the U.S. Department of Agriculture’s"
      },
      {
          "Term:": "Food and Nutrition Service",
          "Definition:": "This service, formerly known as the Food and Consumer Service, administers the nutrition assistance programs of the U.S. Department of Agriculture (USDA). The mission of FNS is to provide children and needy families with better access to food and a more healthful diet through its food assistance programs and comprehensive nutrition education efforts. http://www.fns.usda.gov/fns/"
      },
      {
          "Term:": "FNS",
          "Definition:": "Food and Nutrition Service. This service, formerly known as the Food and Consumer Service, administers the nutrition assistance programs of the U.S. Department of Agriculture (USDA). The mission of FNS is to provide children and needy families with better access to food and a more healthful diet through its food assistance programs and comprehensive nutrition education efforts. http://www.fns.usda.gov/fns/"
      },
      {
          "Term:": "FNSRO",
          "Definition:": "Food and Nutrition Service Regional Office"
      },
      {
          "Term:": "Food Bank",
          "Definition:": "A charitable nonprofit organization that solicits, receives, inventories, stores and distributes donated food and grocery products to charitable agencies that directly serve clients in need. These agencies include churches and qualifying nonprofit 501(c)(3) charitable organizations."
      },
      {
          "Term:": "Food borne Illness",
          "Definition:": "A disease transmitted to people by food.  A food-borne illness outbreak is when two or more people get the same illness after eating the same food."
      },
      {
          "Term:": "Food Broker",
          "Definition:": "An individual or company acting as a sales agent between manufacturers and the wholesale and retail markets."
      },
      {
          "Term:": "Food Contact Surfaces",
          "Definition:": "Any surface in a facility that may come into direct contact with food, food packaging, food equipment and utensils."
      },
      {
          "Term:": "Food Defense",
          "Definition:": "Food defense is the collective term used by regulators to encompass activities associated with protecting the nation's food supply from deliberate or intentional acts of contamination or tampering."
      },
      {
          "Term:": "Food Distribution Program on Indian Reservations (FDPIR)",
          "Definition:": "FDPIR is a federal program that provides commodity foods to low-income households, including the elderly, living on Indian reservations, and to Native American families residing in designated areas near reservations."
      },
      {
          "Term:": "FDPIR",
          "Definition:": "Food Distribution Program on Indian Reservations FDPIR is a federal program that provides commodity foods to low-income households, including the elderly, living on Indian reservations, and to Native American families residing in designated areas near reservations."
      },
      {
          "Term:": "Food Donor",
          "Definition:": "(As defined in the Feeding America Member Contract) An entity or individual that either has donated or may potentially donate food or grocery product to a member or to Feeding America."
      },
      {
          "Term:": "Food Insecurity",
          "Definition:": "The availability of nutritionally adequate and safe foods or the ability to acquire acceptable foods in socially acceptable ways is limited or uncertain."
      },
      {
          "Term:": "Food Insufficiency",
          "Definition:": "The National Health and Nutrition Examination Survey’s (NHANES) measure of whether a family sometimes or often does not have enough food."
      },
      {
          "Term:": "Food Manufacturing Channel Expansion",
          "Definition:": "Initiative to encourage the development of donations from local and regional food manufacturers directly to Feeding America network members.  For example, in 2008, 11,000 food manufacturers were mapped to more than 200 members based upon service areas."
      },
      {
          "Term:": "FMCE",
          "Definition:": "Food Manufacturing Channel Expansion. Initiative to encourage the development of donations from local and regional food manufacturers directly to Feeding America network members.  For example, in 2008, 11,000 food manufacturers were mapped to more than 200 members based upon service areas."
      },
      {
          "Term:": "Food Marketing Institute ",
          "Definition:": "National trade association of retail grocers; very instrumental in the creation and development of Feeding America."
      },{
          "Term:": "FMI",
          "Definition:": "National trade association of retail grocers; very instrumental in the creation and development of Feeding America."
      },
      {
          "Term:": "Foods of Minimal Nutritional Value",
          "Definition:": "FMNV is defined as: (a) In the case of artificially sweetened foods, a food which provides less than five percent of the Reference Daily Intakes (RDI) for each of eight specified nutrients per serving; and (b) in the case of all other foods, a food which provides less than five percent of the RDI for each of eight specified nutrients per 100 calories and less than five percent of the RDI for each of the eight specified nutrients per serving.  The eight nutrients to be assessed for this purpose are – protein, vitamin A, vitamin C, niacin, riboflavin, thiamine, calcium and iron.  The Code of Federal Regulations (CFR) Section 210.11 defines FMNV; Appendix B states foods of minimal nutritional value include: soda water, water ices, chewing gum and certain candies."
      },
      {
          "Term:": "FMNV",
          "Definition:": "Foods of Minimal Nutritional Value/ FMNV is defined as: (a) In the case of artificially sweetened foods, a food which provides less than five percent of the Reference Daily Intakes (RDI) for each of eight specified nutrients per serving; and (b) in the case of all other foods, a food which provides less than five percent of the RDI for each of eight specified nutrients per 100 calories and less than five percent of the RDI for each of the eight specified nutrients per serving.  The eight nutrients to be assessed for this purpose are – protein, vitamin A, vitamin C, niacin, riboflavin, thiamine, calcium and iron.  The Code of Federal Regulations (CFR) Section 210.11 defines FMNV; Appendix B states foods of minimal nutritional value include: soda water, water ices, chewing gum and certain candies."
      },
      {
          "Term:": "Food Pantry",
          "Definition:": "A program that distributes groceries (non-prepared foods) and other basic supplies for off-site use, usually for preparation in the client’s residence."
      },
      {
          "Term:": "Food Policy Council",
          "Definition:": "A group, usually established by a legislative or executive directive, comprised of representatives from diverse food-related sectors that aims to provide advice, recommendations, and information regarding a community’s food system.  Food Policy Councils exist at the state, county, and local level.  The exact powers and responsibilities of Food Policy Councils vary, however many are able to recommend policy or program changes.  Many councils focus on ensuring community food security."
      },
      {
          "Term:": "Food Recovery",
          "Definition:": "The collection of wholesome food for distribution to people in need, sometimes referred to as food rescue."
      },
      {
          "Term:": "Food Rescue",
          "Definition:": "State appropriations designated for soliciting and receiving prepared and/or perishable foods that are, in turn, distributed either directly to low- income people in need, or to charitable human service agencies that provide the food to clients through hunger relief programs."
      },
      
      {
          "Term:": "FRO",
          "Definition:": "Food Rescue Organization"
      },
      {
          "Term:": "Food Research and Action Center",
          "Definition:": "An anti-hunger research and advocacy organization headquartered in Washington, D.C.  Feeding America’s annual spring policy conference is co- hosted with FRAC, and FRAC often works in partnership with Feeding America on public policy issues.  http://www.frac.org"
      },
      {
          "Term:": "FRAC",
          "Definition:": "Food Research and Action Center. An anti-hunger research and advocacy organization headquartered in Washington, D.C.  Feeding America’s annual spring policy conference is co- hosted with FRAC, and FRAC often works in partnership with Feeding America on public policy issues.  http://www.frac.org"
      },
      {
          "Term:": "Food Safety Council",
          "Definition:": "A team comprised of national office and member staff that acts as an advisory body to reduce food safety risk through continuous improvement of food safety policies and programs for the network.  The council meets every two months."
      },
      {
          "Term:": "FSC",
          "Definition:": "Food Safety Council. A team comprised of national office and member staff that acts as an advisory body to reduce food safety risk through continuous improvement of food safety policies and programs for the network.  The council meets every two months."
      },
      {
          "Term:": "Food Safety Hazard",
          "Definition:": "Biological, chemical, or physical agents that are likely to cause illness or injury, when consumed, if not controlled."
      },
      {
          "Term:": "Food Security",
          "Definition:": "See Food Insecurity."
      },
      {
          "Term:": "Food Service or Foodservice",
          "Definition:": "Suppliers and producers of product specifically designed for cafeterias, airlines, hotels, restaurants, cruise ships, schools, and other mass feeding sites.  Food is usually packaged in larger sizes than regular retail pack."
      },
      {
          "Term:": "Food Service Frequency",
          "Definition:": "Backpacks containing food must be offered to children in need a minimum of once per month during the school year.  See BackPack Program."
      },
      {
          "Term:": "Food Service Management Company",
          "Definition:": "Any commercial enterprise or nonprofit organization that a sponsor may hire to prepare unitized meals for use in a meal program, or to manage the sponsor’s food service operations. Food service management companies/commercial meal vendors may be: Public agencies or entities; Private, nonprofit organizations; or Private, for-profit companies."
      },{
          "Term:": "FSMC",
          "Definition:": "Food Service Management Company. Any commercial enterprise or nonprofit organization that a sponsor may hire to prepare unitized meals for use in a meal program, or to manage the sponsor’s food service operations. Food service management companies/commercial meal vendors may be: Public agencies or entities; Private, nonprofit organizations; or Private, for-profit companies."
      },
      
      {
          "Term:": "Food Sharing Cooperative",
          "Definition:": "A group of food banks that collectively purchase food to obtain the best possible delivered price.  An FSC can purchase full truckloads of product and distribute to two or more food banks to minimize shipping costs by filling an entire load and sharing the freight costs with as many cases of product as possible, lowering the case price to all participants."
      },
      {
          "Term:": "FSC",
          "Definition:": "Food Sharing Cooperative. A group of food banks that collectively purchase food to obtain the best possible delivered price.  An FSC can purchase full truckloads of product and distribute to two or more food banks to minimize shipping costs by filling an entire load and sharing the freight costs with as many cases of product as possible, lowering the case price to all participants."
      },
      {
          "Term:": "Food Shelf",
          "Definition:": "A program that distributes groceries (non-prepared foods) and other basic supplies for off-site use, usually for preparation in the client’s residence. Also known as a food pantry."
      },
      {
          "Term:": "Food Stamp Household",
          "Definition:": "Any individual or group of individuals who are currently certified to receive assistance as a household under the Food Stamp Program, also known as the Supplemental Nutrition Assistance Program (SNAP). http://www.fns.usda.gov/snap/"
      },
      
      {
          "Term:": "Food Stamp Program",
          "Definition:": "A federal program that enables low-income people to buy nutritious food with coupons and Electronic Benefits Transfer (EBT) cards.  Recipients spend their benefits to buy eligible food in authorized retail food stores. The 2008 Farm Bill (Public Law 110-234) has renamed this program the Supplemental Nutrition Assistance Program (SNAP). http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "Food Stamp Employment and Training Program",
          "Definition:": "Federal funds made available to the states through the Food Stamp Program for the purpose of providing employment and training programs to food stamp households that would otherwise be ineligible for food stamp benefits.  See Able-Bodied Adults Without Dependents. http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "Food Stamp Nutrition Education",
          "Definition:": "This program is administered through the Food and Nutrition Service of the U.S. Department of Agriculture (USDA) and aims to improve the diet and nutrition-related skills of food stamp recipients and their families."
      },
      {
          "Term:": "FSNE",
          "Definition:": "Food Stamp Nutrition Education. This program is administered through the Food and Nutrition Service of the U.S. Department of Agriculture (USDA) and aims to improve the diet and nutrition-related skills of food stamp recipients and their families."
      },
      
      {
          "Term:": "Food Security",
          "Definition:": "Access by all people at all times to enough food for an active, healthy life."
      },
      {
          "Term:": "Forklift",
          "Definition:": "A machine used for hoisting and transporting heavy objects by means of steel bars inserted under the load.  Used to move pallets."
      },
      {
          "Term:": "Free available chlorine",
          "Definition:": "Amount of chlorine available to react with bacteria."
      },
      {
          "Term:": "Free of Charge",
          "Definition:": "Some afterschool programs may charge a membership fee for participation. This fee should be nominal with opportunities for scholarships or waivers for those unable to pay. This membership fee should not be tied in any way to the meals. Meals or food must be provided free of charge."
      },
      
      {
          "Term:": "Free on Board",
          "Definition:": "A term of sale negotiated with the shipper that specifies where the receiver of a shipment accepts ownership and legal responsibility for the product.  For example, F.O.B. Shipping Point or F.O.B. Origin indicates the receiver accepts ownership (and usually pays freight charges) for the product at the shipper’s dock.  F.O.B. Destination indicates the shipper owns the product (and usually pays freight charges) at the receiver’s dock.   Common Usage:  If product is said to be F.O.B, it is a short way to say that it is F.O.B. Origin, which means that title will pass to the receiver at time of pickup, and the receiver is responsible for freight charges"
      },
      {
          "Term:": "FOB",
          "Definition:": "A term of sale negotiated with the shipper that specifies where the receiver of a shipment accepts ownership and legal responsibility for the product.  For example, F.O.B. Shipping Point or F.O.B. Origin indicates the receiver accepts ownership (and usually pays freight charges) for the product at the shipper’s dock.  F.O.B. Destination indicates the shipper owns the product (and usually pays freight charges) at the receiver’s dock.   Common Usage:  If product is said to be F.O.B, it is a short way to say that it is F.O.B. Origin, which means that title will pass to the receiver at time of pickup, and the receiver is responsible for freight charges"
      },
      {
          "Term:": "Free Meal Certification",
          "Definition:": "A classification within the child nutrition programs indicating that a child is able to receive meals and snacks at no cost to his or her family.  Children from families with income at or below 130 percent of the federal poverty level qualify to receive free meals."
      },
      {
          "Term:": "Freight Bill",
          "Definition:": "The invoice used by carriers to notify the responsible party of charges due for transportation of shipments."
      },
     
      {
          "Term:": "Freight Collect",
          "Definition:": "A term of sale that indicates the receiver is responsible for paying the freight charges.  It is often used when ownership of product is transferred. For example, F.O.B. Origin, Freight Collect indicates the receiver accepts ownership of the product at the shipper’s dock and is responsible for the freight charges."
      },
      {
          "Term:": "Freight Prepaid",
          "Definition:": "A term of sale that indicates the shipper is responsible for paying the freight charges.  For example, F.O.B. Destination, Freight Prepaid indicates the receiver accepts ownership of the product when it is delivered to the receiver’s dock, and the shipper is responsible for the freight charges."
      },
      {
          "Term:": "Fresh",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Fresh Fruits and Vegetables."
      },
      {
          "Term:": "Fruit",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Canned and Frozen Fruit."
      },
      {
          "Term:": "FSOP",
          "Definition:": "Food Sourcing and Operations Conference"
      },
      {
          "Term:": "FTHR",
          "Definition:": "Finance, Technology and Human Resources Conference"
      },
      {
          "Term:": "Fund",
          "Definition:": "A gift or grant given to Feeding America in support of hunger-relief efforts."
      },
      {
          "Term:": "Fund Number",
          "Definition:": "The accounting of a restricted gift that is maintained by Finance in AwardVision to track and assure the appropriate allocation of funds."
      },
      {
          "Term:": "Fund Number Request",
          "Definition:": "The process by which the Philanthropy Donor Services department identifies the need for a new fund to be created by the Finance department"
      },
      {
          "Term:": "Fundable Project",
          "Definition:": "A project with a funding need and budget that Philanthropy staff believes will be appealing to prospects. Some projects are associated with campaign priorities."
      },
      
      {
          "Term:": "Gassing",
          "Definition:": "Some shippers of tomatoes and bananas use ethylene gas to ripen product picked in the green stage."
      },
      {
          "Term:": "General Assistance",
          "Definition:": "A collective group of assistance programs funded and administered entirely by the state, county, and/or locality in which the particular program operates.  Provides benefits to low-income persons who are not eligible for federal assistance.  General Assistance programs are the last resort for government assistance to people in need."
      },
      {
          "Term:": "GA",
          "Definition:": "A collective group of assistance programs funded and administered entirely by the state, county, and/or locality in which the particular program operates.  Provides benefits to low-income persons who are not eligible for federal assistance.  General Assistance programs are the last resort for government assistance to people in need."
      },
      {
          "Term:": "Generally recognized as safe",
          "Definition:": "The substance is generally recognized, among qualified experts, as having been adequately shown to be safe under the conditions of its intended use, or unless the use of the substance is otherwise excluded from the definition of a food additive."
      },
      {
          "Term:": "GRAS",
          "Definition:": "Generally recognized as safe. The substance is generally recognized, among qualified experts, as having been adequately shown to be safe under the conditions of its intended use, or unless the use of the substance is otherwise excluded from the definition of a food additive."
      },
      {
          "Term:": "GIK",
          "Definition:": "Gifts in Kind"
      },
      {
          "Term:": "Gift Tax",
          "Definition:": "A tax imposed on someone who gives money or property to another person without compensation."
      },
      {
          "Term:": "GIS",
          "Definition:": "Geographic Information Systems"
      },
      {
          "Term:": "Gleaning",
          "Definition:": "Gathering what has been left in the fields after the harvest.  The Bible contains a number of references to the practice as a method for feeding the needy."
      },
      
      {
          "Term:": "Gleaning Program",
          "Definition:": "Gleaning is the collection of leftover or specified crops from farmers’ fields, or collecting what is on fields that are not economically profitable to harvest (also considered surplus produce within this definition). State appropriations to support these types of programs often go towards reimbursing the processor for the costs associated with processing, packaging, and transporting product to the food bank or other hunger relief organization."
      },
      
      {
          "Term:": "GMA Food Bank Committee",
          "Definition:": "Grocery Manufacturers Association (GMA) Food Bank Committee is a volunteer group of food industry inspectors who monitor Feeding America members and report its findings to Feeding America.  Also known as the Corporate Inspection Team."
      },
      {
          "Term:": "Goal Factor",
          "Definition:": "A measure of need in a member’s service area, based on a formula including the area’s unemployment rate and client population in poverty. The goal factor is used in the fair-share allocation process to determine how many shares are given to members in the Choice System."
      },
      {
          "Term:": "GF",
          "Definition:": "Goal Factor, A measure of need in a member’s service area, based on a formula including the area’s unemployment rate and client population in poverty. The goal factor is used in the fair-share allocation process to determine how many shares are given to members in the Choice System."
      },
      {
          "Term:": "Good Manufacturing Practices",
          "Definition:": "As described in 21 CFR 110, represents the central food safety regulation implemented by the Food and Drug Administration; when followed, helps protect food from contamination."
      },
      {
          "Term:": "Good Samaritan Laws",
          "Definition:": "The federal Bill Emerson Good Samaritan Food Donation Act, signed into law in 1996 (Public Law 104-210), provides uniform, blanket liability protection in all 50 states for donors who donate apparently fit and wholesome food in good faith for distribution to needy people. Many states also have their own “good Samaritan” laws, but the federal Good Samaritan Act preempts the various state Good Samaritan statutes with a single, federal standard of criminal and civil liability in the donation of food and grocery products."
      },
      {
          "Term:": "Grain",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Flour, Corn Meal, and Matzo Meal Grains."
      },
      {
          "Term:": "Grant Progress Reports",
          "Definition:": "Mandatory reports that must be completed when a member accepts a grant through the national office. These reports assist the national office in reporting back to the donors how the grant funds were utilized and the outcomes.  Grantees are notified of the reporting requirements when awarded a grant."
      },
      {
          "Term:": "Grant Restriction",
          "Definition:": "The state of not being eligible to apply for or receive grant funds due to late submission of the Network Activity Report (NAR), the Quarterly Poundage Report (QPR), or grant reports.  Members are put on grant restriction for a period of six months.  Please refer to NAR or QPR policy, or the late grant report policy, for further details."
      },
      
      
      {
          "Term:": "Grant Review Process",
          "Definition:": "The Grants Administration Team designates a Grant Review Committee to review applications submitted by network members for a member grant opportunity. The Committee will make granting decisions on the individual proposals based on the criteria outlined in the Request for Proposal (RFP)."
      },
      {
          "Term:": "Grantor",
          "Definition:": "The creator of a trust or other legal instrument."
      },
      {
          "Term:": "Grocery Manufacturers Association",
          "Definition:": "Formerly known as Grocery Manufacturers of America.  National trade association of food and grocery manufacturers; very instrumental in the creation and development of Feeding America (of the Feeding America network?)."
      },
      {
          "Term:": "GMA",
          "Definition:": "Formerly known as Grocery Manufacturers of America.  National trade association of food and grocery manufacturers; very instrumental in the creation and development of Feeding America (of the Feeding America network?)."
      },
      {
          "Term:": "Gross negligence",
          "Definition:": "From the Bill Emerson Good Samaritan Food Donation Act: Gross negligence:  The term \"gross negligence\" means voluntary and conscious conduct by a person with knowledge (at the time of the conduct) that the conduct is likely to be harmful to the health or well-being of another person."
      },
     
      {
          "Term:": "Gross Weight",
          "Definition:": "The combined weight of product (net weight), plus the weight of containers/packaging materials (tare weight)."
      },
      {
          "Term:": "GSA",
          "Definition:": "General Service Administration"
      },
      {
          "Term:": "Hand Jack",
          "Definition:": "A hand-operated, non-riding forklift used to move pallets.  See Pallet Jack."
      },
      {
          "Term:": "Handling Fee",
          "Definition:": "The fee members charge agencies for product distributed.  Effective August 1, 2008, the shared maintenance/handling fee ceiling was raised to 19 cents per pound, up from the previous cap of 18 cents per pound.  Also known as the shared maintenance fee."
      },
      {
          "Term:": "Hanging Meats",
          "Definition:": "Prepackaged meats and cheeses that are vacuumed packed and merchandised on metal pegs in the meat or deli departments. May also be known as hard-packed."
      },
      {
          "Term:": "Hazard Analysis Critical Control Points",
          "Definition:": "A systematic approach to assessing possible risks associated with a product and determining the controls necessary to minimize or eliminate the risks of causing illness or injury.  A system which identifies, evaluates, and controls hazards which are significant for food safety."
      },
      {
          "Term:": "HACCP",
          "Definition:": "Hazard Analysis Critical Control Points. A systematic approach to assessing possible risks associated with a product and determining the controls necessary to minimize or eliminate the risks of causing illness or injury.  A system which identifies, evaluates, and controls hazards which are significant for food safety."
      },
      {
          "Term:": "Health & Beauty Care",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Health/Beauty Care such as Shampoo, Conditioner, Soap, Cosmetics, Deodorants, All Dental Care."
      },
      {
          "Term:": "Health Hazard Evaluation",
          "Definition:": "An evaluation of the health hazard presented by a product that is being recalled or considered for recall. A team of experts from the regulatory authority conducts the evaluation.  The affected food bank may also evaluate the potential health hazard presented by the product."
      },
      {
          "Term:": "Healthy Nutritious Food",
          "Definition:": "A variety of foods from each food group, including items that can be used together to create complete meals.  Includes items that are low in sodium, sugar and saturated/trans fats, as well as: Fruits and vegetables, Whole grains, Lean protein, Low-fat dairy products See BackPack Program."
      },
      {
          "Term:": "Home Delivered Meals",
          "Definition:": "A program in which volunteers deliver meals to homebound seniors.  Home-delivered meal programs are often supported by senior nutrition programs.  Some states also use funds from the Social Services Block Grant to support home-delivered meals programs.  These programs are more commonly known as Meals on Wheels."
      },
     
      {
          "Term:": "Homeless Children or Youth",
          "Definition:": "Individuals who lack a fixed, regular, and adequate nighttime residence and includes:  (a) children and youths who are sharing the housing of other persons due to loss of housing, economic hardship, or a similar reason; are living in motels, hotels, trailer parks, or camping grounds due to the lack of alternative adequate accommodations; are living in emergency or transitional shelters; are abandoned in hospitals; or are awaiting foster care placement; (b) children and youths who have a primary nighttime residence that is a public or private place not designed for or ordinarily used as a regular sleeping accommodation for human beings; (c) children and youths who are living in cars, parks, public spaces, abandoned buildings, substandard housing, bus or train stations, or similar settings; and (d) migratory children. http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "Household",
          "Definition:": "See Family."
      },
      {
          "Term:": "Hunger",
          "Definition:": "The uneasy or painful sensation caused by a lack of food or the recurrent and involuntary lack of access to food.  Hunger may produce malnutrition over time.  Hunger is a potential, although not necessary, consequence of food insecurity.  Unlike food insecurity, which is a household-level concept, hunger is an individual-level concept."
      },
      {
          "Term:": "Hunger Action Month",
          "Definition:": "A national “Skip Lunch to Fight Hunger” campaign held during the month of September.  The campaign asks Americans to donate their lunch money to the Feeding America network."
      },
      {
          "Term:": "HAM",
          "Definition:": "Hunger Action Month: A national “Skip Lunch to Fight Hunger” campaign held during the month of September.  The campaign asks Americans to donate their lunch money to the Feeding America network."
      },
      {
          "Term:": "Hunger and Nutrition Education",
          "Definition:": "State appropriations for hunger and nutrition education are often used to provide training opportunities to individuals accessing emergency food assistance, but may be used more broadly. Training programs may cover a wide variety of topics such as nutrition education, safe food handling, meal preparation, and preparing food for special dietary needs."
      },
      
      {
          "Term:": "HungerNet",
          "Definition:": "Feeding America’s corporate intranet: www.hungernet.org. The internal, online communication hub for the national office staff and its member food banks."
      },
      {
          "Term:": "Hunger Relief Organizations",
          "Definition:": "This phrase describes the various organizations that benefit by Feeding America activities, including food banks, rapid food delivery programs, and emergency food programs."
      },
      {
          "Term:": "Hunger Study",
          "Definition:": "The quadrennial study undertaken by the national office to provide information on hunger in America and the charitable response. http://feedingamerica.org/faces-of-hunger/hunger-in-america-2010.aspx"
      },
      {
          "Term:": "Hunger Study Coordinator",
          "Definition:": "The primary contact person and project manager for the Hunger Study at the food bank.  This person is the only individual who is required to attend one of the mandatory trainings, although any additional staff is surely welcome."
      },
      {
          "Term:": "Hunting Donation Program",
          "Definition:": "State funds are used to facilitate and encourage hunters to donate hunted game and wildlife—whose meat may otherwise go to waste—to charitable hunger relief organizations that provide food assistance to low-income individuals in need. State appropriations to support these types of programs often go towards reimbursing the processor for the costs associated with processing, packaging, and transporting the meat to the food bank or other hunger-relief organizations."
      },
      {
          "Term:": "HVAC",
          "Definition:": "Heating, Ventilation, and Air Conditioning"
      },
      {
          "Term:": "IA",
          "Definition:": "Individual Assistance"
      },
      {
          "Term:": "Identification",
          "Definition:": "Step one in the relationship management cycle. Identified prospects have either been suggested or flagged as a possible campaign prospect and merit additional research."
      },
      {
          "Term:": "ILI",
          "Definition:": "Influenza-Like Illness"
      },
      {
          "Term:": "Ill",
          "Definition:": "Donated goods may be distributed only to the “ill, needy or infants,” as defined by Section 170(e)(3) of the U.S. Internal Revenue Code (IRC), as further defined by page 4511 of the 2/1/1992 Federal Register and by the Feeding America Gray Area Task Force Report.  Examples of ill people include people: Suffering from physical injury or with a significant impairment of a bodily organ. Someone with an existing handicap, whether from birth or later injury. Someone suffering from malnutrition. Someone with a disease, sickness, or infection which significantly impairs physical health. Someone partially or totally incapable of self-care, including incapacity due to old age."
      },
     
      {
          "Term:": "Inactive BackPack Program Site",
          "Definition:": "An inactive site is temporarily not operating during a defined period such as the summer or holidays.  See BackPack Program."
      },
      {
          "Term:": "Income Accruing to the Program",
          "Definition:": "All funds used by a sponsor in its food service program, including but not limited to all monies, other than program payments, received from federal, state and local governments, from food sales to adults, and from any other source including cash donations or grants. Income accruing to the program will be deducted from combined operating and administrative costs.  See Sponsor; Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      
      {
          "Term:": "Income Eligibility",
          "Definition:": "Individuals and households qualify for the federal nutrition programs by providing information about the household’s income.  In general, in order to be eligible for food stamps, household income cannot exceed 130 percent of the federal poverty level. Children from households with an income below 135 percent of the poverty level can receive free meal certification.  Children from households with an income between 135 percent and 180 percent of the poverty level can receive reduced price meal certification. See Food Stamp Program; Supplemental Nutrition Assistance Program (SNAP). "
      },
      
      {
          "Term:": "Individually Quick Frozen (IQF)",
          "Definition:": "Product that is frozen individually and instantly, so it will be loose in its container and not frozen into a solid block."
      },
      {
          "Term:": "IQF",
          "Definition:": "Individually Quick Frozen. Product that is frozen individually and instantly, so it will be loose in its container and not frozen into a solid block."
      },
      {
          "Term:": "Infant",
          "Definition:": "A minor child, as determined under the laws of jurisdiction in which the child resides.  The Feeding America Gray Area Task Force Report concluded that an infant must also be needy to qualify for member services.  For further reading, refer to Section 170(e)(3) of the Internal Revenue Code."
      },
      {
          "Term:": "IT",
          "Definition:": "Information Technology"
      },
      {
          "Term:": "Infrared Thermometer",
          "Definition:": "Noncontact and noninvasive thermometer used to measure surface temperatures."
      },
      {
          "Term:": "Integrated Pest Control Management Program",
          "Definition:": "This program uses a pest control strategy comprised of two parts: It uses preventative measures to keep pests from entering the operation."
      },
      {
          "Term:": "IPM",
          "Definition:": "Integrated Pest Control Management Program. This program uses a pest control strategy comprised of two parts: It uses preventative measures to keep pests from entering the operation."
      },
      {
          "Term:": "Intentional misconduct",
          "Definition:": "From the Bill Emerson Good Samaritan Food Donation Act: The term \"intentional misconduct\" means conduct by a person with knowledge (at the time of the conduct) that the conduct is harmful to the health or well-being of another person."
      },
      
      {
          "Term:": "Interaction Report",
          "Definition:": "Notes detailing any interaction/contact with a prospect or donor."
      },
      {
          "Term:": "Interest",
          "Definition:": "A donor is considered interested when he or she has a regular history of giving, involvement and external interests that tend to match with the mission of the Feeding America network."
      },
      {
          "Term:": "Interruption Event",
          "Definition:": "An event that is considered a minor disturbance that disrupts normal operations for a limited amount of time. During an interruption event, a limited amount of workflow for a branch office will typically be re-routed to another branch. Workflow for a corporate business unit and a managed agency will typically not be re-routed or recovered to an off-site location. However, a corporate business unit and/or a managed agency are often required to implement recovery procedures. Examples of an interruption event include snowstorms, power outages, etc."
      },
      {
          "Term:": "Intranet",
          "Definition:": "Feeding America’s corporate intranet site is www.hungernet.org.  It is the online internal communication hub for Feeding America national office staff and member food banks."
      },
      {
          "Term:": "Inventory",
          "Definition:": "An itemized list of goods or materials on hand at any given time."
      },
      {
          "Term:": "Inventory Turns or Inventory Turnover",
          "Definition:": "This is a measure of the throughput of your purchasing program and is typically computed as the total sales over some period divided by the average value of inventory on hand during the period.  For example, a purchasing program with $1.2M in sales per year, with an average inventory value of $120K, turns their inventory 12 times per year and therefore, has an inventory turns ratio of 12.  This metric should also be scrutinized at the product or item level to determine which products are turning fast or slow.  Throughput for any period is defined as:  Throughput inventory."
      },
      {
          "Term:": "Inventory Turnover",
          "Definition:": "This is a measure of the throughput of your purchasing program and is typically computed as the total sales over some period divided by the average value of inventory on hand during the period.  For example, a purchasing program with $1.2M in sales per year, with an average inventory value of $120K, turns their inventory 12 times per year and therefore, has an inventory turns ratio of 12.  This metric should also be scrutinized at the product or item level to determine which products are turning fast or slow.  Throughput for any period is defined as:  Throughput inventory."
      },
      {
          "Term:": "IFB",
          "Definition:": "Invitation for Bid"
      },
      {
          "Term:": "Irrevocable Trust",
          "Definition:": "A trust that cannot be changed or dissolved."
      },
      {
          "Term:": "IRS Form 990",
          "Definition:": "The federal tax return form used by organizations that are exempt from paying income tax.  The form must be filed four and a half months after the close of the fiscal year."
      },
      {
          "Term:": "IRS Form SS-4",
          "Definition:": "The form that an agency or business submits to the Internal Revenue Service to request an employer identification number."
      },
      {
          "Term:": "IRS Package 1023",
          "Definition:": "The forms and instructions used by a nonprofit entity when applying to the Internal Revenue Service for 501(c)(3) status designation."
      },
      {
          "Term:": "JFO",
          "Definition:": "Joint Field Office"
      },
      {
          "Term:": "Job Training Program",
          "Definition:": "A program that provides skills training in order to move more people toward self-sufficiency."
      },
      {
          "Term:": "Joint Report",
          "Definition:": "A Hunger Study local report that reflects the combination of two service areas.  This format is typically applied to member food banks and food rescue organizations (FROs) that share a service area.  Because only one report is generated, the fee for participation by both members is the highest fee of the two.  This means that each member would pay only half of the highest fee."
      },
      {
          "Term:": "Juice",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for 100% Fruit or Vegetable Juice."
      },
      {
          "Term:": "Just In Time (JIT)",
          "Definition:": "The practice of timing inbound material flows so that they arrive just before they are required.  This results in smaller inventories and cost savings."
      },
      {
          "Term:": "JIT",
          "Definition:": "Just In Time The practice of timing inbound material flows so that they arrive just before they are required.  This results in smaller inventories and cost savings."
      },
      {
          "Term:": "Kids Cafe Program",
          "Definition:": "Kids Cafe programs provide free meals and snacks to low-income children through a variety of existing community locations where children congregate. In addition to providing meals to hungry kids, all Kids Cafe programs also offer a safe place, where under the supervision of trustworthy staff, a child can get involved in educational, recreational and social activities that draw on existing community programs and often include family members. If a member operates a Kids Cafe program, the national office should have a signed program agreement on file."
      },
     
     
      {
          "Term:": "Knowledge Assets",
          "Definition:": "An organization’s collection of information and knowledge resources. These resources can be promising/best practices, lessons learned, processes, procedures, guides, or any other form of reusable knowledge. Knowledge assets are what an organization knows or needs to know to facilitate its daily business."
      },
     
      {
          "Term:": "Knowledge Management",
          "Definition:": "The practice that supports and promotes a learning organization in order to meet business objectives.  It enables individuals and organizations to collectively and systematically create, share and apply knowledge and information.  Knowledge management can include tools and activities such as online interactive tools, learning opportunities, online collaboration and sharing of business practices.  Its systematic and organic approach helps information and knowledge merge and flow to the right people, at the right time, in the right context and in the right amount, so they can act  more effectively and efficiently."
      },
     
      {
          "Term:": "Knowledge Owner",
          "Definition:": "The individual(s) responsible for knowledge and information for a subject area.  The knowledge owner is responsible for keeping the knowledge and information current, relevant, and complete.  The knowledge owner may or may not be the author or creator of the specific content.  The owner may be the expert in the subject area or a skilled editor."
      },
      {
          "Term:": "Label",
          "Definition:": "The information that must be affixed to food products in order to be lawfully distributed.  Specific requirements are set by the U.S. Food and Drug Administration (USDA) and include the product’s name, weight, ingredients, and distribution point (name, city, and state) of the food bank, manufacturer, packer, or distributor. http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "Landfill",
          "Definition:": "Contemporary name for a garbage dump; one of our major competitors for product donations."
      },
      {
          "Term:": "Learning Management System (LMS)",
          "Definition:": "Software application system used to support e-learning activities.  It provides an organization with a way to deliver content, monitor student participation and assess student performance.  It provides students with the ability to use interactive features such as web-based training courses and discussion forums.  Organizations implement an LMS because they are committed to continued learning, development and knowledge transfer for the members of their organization."
      },
      {
          "Term:": "LMS",
          "Definition:": "Learning Management System. Software application system used to support e-learning activities.  It provides an organization with a way to deliver content, monitor student participation and assess student performance.  It provides students with the ability to use interactive features such as web-based training courses and discussion forums.  Organizations implement an LMS because they are committed to continued learning, development and knowledge transfer for the members of their organization."
      },
      {
          "Term:": "Legal Assistance",
          "Definition:": "Free or low-cost legal advice, counseling, or trial services."
      },
      {
          "Term:": "Legislative Agenda",
          "Definition:": "A legislative agenda details the legislative proposals an entity, or a coalition, plans to advocate for with a governmental body."
      },
      {
          "Term:": "Less than Truckload (LTL)",
          "Definition:": "Abbreviation for less than a full truckload."
      },
      {
          "Term:": "LTL",
          "Definition:": "Less than Truckload Abbreviation for less than a full truckload."
      },
      {
          "Term:": "Letter to the Editor",
          "Definition:": "A short letter that is written to the editor of a newspaper, magazine, or periodical about an issue that may be of interest or concern to the readers. These letters are usually intended to be published when submitted."
      },
      {
          "Term:": "Life Income Gift",
          "Definition:": "A gift of a principal sum, property, or securities with a stipulated life income paid to the donor or another person for his or her lifetime(s)."
      },
      {
          "Term:": "Life Income Trust",
          "Definition:": "A plan whereby gift assets are placed in trust for the lifetime benefit of an income beneficiary, with the remainder going to another beneficiary."
      },
      {
          "Term:": "Linkage",
          "Definition:": "Identifying connections to the Feeding America network through personal relationships, and other involvement with similar organizations and causes."
      },
      {
          "Term:": "Local Agreement",
          "Definition:": "(As defined in the Feeding America Member Contract) A written, signed agreement between two or more members specifying ways in which they will work together within the network, share or divide resources within their shared service area, and resolve other operational issues. A local agreement between two members that share an overlapping service area is required.  A current local agreement is part of the Feeding America Member Contract."
      },
      {
          "Term:": "Local Disruptions",
          "Definition:": "Disruptions that affect an individual Feeding America network location."
      },
      {
          "Term:": "Local Donor",
          "Definition:": "(As defined in the Feeding America Member Contract) A food or grocery product donor that is not a “national donor.”"
      },
      {
          "Term:": "Local Receipt",
          "Definition:": "A receipt sent by a member to a local donor for a local donation of product."
      },
      {
          "Term:": "Local Report",
          "Definition:": "For each participating member food bank, a local report is received providing an exact replica of the national report except reflecting the participating member’s service area.  Each local report contains an in- depth analysis of the client interview results as well as the agency survey results."
      },
      
      {
          "Term:": "Logistics",
          "Definition:": "The management of inbound and outbound materials, parts, supplies, and finished goods.  Originally confined to traffic and warehousing, logistics has evolved to include production scheduling, forecasting, customer service, order entry, inventory control, and product allocation among customers."
      },
      {
          "Term:": "Manufacturer",
          "Definition:": "Company that processes finished goods from raw materials."
      },
      {
          "Term:": "Manufacturer’s Representative",
          "Definition:": "An agent who generally operates on an extended contractual basis and handles non-competing but related lines of products within an exclusive territory."
      },
      {
          "Term:": "Market Share",
          "Definition:": "A firm’s percentage of total sales for the finished product of a specific category, such as cereal, peanut butter, pasta, or eggs."
      },
      {
          "Term:": "Maroon Load",
          "Definition:": "A donation transfer posted on the Choice System from one member to another member.  Members may charge shared maintenance fees and value added processing fees and may require a minimum level of shares."
      },
      {
          "Term:": "Mass Care",
          "Definition:": "The branch of the Emergency Support Function within the Federal Emergency Management Agency National Response Framework that addresses the delivery of shelter, food, and emergency first aid to disaster victims; the establishment of systems to provide bulk distribution of emergency relief supplies to disaster victims; and the collection of information to operate a Disaster Welfare Information (DWI) system for the purpose of reporting victim status and assisting in family reunification. See ESF #6."
      },
      {
          "Term:": "MC",
          "Definition:": "Mass Care. The branch of the Emergency Support Function within the Federal Emergency Management Agency National Response Framework that addresses the delivery of shelter, food, and emergency first aid to disaster victims; the establishment of systems to provide bulk distribution of emergency relief supplies to disaster victims; and the collection of information to operate a Disaster Welfare Information (DWI) system for the purpose of reporting victim status and assisting in family reunification. See ESF #6."
      },
      {
          "Term:": "Material Safety Data Sheets",
          "Definition:": "Designed to provide both workers and emergency personnel with the proper procedures for handling or working with a particular substance. Data sheets include information such as physical data, health effects, first aid, reactivity, storage, disposal, protective and spill/leak procedures."
      },
      {
          "Term:": "MSDS",
          "Definition:": "Material Safety Data Sheets. Designed to provide both workers and emergency personnel with the proper procedures for handling or working with a particular substance. Data sheets include information such as physical data, health effects, first aid, reactivity, storage, disposal, protective and spill/leak procedures."
      },
      {
          "Term:": "McKinney Act",
          "Definition:": "Federal Hunger and Homelessness Relief legislation enacted in the late 1980s.  Some members handle U.S. Department of Agriculture (USDA) food supplies and access federal surplus property and real estate through the McKinney Act.  http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "MCEA",
          "Definition:": "Mass Care/Emergency Assistance"
      },
      {
          "Term:": "MCS",
          "Definition:": "Master Cleaning Schedule"
      },
      {
          "Term:": "Meal",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Complete Meal or Entrée and Soup."
      },
      {
          "Term:": "Meal Pattern",
          "Definition:": "Meals served under the child nutrition programs must fulfill certain nutrition standards established by the U.S. Department of Agriculture (USDA).  The meal pattern outlines the specific types (fluid milk, dairy, fruit/vegetable, bread/bread alternative, and meat/meat alternative) and serving size of food that fulfill these guidelines. The meal pattern varies based upon type of meal (breakfast, lunch/supper or snack) and age of the child being served. http://www.usda.gov/wps/portal/usda/usdahome"
      },
      
      {
          "Term:": "Meals on Wheels",
          "Definition:": "In partnership with members, Meals on Wheels provides nutritious meals to the homebound elderly and persons with disabilities in an effort to improve health, reduce isolation, and prevent inappropriate institutionalization.  See Home-Delivered Meals."
      },
      
      {
          "Term:": "Meat",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Meat, Fish, and Poultry."
      },
      {
          "Term:": "Medicaid",
          "Definition:": "The state medical assistance program under Title XIX of the Social Security Act."
      },
      {
          "Term:": "Member",
          "Definition:": "(As defined in the Feeding America Member Contract) A charitable organization whose core function is food banking, which is to solicit, receive, inventory, store, and distribute donated food and grocery product to anti-hunger organizations and needy individuals and has executed a member contract (that has not been terminated or expired) with the national office."
      },
      {
          "Term:": "Member Advisory Committee",
          "Definition:": "A select committee comprised of Hunger Study participants of each size, region, and type.  MAC members will be required to attend at least two meetings to discuss development and progress of the project and provide a food bank perspective, as well as conduct mentorships, technical assistance, and advisors to other participants within the network."
      },
      {
          "Term:": "MAC",
          "Definition:": "Member Advisory Committee. A select committee comprised of Hunger Study participants of each size, region, and type.  MAC members will be required to attend at least two meetings to discuss development and progress of the project and provide a food bank perspective, as well as conduct mentorships, technical assistance, and advisors to other participants within the network."
      },
      {
          "Term:": "Member Compliance Standards",
          "Definition:": "(As defined in the Feeding America Member Contract) The standards as described in Appendix B (of the Feeding America Member Contract)."
      },
      {
          "Term:": "Member Contract",
          "Definition:": "The contract between Feeding America and its members, which outlines the terms of membership and defines the policies to which both parties agree."
      },
      {
          "Term:": "Member Fees",
          "Definition:": "(As defined in the Feeding America Member Contract) The fees to be paid by the member to the national office, as calculated in accordance with the method described in Appendix D (of the Feeding America Member Contract)."
      },
      {
          "Term:": "Member Grant",
          "Definition:": "A gift to Feeding America intended for network distribution, over which Feeding America exercises variance power. The donor may work with the national office to determine the types of program(s) and organizations towards which these funds will be applied, but Feeding America has variance power over the use and distribution of the transferred assets. Member grants are counted as revenue (approved 10/26/09).  See Variance."
      },
      
     
      {
          "Term:": "Members",
          "Definition:": "(As defined in the Feeding America Member Contract) The collective term for all organizations that have signed member contracts (that have not been terminated or expired) with the national office."
      },
      {
          "Term:": "Memorandum of Understanding",
          "Definition:": "A non-binding written agreement that details how the parties involved will act and support each other.  It clearly defines roles and responsibilities but carries no recourse if one party fails to live up to the terms or spirit of the document."
      },
      {
          "Term:": "MOU",
          "Definition:": "Memorandum of Understanding. A non-binding written agreement that details how the parties involved will act and support each other.  It clearly defines roles and responsibilities but carries no recourse if one party fails to live up to the terms or spirit of the document."
      },
      {
          "Term:": "Milk",
          "Definition:": "All milk for meal programs must be fluid and pasteurized and must meet state and local standards for the appropriate type of milk, which includes whole milk, low fat milk, skim milk, and buttermilk.  Milk served may be flavored or unflavored.  All milk should contain Vitamins A and D, at the levels specified by the Food and Drug Administration (FDA), and at levels consistent with state and local standards for such milk. If the supply of such types of fluid milk is insufficient, reconstituted or recombined milk may be used in the following states and territories: Alaska, Hawaii, American Samoa, Guam, Northern Mariana Islands, Puerto Rico, Trust Territory of the Pacific Islands, Virgin Islands of the United States."
      },
      
      {
          "Term:": "Milk By Products",
          "Definition:": "Products other than milk that contain milk as one of the primary ingredients, such as cottage cheese and sour cream."
      },
      {
          "Term:": "Minimum Staffing Ratio",
          "Definition:": "There should be a ratio of at least two adults for the first 25 children. In the case of 25 or less children, another adult must be nearby on the premises in case of an emergency. The number of additional adults assigned for groups of children greater than 25 is determined at the local level, between the Feeding America Participant and its program partner. See Kids Cafe Program."
      },
      
      {
          "Term:": "Misbranded",
          "Definition:": "Any number of label or product identification deficiencies, including use of a false label; false advertising; wrong product name, misleading container, not bearing the name and address of the manufacturer, packer or distributor; inaccurate statement of net quantity; or mislabeling."
      },
      {
          "Term:": "Mix",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Mixed and Assorted Food."
      },
      {
          "Term:": "Mixing Center",
          "Definition:": "A warehouse facility that stores a variety of products (dry, refrigerated and frozen) and ships an assortment of these products to customers."
      },
      {
          "Term:": "MMG",
          "Definition:": "Map the Meal Gap"
      },
      {
          "Term:": "Mobile Pantry",
          "Definition:": "A method of distributing dry and/or refrigerated products via vehicles to clients.  Food banks or member agency representatives manage the direct client distribution.  Utilizing mobile food pantries provides food banks and agencies with expanded capacity, removes barriers to access while increasing distribution in unserved/underserved areas, builds community, and adds flexibility in the delivery of food and grocery products."
      },
      {
          "Term:": "Moderate Level Outreach",
          "Definition:": "Food banks conducting a moderate level of Supplemental Nutrition Assistance Program (SNAP) outreach (i.e., prescreening). http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "MOE",
          "Definition:": "Maintenance of Effort"
      },
      {
          "Term:": "Monitoring",
          "Definition:": "Also referred to as a Compliance Audit.  A formal inspection of a member by Feeding America, or of an agency by a member, to ensure that record keeping, sanitation, distribution and other requirements are being met."
      },
      {
          "Term:": "Monthly Poundage Report",
          "Definition:": "The MPR has only one section, Receipts, same section as the Quarterly Poundage Report (QPR).  Information reported in the MPR enables the national office to monitor trends in a timely manner and quickly respond to emerging needs. This report is optional for member food banks, but we strongly encourage all members to submit this report."
      },
      {
          "Term:": "MPR",
          "Definition:": "Monthly Poundage Report. The MPR has only one section, Receipts, same section as the Quarterly Poundage Report (QPR).  Information reported in the MPR enables the national office to monitor trends in a timely manner and quickly respond to emerging needs. This report is optional for member food banks, but we strongly encourage all members to submit this report."
      },
      {
          "Term:": "MSDS",
          "Definition:": "Material Safety Data Sheet"
      },
      {
          "Term:": "MTP",
          "Definition:": "Mobilizing the Public Conference"
      },
      {
          "Term:": "Multi Benefit Outreach",
          "Definition:": "Outreach initiatives aimed at connecting low-income families to the range of income support programs and services.  Multi-benefit outreach efforts can help low-income families learn about the variety of support programs available and simplify the outreach and enrollment process. Multi-benefit outreach campaigns often provide information about programs such as: earned income tax credits, food stamps and other nutrition programs, free and low-cost health insurance, child-care assistance, and energy assistance."
      },
      
      {
          "Term:": "National Anti Hunger Organizations",
          "Definition:": "A coalition of the nation’s leading anti-hunger advocacy, food bank, and emergency feeding organizations working to reduce hunger in the U.S. Feeding America is a member of the NAHO."
      },
      {
          "Term:": "NAHO",
          "Definition:": "National Anti-Hunger Organizations. A coalition of the nation’s leading anti-hunger advocacy, food bank, and emergency feeding organizations working to reduce hunger in the U.S. Feeding America is a member of the NAHO."
      },
      {
          "Term:": "National Background Search",
          "Definition:": "National background searches are done on volunteers and staff in direct repetitive contact with children at Kids Cafes or BackPack sites to ensure the children’s safety. This database search provides information on who has been convicted or has been under the supervision of states’ department of corrections."
      },
     
      {
          "Term:": "National Council",
          "Definition:": "(As defined in the Feeding America Member Contract) The representative body of the members established by the Feeding America network and elected by the members; successor to the National Delegation and described in Recommendations 6.1 and 7.2.4 of the National Voice Committee’s Report accepted by the National Office’s Board of Directors on June 5, 2001."
      },
      {
          "Term:": "NAC",
          "Definition:": " National Council (As defined in the Feeding America Member Contract) The representative body of the members established by the Feeding America network and elected by the members; successor to the National Delegation and described in Recommendations 6.1 and 7.2.4 of the National Voice Committee’s Report accepted by the National Office’s Board of Directors on June 5, 2001."
      },
      {
          "Term:": "National Donor",
          "Definition:": "(As defined in the Feeding America Member Contract) A food or grocery product donor that donates products to the network through Feeding America (through the national office?)."
      },
      {
          "Term:": "National Partner",
          "Definition:": "(As defined in the Feeding America Member Contract) A food or grocery product donor that donates products to the network through Feeding America (through the national office?)."
      },
      {
          "Term:": "National Office",
          "Definition:": "(As defined in the Feeding America Member Contract) Feeding America, an Arizona nonprofit organization based in Chicago, Illinois, and its staff."
      },
      {
          "Term:": "National Program",
          "Definition:": "(As defined in the Feeding America Member Contract) A nongovernmental direct service program or alternative means of distribution, in each case, the core components of which are defined by the national office and the National Council (NAC), and which is operated by members on a voluntary basis with the support of resource development and technical assistance from the national office."
      },
      
      {
          "Term:": "National Receipt",
          "Definition:": "See Yellow Receipt."
      },
      {
          "Term:": "National Report",
          "Definition:": "A Hunger Study report reflecting the interviews and surveys conducted by each participating member and weighted to reflect the entire Feeding America network.  For Hunger in America 2010, more than 61,000 face-to- face client interviews and more than 37,000 agency surveys were captured by the research firm Mathematica Policy Research Inc."
      },
      {
          "Term:": "National School Lunch Program",
          "Definition:": "A federal program that provides free or reduced-price lunches to more than 15 million low-income children in over 99,000 public and nonprofit private schools and residential child-care institutions each school day.  The Food and Nutrition Service administers the program at the federal level."
      },
      {
          "Term:": "NSLP",
          "Definition:": "National School Lunch Program. A federal program that provides free or reduced-price lunches to more than 15 million low-income children in over 99,000 public and nonprofit private schools and residential child-care institutions each school day.  The Food and Nutrition Service administers the program at the federal level. At the state level, the NSLP is usually administered by state education agencies, which operate the program through agreements with school food authorities.  http://www.fns.usda.gov/cnd/Lunch/"
      },
      
      {
          "Term:": "National Volunteer Organizations Active in Disaster (NVOAD)",
          "Definition:": "NVOAD is not itself a service delivery organization. It upholds the privilege of its members to independently provide relief and recovery services, while expecting them to do so cooperatively.  NVOAD is committed to the idea that the best time to train, prepare, and become acquainted with each other is prior to the actual disaster response.  Organizations and agencies that wish to become NVOAD members undergo an application process and must demonstrate their capability to work within the parameters of NVOAD.  http://www.nvoad.org"
      },
      {
          "Term:": "NVOAD",
          "Definition:": "National Volunteer Organizations Active in Disaster. NVOAD is not itself a service delivery organization. It upholds the privilege of its members to independently provide relief and recovery services, while expecting them to do so cooperatively.  NVOAD is committed to the idea that the best time to train, prepare, and become acquainted with each other is prior to the actual disaster response.  Organizations and agencies that wish to become NVOAD members undergo an application process and must demonstrate their capability to work within the parameters of NVOAD.  http://www.nvoad.org"
      },
      {
          "Term:": "Natural Partners",
          "Definition:": "Individuals who know or may have a relationship with a prospect."
      },
      {
          "Term:": "NAV",
          "Definition:": "Microsoft Dynamics NAV is an enterprise resource management system that provides functionality for inventory, warehouse and financial management. NAV is the underlying system upon which Ceres is built.  See Ceres."
      },
      {
          "Term:": "Navision",
          "Definition:": "A leading enterprise software system sold by Microsoft.  This product has been renamed Microsoft Dynamics NAV."
      },
      {
          "Term:": "NCMEC",
          "Definition:": "National Center for Missing and Exploited Children"
      },
      {
          "Term:": "NECLC",
          "Definition:": "National Emergency Child Locator Center"
      },
      {
          "Term:": "Needy",
          "Definition:": "Donated goods may be distributed only to the “ill, needy or infants,” as defined by Section 170(e)(3) of the U.S. Internal Revenue Code (IRC), as further defined by page 4511 of the 2/1/1992 Federal Register and by the Feeding America Gray Area Task Force Report.  A needy person is one who lacks the necessities of life, involving physical, mental or emotional well- being, as a result of poverty or temporary distress."
      },
      {
          "Term:": "Needy Children",
          "Definition:": "Children from families whose incomes are equal to or below the U.S. Department of Agriculture’s guidelines for determining eligibility for reduced price school meals. http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "NEFRLS",
          "Definition:": "National Emergency Family Registry and Locator System"
      },
      {
          "Term:": "NEMIS",
          "Definition:": "National Emergency Management Information System"
      },
      {
          "Term:": "Net Weight",
          "Definition:": "Weight of product only (does not include container weight)."
      },
      {
          "Term:": "Network",
          "Definition:": "(As defined in the Feeding America Member Contract) The national office and all the members."
      },
      {
          "Term:": "Network Activity Report",
          "Definition:": "A group of informative reports compiled and published annually, based on members’ responses to a computerized questionnaire. The reports cover operational statistics, compensation and benefits, member profiles, performance measures, and more."
      },
      {
          "Term:": "NAR",
          "Definition:": "Network Activity Report A group of informative reports compiled and published annually, based on members’ responses to a computerized questionnaire. The reports cover operational statistics, compensation and benefits, member profiles, performance measures, and more."
      },
      {
          "Term:": "Network Median Poundage",
          "Definition:": "The middle point of pounds distributed per person in poverty by the network."
      },
      {
          "Term:": "New Site",
          "Definition:": "A site that Did not participate in the program in the prior year, or Has experienced significant staff turnover from the prior year: See Site; Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      
      {
          "Term:": "New Sponsor",
          "Definition:": "A sponsor that: Did not participate in the program in the prior year, or Has experienced significant staff turnover from the prior year. See Sponsor; Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      
      {
          "Term:": "NFPA",
          "Definition:": "National Fire Protection Association"
      },
      {
          "Term:": "NGO",
          "Definition:": "Non-Government Organization"
      },
      {
          "Term:": "Non-Food",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Assorted Non-Food such as Household goods, Toys, Books, Clothing."
      },
      {
          "Term:": "Non Fundable Project",
          "Definition:": "A project with a funding need that Philanthropy staff believes will be less appealing to prospects, such as funding for administrative support functions. Staff can and still should raise money for these projects."
      },
      {
          "Term:": "Noninvasive",
          "Definition:": "Means of assessing the physical state of a food product that does not involve direct entry into the food by insertion of an instrument, such as a thermometer."
      },
     
      {
          "Term:": "Nonperishable",
          "Definition:": "See Shelf Stable."
      },
      {
          "Term:": "Nonprofit Organization",
          "Definition:": "From the Bill Emerson Good Samaritan Food Donation Act: The term \"nonprofit organization\" means an incorporated or unincorporated entity that (A) is operating for religious, charitable, or educational purposes; and (B) does not provide net earnings to, or operate in any other manner that inures to the benefit of, any officer, employee, or shareholder of the entity."
      },
      
      {
          "Term:": "NPSC",
          "Definition:": "National Processing Service Center"
      },
      {
          "Term:": "NRF",
          "Definition:": "National Response Framework"
      },
      {
          "Term:": "Nutrition Education",
          "Definition:": "Educational lessons and activities that focus on food, nutrition, healthy eating, physical activity, and food safety, as appropriate for the age group of the program attendees."
      },
      {
          "Term:": "Nutritional Aids",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Nutritional Aids as Drinks, Vitamins, Diet Supplements."
      },
      {
          "Term:": "Nutritious Meals",
          "Definition:": "Nutritious meals include a variety of foods from four of the five food groups of the recommended U.S. Department of Agriculture (USDA) MyPyramid (fruit, vegetables, grain, protein, and dairy products.  Based on available resources, meal program sponsors should strive to develop menus in accordance with the USDA’s Dietary Guidelines and provide a variety of fruits, vegetables, lean protein and dairy products, which are often available in limited supplies in food insecure households. http://www.healthierus.gov/nutrition.html."
      },
      {
          "Term:": "NYSP",
          "Definition:": "The National Youth Sports Program administered by the National Collegiate Athletic Association."
      },
      {
          "Term:": "NYSP Feeding Site",
          "Definition:": "A site: Where all of the children receiving program meals are enrolled in the National Youth Sports Program (NYSP), and That qualifies for program participation based on the definition of “areas in which poor economic conditions exist” See Areas in which Poor Economic Conditions Exist; Summer Food Service Program (SFSP).  http://www.fns.usda.gov/cnd/summer/"
      },
     
      {
          "Term:": "NSS",
          "Definition:": "National Shelter System"
      },
      {
          "Term:": "Occupational Safety and Health Act ",
          "Definition:": "The mission of the U.S. Occupational Safety and Health Administration (OSHA) is to save lives, prevent injuries, and protect the health of U.S. workers. To accomplish this, federal and state governments must work in partnership with the more than 100 million working men and women and their 6.5 million employers who are covered by the OSHA Act of 1970."
      },
      {
          "Term:": "OSHA",
          "Definition:": "Occupational Safety and Health Act/Administration. The mission of the U.S. Occupational Safety and Health Administration (OSHA) is to save lives, prevent injuries, and protect the health of U.S. workers. To accomplish this, federal and state governments must work in partnership with the more than 100 million working men and women and their 6.5 million employers who are covered by the OSHA Act of 1970."
      },
      {
          "Term:": "OVS",
          "Definition:": "Offer Versus Serve"
      },
      {
          "Term:": "OIG",
          "Definition:": "Office of the Inspector General."
      },
      {
          "Term:": "On site",
          "Definition:": "An agency that serves meals to needy persons in its facility, such as soup kitchens, day-care centers, shelters."
      },
      {
          "Term:": "Open Dated",
          "Definition:": "Products that are not dated or are dated in a code that is legible only to someone able to read the manufacturers coding system."
      },
      {
          "Term:": "Open Site",
          "Definition:": "A site at which meals are made available to all children in the area and where at least 50 percent of the children are from households that would be eligible for free or reduced-price school meals under the National School Lunch Program (NSLP) or the School Breakfast Program (SBP).  See Site; Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      
      {
          "Term:": "Operating Costs",
          "Definition:": "The cost of operating a food service (such as under the Summer Food Service Program): Including:Cost of obtaining food, Labor directly involved in the preparation and service of food, Cost of nonfood supplies, Rental and use allowances for equipment and space, and Cost of transporting children in rural areas to feeding sites in rural areas, but Excluding: Cost of the purchase of land, acquisition or construction of buildings, Alteration of existing buildings, Interest costs, Value of in-kind donations, and Adminstrative costs http://www.fns.usda.gov/cnd/summer/"
      },
     
      {
          "Term:": "Operating Reserves",
          "Definition:": "(As defined by the CFO best practices team on Operating Reserves) These are unrestricted net assets set aside by the Board or per Board policy. Equity in property, plant and equipment, the value of inventory, and any other board-designated net assets are excluded from available unrestricted net assets in the reserves calculation."
      },
      
      {
          "Term:": "Outreach Plan",
          "Definition:": "A plan created and submitted to the U.S. Department of Agriculture’s Food and Nutrition Service by state agencies that administer the Supplemental Nutrition Assistance Program (SNAP) and/or SNAP outreach; can include food banks as subcontractors.  http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "Over the Counter ",
          "Definition:": "Nonprescription medication that may or may not be a controlled substance.  Certain controlled substances may require Drug and Enforcement Agency (DEA) registration for distribution.  This includes products such as aspirin, cold and cough medicine, and nasal sprays."
      },
      {
          "Term:": "OTC",
          "Definition:": "Over the Counter. Nonprescription medication that may or may not be a controlled substance.  Certain controlled substances may require Drug and Enforcement Agency (DEA) registration for distribution.  This includes products such as aspirin, cold and cough medicine, and nasal sprays."
      },
      {
          "Term:": "Overage",
          "Definition:": "Freight that exceeds the quantity shown on the shipping document."
      },
      {
          "Term:": "Overlapping Service Area",
          "Definition:": "(As defined in the Feeding America Member Contract) A geographical area that is included in the service areas of two or more members."
      },
      {
          "Term:": "Pack Date",
          "Definition:": "Indicates the date a product was manufactured, processed or packaged."
      },
      {
          "Term:": "Pack Size",
          "Definition:": "The size of the individual units of case goods."
      },
      {
          "Term:": "Paid Meal Certification",
          "Definition:": "A classification within the child nutrition programs where children pay most of the cost for receiving meals and snacks.  Through the five child nutrition programs, the federal government pays some of the administrative costs.  Children from families with incomes above 185 percent of poverty pay for meals and snacks."
      },
      {
          "Term:": "Pallet",
          "Definition:": "A device used for moving and storing freight.  It is used as a base for assembling, storing, stacking, handling and transporting goods as a unit load.  Commonly, a pallet is about four feet square and is constructed to facilitate the placement of a lift truck’s forks between the levels of a platform so it can be moved onto a freight car or into a warehouse.  See CHEP pallet."
      },
     
      {
          "Term:": "Pallet Exchange",
          "Definition:": "The process of returning the same number of pallets to the donor, shipper or carrier as was used to move the donated product to the member."
      },
      {
          "Term:": "Pallet Jack",
          "Definition:": "A portable device used for raising and moving heavy objects (pallets) by means of hydraulic pressure.  See Hand Jack."
      },
      {
          "Term:": "Pantry",
          "Definition:": "See Food Pantry."
      },
      {
          "Term:": "Paper Product Household",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Paper Product Household Plates, Napkins, Towels, Toilet Paper, Facial Tissue."
      },
      {
          "Term:": "Paper Product Personal",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Paper Product Personal Diapers, Adult Sanitary Products, Feminine Products."
      },
      {
          "Term:": "Participation Grant",
          "Definition:": "USDA regularly offers grants to support efforts by state agencies and their community-based and faith-based partners to develop and implement process improvements to increase participation in SNAP. Examples of process improvements include simplified SNAP application and eligibility determination systems or business process re-engineering. Funding for these grants was authorized under the Food and Nutrition Act of 2008."
      },
      {
          "Term:": "Partner Distribution Organization (PDO)",
          "Definition:": "(As defined in the Feeding America Member Contract) A 501(c)(3) organization or a wholly owned subsidiary of a 501(c)(3) organization that does not have direct membership in the network but fulfills primary member functions (product distribution management, agency relations management, food solicitation, fundraising for hunger related activities, media and community relations for hunger related activities) on behalf of the member through a defined portion of a member’s service area. Each PDO will have a contractually defined geographic service area in which it is contractually obligated to provide specific food banking and/or food rescue services. The sum total of the services provided by the PDO and the member, in the PDO service area, will meet the contractual obligations of the member as outlined in the Member Contract. PDO must be physically located within the officially designated area as specified in Appendix A (of the Feeding America Member Contract). All PDO’s will be monitored on an annual basis by the member ultimately responsible for the area served."
      },
      
      {
          "Term:": "Partner State Association (PSA)",
          "Definition:": "A charitable organization whose membership is minimally comprised of a simple majority of Feeding America members AND whose members share a core function of food banking and food distribution to needy individuals. the PSA HungerNet page"
      },
      {
          "Term:": "Party",
          "Definition:": "(As defined in the Feeding America Member Contract) For purposes of this Contract, the national office and the member shall each be referred to as a “Party,” and shall collectively be referred to as the “Parties.”"
      },
      {
          "Term:": "Parties",
          "Definition:": "(As defined in the Feeding America Member Contract) For purposes of this Contract, the national office and the member shall each be referred to as a “Party,” and shall collectively be referred to as the “Parties.”"
      },
      {
          "Term:": "Pass through Grant",
          "Definition:": "A type of restricted gift intended for network distribution over which Feeding America has no variance power regarding the use of the transferred assets. The Feeding America national office must pass through amounts to specific member organizations as directed by the donor. Pass- through grants are not counted as revenue (approved 10/26/09).  See Variance Power."
      },
      
      {
          "Term:": "Pasta",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Pasta such as Macaroni, Spaghetti, Noodles."
      },
      {
          "Term:": "PEAC",
          "Definition:": "Policy Engagement Advocacy Committee"
      },
      {
          "Term:": "Peer to Peer Mentoring",
          "Definition:": "A process where two or more individuals work together to review and share current practices; expand, refine, and build new skills; share ideas; teach one another; conduct research; or solve problems in the workplace. The goal of the peer-to-peer mentoring process is to support colleagues in their professional development and growth, facilitate mutual learning opportunities, and build a sense of community."
      },
      {
          "Term:": "Perishables",
          "Definition:": "(As defined in the Feeding America Member Contract) Food products which are subject to decay or spoilage within a limited amount of time, unlike shelf-stable products which retain acceptable quality for human consumption over an extended period of time as defined by current professional food safety standards."
      },
      {
          "Term:": "Perishable Foods",
          "Definition:": "(As defined in the Feeding America Member Contract) Food products which are subject to decay or spoilage within a limited amount of time, unlike shelf-stable products which retain acceptable quality for human consumption over an extended period of time as defined by current professional food safety standards."
      },
      {
          "Term:": "Permanently Restricted Net Assets",
          "Definition:": "(As defined by the CFO best practices team on Operating Reserves) Assets that have been restricted by donor or law to be maintained by the organization in perpetuity.  An example would be an endowment fund. The net assets are not available for general use and are excluded from the reserve calculations."
      },
      
      {
          "Term:": "Personnel Protective Equipment",
          "Definition:": "Used to reduce exposure to chemical, physical or biological hazards in the workplace."
      },
      {
          "Term:": "PPE",
          "Definition:": "Personnel Protective Equipment. Used to reduce exposure to chemical, physical or biological hazards in the workplace."
      },
      {
          "Term:": "Pest",
          "Definition:": "Any objectionable animal or insect, including birds, rodents, flies, or larvae."
      },
      {
          "Term:": "Pest Control Operator",
          "Definition:": "Licensed by the governing state regulatory authority to conduct pest control activities at commercial food facilities, including but not limited to the application and storage of pest control equipment and chemical agents."
      },
      {
          "Term:": "PCO",
          "Definition:": "Pest Control Operator Licensed by the governing state regulatory authority to conduct pest control activities at commercial food facilities, including but not limited to the application and storage of pest control equipment and chemical agents."
      },
      {
          "Term:": "Pesticide",
          "Definition:": "Any substance or mixture of substances that is intended for preventing, destroying, repelling, or mitigating any pest."
      },
      {
          "Term:": "Pet",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Pet Food and Pet Care."
      },
      {
          "Term:": "Phenylpropanolamine",
          "Definition:": "An ingredient that was used in many OTC and prescription cough and cold medications as a decongestant and in OTC weight loss products.  Refer to the Member Contract, Appendix B, Section 2B, 3. a.,b.,c.  for specific contract requirements for handling PPA-containing products."
      },
      {
          "Term:": "PPA",
          "Definition:": "Phenylpropanolamine. An ingredient that was used in many OTC and prescription cough and cold medications as a decongestant and in OTC weight loss products.  Refer to the Member Contract, Appendix B, Section 2B, 3. a.,b.,c.  for specific contract requirements for handling PPA-containing products."
      },
      {
          "Term:": "PIDI",
          "Definition:": "The database of record of the Philanthropy team that tracks all gifts and relationships with donors to Feeding America."
      },
      {
          "Term:": "Piggy Back",
          "Definition:": "Cargo containers traveling by railroad."
      },
      {
          "Term:": "PIO",
          "Definition:": "Public Information Officer"
      },
      {
          "Term:": "Plant",
          "Definition:": "A manufacturing factory that processes raw materials to create finished products."
      },
      {
          "Term:": "Pledge",
          "Definition:": "A written commitment by a donor to make a gift over a defined period of time."
      },
      {
          "Term:": "POD",
          "Definition:": "Point of Distribution"
      },
      {
          "Term:": "Point of Purchase",
          "Definition:": "Materials and/or displays at retail checkout areas."
      },
      {
          "Term:": "POP",
          "Definition:": "Point of Purchase. Materials and/or displays at retail checkout areas."
      },
      {
          "Term:": "Point of Sale",
          "Definition:": "Collection point at retail stores for information about purchases; tabulating the data captured provides information for better product forecasting and inventory control."
      },
      {
          "Term:": "POS",
          "Definition:": "Point of Sale. Collection point at retail stores for information about purchases; tabulating the data captured provides information for better product forecasting and inventory control."
      },
      {
          "Term:": "Toxic Materials",
          "Definition:": "Substances not intended for ingestion and are included in four categories: A.  Cleaners  and  sanitizers,  which  include  cleaning  and  sanitizing  agents and  agents  such  as  caustics,  acids,  drying  agents,  polishes,  and  other chemicals; Pesticides,    which    include    substances    such    as    insecticides    and rodenticides; Pesticides,    which    include    substances    such    as    insecticides    and rodenticides; D. Substances that are not necessary for the operation and maintenance of the   establishment   and   are   on   the   premises   for   retail   sale,   such   as petroleum products and paints."
      },
      {
          "Term:": "Poisonous Materials",
          "Definition:": "Substances not intended for ingestion and are included in four categories: A.  Cleaners  and  sanitizers,  which  include  cleaning  and  sanitizing  agents and  agents  such  as  caustics,  acids,  drying  agents,  polishes,  and  other chemicals; Pesticides,    which    include    substances    such    as    insecticides    and rodenticides; Pesticides,    which    include    substances    such    as    insecticides    and rodenticides; D. Substances that are not necessary for the operation and maintenance of the   establishment   and   are   on   the   premises   for   retail   sale,   such   as petroleum products and paints."
      },
      
      {
          "Term:": "Portion Pack",
          "Definition:": "The packaging of individual-sized portions, such as single servings."
      },
      {
          "Term:": "Potentially Hazardous Food",
          "Definition:": "Food that is natural or synthetic and that requires temperature control because it is in a form capable of supporting: A. The rapid and progressive growth of infectious or toxigenic microorganisms; B. The growth and toxin production of Clostridium botulinum: or C. In raw shell eggs, the growth of Salmonella enteritidis. Potentially Hazardous Food includes a food of animal origin that is raw or heat-treated; a food of plant origin that is heat-treated or consists of raw seed sprouts; cut melons; and garlic in oil mixtures that are not acidified or otherwise modified at a food processing plant in a way that results in mixtures that do not support growth."
      },
      
      
      {
          "Term:": "Poultry",
          "Definition:": "Any domesticated bird (chickens, turkeys, ducks, geese, guineas, ratites, or squabs)."
      },
      {
          "Term:": "Pounds per Person in Poverty",
          "Definition:": "Pounds Per Person in Poverty is defined as the ratio of number of total pounds distributed into a specific area, divided by the number of persons at 100% or below the poverty threshold living in that area.  For this analysis, PPIP is calculated by county for every county in the U.S. and Puerto Rico."
      },
      {
          "Term:": "PPIP",
          "Definition:": "Pounds Per Person in Poverty is defined as the ratio of number of total pounds distributed into a specific area, divided by the number of persons at 100% or below the poverty threshold living in that area.  For this analysis, PPIP is calculated by county for every county in the U.S. and Puerto Rico."
      },
      {
          "Term:": "Poverty Guidelines",
          "Definition:": "The administrative version of the poverty measure.  Guidelines are issued by the Department of Health and Human Services and are a simplification of the poverty thresholds used in determining financial eligibility for certain federal programs."
      },
      {
          "Term:": "Poverty Threshold",
          "Definition:": "The statistical version of the poverty measure; figures are issued by the Census Bureau and used for calculating the number of persons in poverty in the U.S.  The poverty threshold is updated each March in the Federal Register.  The threshold corresponds to household size."
      },
      
      {
          "Term:": "Prepared and Perishable Food",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Prepared and Perishable Food.  See Prepared Foods; Perishables."
      },
      {
          "Term:": "Prepared Foods",
          "Definition:": "(As defined in the Feeding America Member Contract) Any food product not packaged for commercial or consumer distribution (excluding bakery and produce) and those foods packaged for immediate meal service that is prepared by a local or central commissary."
      },
      {
          "Term:": "Prerequisite Programs",
          "Definition:": "Food facility programs that lay out the foundation for food safety and Hazard Analysis Critical Control Points (HACCP) and create the environment for producing, receiving, storing and distributing clean and safe food."
      },
      {
          "Term:": "Prescreening Tool",
          "Definition:": "A computer program that estimates an individual’s eligibility for various income support programs, such as food stamps.  The U.S. Department of Agriculture (USDA) has developed a web-based prescreening tool. http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "Press Release",
          "Definition:": "A press release is a prepared publicity or news announcement about an event, issue, or other newsworthy information."
      },
      {
          "Term:": "Price",
          "Definition:": "The amount a business charges for a product or service. For example, a wholesaler offers a case of beans at a price of $15.35. A food bank offers a case of beans at a price of $17.00. Very often, a price will be the sum of the costs incurred to provide the product, plus a profit margin for the business."
      },
      {
          "Term:": "Primary Partner",
          "Definition:": "The one person who is best positioned and suited to personally ask the prospect for the gift."
      },
      {
          "Term:": "Private Label",
          "Definition:": "Product that is manufactured under a retailer’s or wholesaler’s name.  For example, Costco’s private label is Kirkland; Target’s private label is Archer Farms and Market Pantry; Kroger’s private label carries the Kroger name."
      },
      {
          "Term:": "Private Nonprofit",
          "Definition:": "Tax exempt under the Internal Revenue Code of 1986."
      },
      {
          "Term:": "Private Nonprofit Organization",
          "Definition:": "An organization (other than private nonprofit residential camps, school food authorities, or colleges or universities participating in the National Youth Sports Program) that meets the definition of “private nonprofit” and which: a. Administers the Summer Food Service Program: 1. At no more than 25 sites, with not more than 300 children being served at any 2. Approved meal service at any one site, or 3. With a waiver granted by the state in accordance with §225.6(b)(5)(ii), not more than 500 children being served at any approved meal service at any one site Operates in areas where a school food authority has not indicated that it will operate the program in the current year Exercises full control and authority over the operation of the program at all sites under its sponsorship. Provides ongoing year-round activities for children or families.  Demonstrates that it possesses adequate management and the fiscal capacity to operate the program, and Meets applicable state and local health, safety, and sanitation standards See Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      
      {
          "Term:": "Probate",
          "Definition:": "The process of proving a will’s validity; used loosely to mean the administration of an estate."
      },
      {
          "Term:": "Processor",
          "Definition:": "A converter of raw material into a finished consumer product."
      },
      {
          "Term:": "Produce and Perishable Programs",
          "Definition:": "State appropriations designated for food banks to specifically purchase produce and perishable food items."
      },
      {
          "Term:": "Product Category or Product Type",
          "Definition:": "Food and non-food categories of product donations as reported in the Quarterly Poundage Reports (QPRs)."
      },
      {
          "Term:": "Product Cost",
          "Definition:": "The cost of manufacturing an individual product (cost per unit or base cost)."
      },
      {
          "Term:": "Product Valuation Study",
          "Definition:": "Annual study conducted by the national office to determine the average wholesale value of a pound of donated product.  The results are used to determine the value of product received throughout the year, as well as year-end inventories."
      },
      {
          "Term:": "Production Alliance",
          "Definition:": "A joint venture between a product donor and a food bank to use philanthropic dollars to produce first-line products for donation."
      },
      {
          "Term:": "Production Overrun",
          "Definition:": "A situation in which a manufacturer creates more finished goods than the market can absorb.  Overruns can be caused by the original commitment to the quantity of raw materials purchased, an attempt to stabilize production costs, quantity discounts, or fluctuating markets."
      },
      {
          "Term:": "Profit Margin and Mark-up",
          "Definition:": "The mathematical difference between the delivered cost of a purchased food item and the selling price to an agency.  Very often it is expressed as a percentage of sale price.  This is different than a mark-up, which is the same absolute value, however, expressed as a percentage of the delivered cost."
      },
     
      {
          "Term:": "Program Funds",
          "Definition:": "Federal financial assistance made available to state agencies for the purpose of making program payments.  See Summer Food Service Program (SFSP).  http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Program or Project “Umbrella’d” by the Feeding America Participant",
          "Definition:": "This instance applies when a Feeding America participant takes on an activity under its 501(c)(3) status and is responsible for the provision and direct distribution of food. Examples of utilizing a distributing agent includes: a school acting as the distributing agent for the Feeding America participant in a BackPack Program or serving as a host site for a Kids Cafe; and housing projects where food is delivered for direct distribution to low income individuals. Under this model the Feeding America participant retains sole title and responsibility for the food and any liability that may result. At no time may the non-501(c)(3) group pay shared maintenance or any other type of fee for donated food."
      },
      {
          "Term:": "Program Umbrella",
          "Definition:": "This instance applies when a Feeding America participant takes on an activity under its 501(c)(3) status and is responsible for the provision and direct distribution of food. Examples of utilizing a distributing agent includes: a school acting as the distributing agent for the Feeding America participant in a BackPack Program or serving as a host site for a Kids Cafe; and housing projects where food is delivered for direct distribution to low income individuals. Under this model the Feeding America participant retains sole title and responsibility for the food and any liability that may result. At no time may the non-501(c)(3) group pay shared maintenance or any other type of fee for donated food."
      },
      {
          "Term:": "Project Umbrella",
          "Definition:": "This instance applies when a Feeding America participant takes on an activity under its 501(c)(3) status and is responsible for the provision and direct distribution of food. Examples of utilizing a distributing agent includes: a school acting as the distributing agent for the Feeding America participant in a BackPack Program or serving as a host site for a Kids Cafe; and housing projects where food is delivered for direct distribution to low income individuals. Under this model the Feeding America participant retains sole title and responsibility for the food and any liability that may result. At no time may the non-501(c)(3) group pay shared maintenance or any other type of fee for donated food."
      },
      {
          "Term:": "Program Participant",
          "Definition:": "A Feeding America member food bank or its approved partner distribution organization (PDO) that is coordinating a program."
      },
      {
          "Term:": "Program Partner",
          "Definition:": "A nonprofit organization that a member partners with to operate a Feeding America national program, such as Kids Cafe or the BackPack Program."
      },
      {
          "Term:": "Program Payments",
          "Definition:": "Financial assistance in the form of start-up payments, advance payments, or reimbursement paid to sponsors for operating and administrative costs. See Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Program Sponsor",
          "Definition:": "An organization that sponsors one or more programs, such as the U.S. Department of Agriculture’s (USDA) Child and Adult Care Food Program (CACFP) or the Summer Food Service Program (SFSP), provides meals or snacks to qualified sites, and receives USDA reimbursement for the meals or snacks served.  http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "Promising Practices",
          "Definition:": "A program, activity, strategy or process that has worked within one food bank and shows promise during its early stages for becoming a best practice with long term sustainable impact.  A promising practice must have some objective basis for claiming effectiveness and the potential for replication among other organizations."
      },
      
      {
          "Term:": "Prospect",
          "Definition:": "An individual or family foundation identified as having a combination of interest, capacity and linkage to the Feeding America network."
      },
      {
          "Term:": "Protein",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Protein – Non-Meat such as Peanut Butter, Beans, Eggs, Pork and Beans, Nuts."
      },
      {
          "Term:": "Pseudoephedrine (PSE)",
          "Definition:": "A drug found in many OTC products and is used to relieve nasal or sinus congestion caused by the common cold, sinusitis, and respiratory allergies. Refer to the Member Contract, Appendix B, Section 2B, 3. a.,b.,c. for specific contract requirements for handling PSE-containing products."
      },
      {
          "Term:": "PSE",
          "Definition:": "Pseudoephedrine. A drug found in many OTC products and is used to relieve nasal or sinus congestion caused by the common cold, sinusitis, and respiratory allergies. Refer to the Member Contract, Appendix B, Section 2B, 3. a.,b.,c. for specific contract requirements for handling PSE-containing products."
      },
      {
          "Term:": "Public Charge",
          "Definition:": "Immigrants who become primarily dependent on the government for subsistence may be denied adjustment to permanent resident status, or they may be deported on the grounds they have become a “public charge.”  Nutrition programs have been specifically excluded from consideration in public charge determinations.  This includes food stamps, the Special Supplemental Nutrition Program for Women, Infants, and Children (WIC), school meals programs, and other supplementary and emergency food assistance programs.  Confusion about public charge keeps some immigrants from accessing nutrition benefits for which they or other household members are eligible.  http://www.usda.gov/wps/portal/usda/usdahome"
      },
     
      {
          "Term:": "Public Service Announcement",
          "Definition:": "A free advertisement run by a radio or television station."
      },
      {
          "Term:": "PSA",
          "Definition:": "Public Service Announcement. A free advertisement run by a radio or television station."
      },
      {
          "Term:": "Pull by Date",
          "Definition:": "Also referred to as the sell-by date.  The last date a product should be offered for sale allowing time for home use under proper storage conditions.  Generally used for perishable products such as meats, dairy, refrigerated juices, and fresh baked goods."
      },
      {
          "Term:": "Purchase Program",
          "Definition:": "Purchase of food and nonfood products by a member to supplement the products available through donations."
      },
      {
          "Term:": "Qualification",
          "Definition:": "Step two in the relationship management cycle. The process of qualification encompasses additional research and discovery visits with prospects to ascertain their particular interest."
      },
      {
          "Term:": "Qualified Immigrants",
          "Definition:": "Refers to legal immigrants and their eligibility for federal public benefits.  Most qualified immigrants entering the U.S. after August 22, 1996 are barred from receiving federal benefits, including food stamps, for five years.  Eligibility for food stamps has been restored to immigrant children, the disabled, and some elderly immigrants.  The term “qualified immigrants” was created in the 1996 welfare reform legislation, P.L. 104- 193, and refers specifically to: lawful permanent residents, refugees, Cuban and Haitian entrants, aliens paroled into the U.S. for a period of at least one year, aliens granted withholding of deportation, aliens granted conditional entry into the U.S., and certain battered alien spouses and children.  http://www.usda.gov/wps/portal/usda/usdahome"
      },
      
      {
          "Term:": "Qualified Retirement Plan",
          "Definition:": "A retirement plan is eligible for favorable tax treatment."
      },
      {
          "Term:": "Quality Control Program",
          "Definition:": "Program required of Feeding America members handling reclamation center products; involves methodical double-checking of the quality of the evaluation/inspection program.  Requirements are outlined in a supplement to the Feeding America Food Safety and Handling Manual."
      },
      {
          "Term:": "QC",
          "Definition:": "Quality Control Program. Program required of Feeding America members handling reclamation center products; involves methodical double-checking of the quality of the evaluation/inspection program.  Requirements are outlined in a supplement to the Feeding America Food Safety and Handling Manual."
      },
      {
          "Term:": "Quarterly Poundage Report",
          "Definition:": "A set of two detailed reports prepared quarterly by members that track poundage received and distributed.  Data from these reports are published annually in the Network Activity Report, and are used to provide information to donors, funders, media, both internal and external auditors, public policy decision makers, and management."
      },
      {
          "Term:": "QPR",
          "Definition:": "Quarterly Poundage Report. A set of two detailed reports prepared quarterly by members that track poundage received and distributed.  Data from these reports are published annually in the Network Activity Report, and are used to provide information to donors, funders, media, both internal and external auditors, public policy decision makers, and management."
      },
      {
          "Term:": "Random Weight",
          "Definition:": "Refers to meat and cheeses that arrive at stores as large pieces and are cut and sliced to order."
      },
      {
          "Term:": "Rate",
          "Definition:": "The fee charged by a trucking company for transporting goods, usually set by the miles driven."
      },
      {
          "Term:": "Raw",
          "Definition:": "When referring to food, an uncooked state and/or a state in which a kill step has not been applied to reduce the presence of biological contamination."
      },
      {
          "Term:": "RCCI",
          "Definition:": "Residential Child Care Institution"
      },
      {
          "Term:": "Ready to Eat Food",
          "Definition:": "Food that is edible without further washing, cooking, or additional preparation and that is reasonably expected to be consumed in that form."
      },
      {
          "Term:": "RTE",
          "Definition:": "Ready to Eat Food. Food that is edible without further washing, cooking, or additional preparation and that is reasonably expected to be consumed in that form."
      },
      {
          "Term:": "Real Property",
          "Definition:": "Land, buildings, or other forms of real estate."
      },
      {
          "Term:": "Recall",
          "Definition:": "The voluntary removal or correction in the field by a company, of product that may be considered adulterated or misbranded according to federal, state, or local regulations, or may not comply with government regulations, or may fail to meet the manufacturer’s product specification."
      },
      {
          "Term:": "Recall Classification",
          "Definition:": "The numerical designation, i.e. I, II, III, assigned by the regulatory agency to a particular product recall that indicates the relative degree of health hazard presented by the product being recalled. Class I – situation where there is a strong likelihood that the use of, or exposure to, an adulterated or misbranded product will cause serious, adverse health consequences or death Class II – situation in which the use of, or exposure to an adulterated or misbranded product may cause temporary or medically reversible adverse health consequences or where the probability of serious adverse health consequences is remote Class III – situation in which the use of, or exposure to, an adulterated or misbranded product is not likely to cause adverse health consequences."
      },
      
      {
          "Term:": "Recall Completed Recall Terminated",
          "Definition:": "The classification status used for monitoring purposes when the recall reaches the point at which the food bank has retrieved and/or corrected all outstanding product that could be reasonably expected to be recovered. A recall will be officially terminated when the regulatory agency determines that all reasonable efforts have been made to remove or correct the adulterated or misbranded product."
      },
      {
          "Term:": "Recall Strategy",
          "Definition:": "The course of action recommended by or to the recalling firm in order to achieve its goals."
      },
      {
          "Term:": "Recalling Firm",
          "Definition:": "The food bank that initiates a recall, or in case of a regulatory requested recall, the food bank that has primary responsibility for the distribution of the product to be recalled."
      },
      {
          "Term:": "Receipt",
          "Definition:": "Document prepared by a member of Feeding America that acknowledges a donation.  This document includes information on quantities, product type, location, and poundage."
      },
      {
          "Term:": "Reclamation Center",
          "Definition:": "Often operated by or for retail grocery companies, a facility through which all of that chain’s returns and damaged product are handled.  Each product is scanned to identify manufacturer and product value.  Manufacturers are billed for credits on these products and will either pick the product up, request that it be dumped, or release it for donation."
      },
      {
          "Term:": "Rec Center",
          "Definition:": "Reclamation Center. Often operated by or for retail grocery companies, a facility through which all of that chain’s returns and damaged product are handled.  Each product is scanned to identify manufacturer and product value.  Manufacturers are billed for credits on these products and will either pick the product up, request that it be dumped, or release it for donation."
      },
      {
          "Term:": "Recreational Activities",
          "Definition:": "Activities that are meant to restore and refresh children such as physical fitness, sports, arts, drama, or music."
      },
      {
          "Term:": "Redistribution Organization",
          "Definition:": "(As defined in the Feeding America Member Contract) A 501(c)(3) organization or a wholly owned subsidiary of a 501(c)(3) organization that a member contracts with for the purpose of the logistical transfer of food and grocery product which will include one or more, but not all, of the following primary member functions: product distribution management, agency relations management, food solicitation, fundraising for hunger related activities, media and community relations for hunger related activities. The sum total of the services provided by the RDO and the member, in the defined RDO service area, will meet the contractual obligations of the member as outlined in the Member Contract. RDO facilities must be physically located within the officially designated area as specified in Appendix A (of the Feeding America Member Contract). All RDO’s will be monitored on an annual basis by the member ultimately responsible for the area served."
      },
      {
          "Term:": "RDO",
          "Definition:": "Redistribution Organization. (As defined in the Feeding America Member Contract) A 501(c)(3) organization or a wholly owned subsidiary of a 501(c)(3) organization that a member contracts with for the purpose of the logistical transfer of food and grocery product which will include one or more, but not all, of the following primary member functions: product distribution management, agency relations management, food solicitation, fundraising for hunger related activities, media and community relations for hunger related activities. The sum total of the services provided by the RDO and the member, in the defined RDO service area, will meet the contractual obligations of the member as outlined in the Member Contract. RDO facilities must be physically located within the officially designated area as specified in Appendix A (of the Feeding America Member Contract). All RDO’s will be monitored on an annual basis by the member ultimately responsible for the area served."
      },
      {
          "Term:": "Reduced Price Meal Certification",
          "Definition:": "A classification within the child nutrition programs indicating that a child is able to receive reduced-price meals and snacks.  Students cannot be charged more than $0.40 for reduced-price lunches or $0.30 for reduced- price breakfasts.  Children from families with income between 130 percent and 185 percent of the Federal Poverty Level are certified for reduced-price meals."
      },
      
      {
          "Term:": "Reefer",
          "Definition:": "Refrigerated truck or a refrigerator."
      },
      {
          "Term:": "Re Entry",
          "Definition:": "A situation where product is illegally reintroduced to the marketplace."
      },
      {
          "Term:": "Re Granting",
          "Definition:": "Awarding grants to network members from a grant originally made to the national office."
      },
      {
          "Term:": "Regional Associations",
          "Definition:": "Feeding America members grouped by geographic region, who meet periodically to share information and discuss policy. The three associations are: The Eastern Region Association, The Central Region Association The Western Region Association. See Regions."
      },
     
      {
          "Term:": "Regional Distribution Center (RDC)",
          "Definition:": "A facility that serves a region rather than just one location.  A regional warehouse can service other branch warehouses, service customers directly, or service both."
      },
      {
          "Term:": "RDC",
          "Definition:": "Regional Distribution Center. A facility that serves a region rather than just one location.  A regional warehouse can service other branch warehouses, service customers directly, or service both."
      },
      {
          "Term:": "Regions",
          "Definition:": "The Feeding America network is divided into three administrative units: the Atlantic coast (Eastern Region), the Pacific coast and Rocky Mountain states plus Hawaii and Alaska (Western Region) and the area between the Rockies and the Appalachians (Central Region).  See Regional Associations."
      },
     
      {
          "Term:": "Regulatory Requested Recall",
          "Definition:": "A recall initiated by the food bank in response to a formal request from a regulatory authority."
      },
      {
          "Term:": "Reimbursement",
          "Definition:": "State agencies and nonprofit organizations can receive up to a 50% reimbursement for allowable activities for Supplemental Nutrition Assistance Program (SNAP) outreach, as approved in the outreach plan. http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "Relationship Manager",
          "Definition:": "A Philanthropy, Strategic Gifts, Cause Marketing, or Product Sourcing team member that is assigned to manage the relationship between a specific donor or prospect and Feeding America (the national office?). Relationship managers are responsible for facilitating appropriate communication, recording significant interactions, and submitting all related documentary materials to record the history of the relationship. Relationship managers are also responsible for understanding and communicating donor intent."
      },
      
      {
          "Term:": "Repack",
          "Definition:": "The process of removing a product from one container and packaging it into another."
      },
      {
          "Term:": "Repetitive Contact",
          "Definition:": "The amount of repeated contact that results in the potential for a person to develop a relationship with a child outside of the program."
      },
      {
          "Term:": "Request for Proposal (RFP)",
          "Definition:": "An invitation from Feeding America to members or agencies to formally apply for a member grant."
      },
      {
          "Term:": "RFP",
          "Definition:": "Request for Proposal. An invitation from Feeding America to members or agencies to formally apply for a member grant."
      },
      {
          "Term:": "Restricted Gifts",
          "Definition:": "Gifts in which a donor places conditions on the gift or identifies the specific use of the gift. Only donors can restrict gifts. Donors may also give unrestricted gifts."
      },
      {
          "Term:": "Restricted Open Site",
          "Definition:": "A site which is initially open to broad community participation, but at which the sponsor restricts or limits attendance for reasons of security, safety or control. Site eligibility for a restricted open site shall be documented in accordance with paragraph (a) of the definition of “areas in which poor economic conditions exist.  See Site; Areas in which Poor Economic Conditions Exist; See Summer Food Service Program (SFSP). http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Retail Trade",
          "Definition:": "The activities involved in selling directly to the consumer."
      },
      {
          "Term:": "Retailer",
          "Definition:": "A merchant whose main business is selling directly to the consumer in single-unit quantities."
      },
      {
          "Term:": "Return on Investment",
          "Definition:": "A financial measure based on the ratio of income derived from an investment or project, divided by the cost of assets devoted to the project."
      },
      {
          "Term:": "ROI",
          "Definition:": "Return on Investment. A financial measure based on the ratio of income derived from an investment or project, divided by the cost of assets devoted to the project."
      },
      {
          "Term:": "Revocable Trust",
          "Definition:": "A trust that can be changed or dissolved at any time by the grantor."
      },
      {
          "Term:": "Rework",
          "Definition:": "A manufacturer’s process of repackaging a product due to distribution or production errors."
      },
      {
          "Term:": "Rice",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Rice."
      },
      {
          "Term:": "Rotation",
          "Definition:": "The practice of moving older stock forward when restocking shelves or cases so that the oldest product is in the first spot to move out.  See First In First Out (FIFO)."
      },
      {
          "Term:": "Rural",
          "Definition:": "Any area in a county which is not part of a Metropolitan Statistical Area, or Any “pocket” within a Metropolitan Statistical Area which, at the option of the state agency and with the Food and Nutrition Service Regional Office concurrence, is determined to be geographically isolated from urban areas. http://www.usda.gov/wps/portal/usda/usdahome"
      },
      
     
      {
          "Term:": "Safe Environment",
          "Definition:": "This includes the physical safety of the building and equipment; safe practices in food handling, preparation, distribution and storage; and supervision by adults that have passed national criminal background checks."
      },
      {
          "Term:": "Safe Food Handlers",
          "Definition:": "Any staff or volunteer who handles food, including preparation and service, must pass required local health department food safety training, or equivalent food safety training such as the ServSafe training course, and have a current/valid safe food handler’s certification."
      },
      {
          "Term:": "Salvage",
          "Definition:": "Product that has been damaged either at the warehouse or the retail level; it typically passes through reclamation centers."
      },
      {
          "Term:": "Sanitizer",
          "Definition:": "Post-cleaning chemical used on food contact surfaces to eliminate and prevent microbiological contamination."
      },
      {
          "Term:": "Scanner",
          "Definition:": "An electronic mechanism that reads a Universal Product Code (UPC) and translates it into item description and price.  See Universal Product Code (UPC)."
      },
      {
          "Term:": "School Based Pantry Program",
          "Definition:": "School Based Pantries are located on the grounds of a school and intended to provide a more readily accessible source of food assistance to low- income students and their families. Sites are consistently in the same location of the school’s campus, have set distribution schedules and offer ongoing food assistance services.  School based pantries may have a permanent set up within a school, or may operate through a mobile distribution rotation where food is brought to the school campus.  If a food bank operates a School Pantry Program, the national office should have a signed program agreement on file."
      },
      
     
      {
          "Term:": "School Breakfast Program (SBP)",
          "Definition:": "A federally assisted meal program that operates in the same manner as the National School Lunch Program to provide low-cost or free breakfasts to children each school day. http://www.fns.usda.gov/cnd/Breakfast/Default.htm"
      },
      {
          "Term:": "SBP",
          "Definition:": "School Breakfast Program. A federally assisted meal program that operates in the same manner as the National School Lunch Program to provide low-cost or free breakfasts to children each school day. http://www.fns.usda.gov/cnd/Breakfast/Default.htm"
      },
      {
          "Term:": "School Food Authority",
          "Definition:": "The governing body that is responsible for the administration of one or more schools and that has the legal authority to operate a lunch program in those schools. In addition, for the purpose of determining the applicability of food service management company registration and bid procedure requirements, “school food authority” also means any college or university that participates in the program.  See Summer Food Service Program (SFSP).  http://www.fns.usda.gov/cnd/summer/"
      },
      
      {
          "Term:": "Scouting for Food",
          "Definition:": "Annual canned goods drive conducted by Boy Scout councils or districts on a model developed in St. Louis in 1985.  A good portion of Scouting for Food product is distributed through members."
      },
      {
          "Term:": "Seafood",
          "Definition:": "Fresh or saltwater finfish, crustaceans and other forms of aquatic life other than birds or mammals, and all mollusks, if such animal life is intended for human consumption.  Includes edible human food product derived in whole or in part from fish, including fish that have been processed in any manner."
      },
      {
          "Term:": "SeaShare",
          "Definition:": "Formerly Northwest Food Strategies, a nonprofit organization that facilitates the distribution of seafood to other nonprofits. The intent of SeaShare’s program is to increase the amount of portioned, packaged seafood available for food banks, food pantries, soup kitchens, shelters and hospices."
      },
      {
          "Term:": "Secondary market",
          "Definition:": "The discount market for surplus and distressed goods used as an alternative to donating those goods."
      },
      {
          "Term:": "Section 32",
          "Definition:": "The Agriculture Act of 1935 provided a permanent appropriation, known as Section 32, which sets aside an amount equal to 30% of annual customs receipts specifically for the U.S. Department of Agriculture (USDA), to aid farmers and producers by purchasing surplus agricultural products.  These surplus products are then provided to child nutrition and charitable  feeding programs through The Emergency Food Assistance Program (TEFAP).  http://www.fns.usda.gov/fdd/programs/tefap/"
      },
     
      {
          "Term:": "Sell By Date",
          "Definition:": "The last date on which a product should be sold."
      },
      {
          "Term:": "Self Preparation Sponsor",
          "Definition:": "A sponsor that prepares the meals that will be served at its site(s) and does not contract with a food service management company for unitized meals, with or without milk, or for management services.  See Summer Food Service Program (SFSP).  http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Senior Nutrition Programs",
          "Definition:": "Senior nutrition programs focus on increasing access to nutritious food for seniors. State support is often targeted towards increasing purchasing power for seniors at farmers’ markets or supplementing federal senior nutrition programs."
      },
      {
          "Term:": "Service Area",
          "Definition:": "(As defined in the Feeding America Member Contract) An officially designated geographic area as specified in Appendix A (of the Feeding America Member Contract)."
      },
      {
          "Term:": "ServSafe",
          "Definition:": "Training program to help participants understand food contaminants, safe food handling procedures, and potential food poisoning situations. Training can be procured through state contacts.  The course involves two full days of training and an exam."
      },
     
      {
          "Term:": "Session",
          "Definition:": "A specified period of time during which an enrolled group of children attend camp."
      },
      {
          "Term:": "Sex Offender Registries",
          "Definition:": "All states have established sex offender registries. These databases are lists of individuals who have been convicted of criminal sexual conduct ranging from child molestation to rape. While the scope of offenses included in sex offender registries is limited, such registries offer an advantage that state criminal history record checks do not – they list sex offenders living in the state irrespective of where their convictions occurred. According to the law, individuals who have been convicted of specific sexual crimes are required to register when they move into a new state."
      },
      {
          "Term:": "Shared Maintenance Fee (SMF)",
          "Definition:": "The fee members charge agencies for distributed product.  Effective August 1, 2008, the shared maintenance/handling fee ceiling was raised to 19 cents per pound, up from the previous cap of 18 cents per pound.   Also known as the handling fee."
      },
      {
          "Term:": "SMF",
          "Definition:": "Shared Maintenance Fee. The fee members charge agencies for distributed product.  Effective August 1, 2008, the shared maintenance/handling fee ceiling was raised to 19 cents per pound, up from the previous cap of 18 cents per pound.   Also known as the handling fee."
      },
      {
          "Term:": "Sharing",
          "Definition:": "When a member distributes surplus or excess food to another member."
      },
      {
          "Term:": "Shelf Life",
          "Definition:": "The length of time a product can be kept for use before quality considerations make it necessary to remove the item from distribution."
      },
      {
          "Term:": "Shelf Stable",
          "Definition:": "A product that can be stored and merchandised without the need of refrigeration.  Also known as ambient or dry."
      },
      {
          "Term:": "Shiners",
          "Definition:": "An unlabeled can which must be labeled before a food bank can distribute the product. See Brites."
      },
      {
          "Term:": "Shrink Wrap",
          "Definition:": "Clear plastic film, conforming to the object or product it covers; often used to keep cases from shifting on a pallet. Also known as stretch wrap."
      },
      {
          "Term:": "Shrinkage",
          "Definition:": "The loss of product due to damage, theft, or miscounting and inventory errors."
      },
      {
          "Term:": "Site",
          "Definition:": "A physical location where a meal program sponsor provides food service for children and where children consume meals in a supervised setting."
      },
      {
          "Term:": "Site Size",
          "Definition:": "As defined by Child Hunger programs:"
      },
     
      {
          "Term:": "Slip Sheet",
          "Definition:": "A sheet of cardboard, fiberboard, or plastic used to handle unitized loads with a push/pull attachment."
      },
      {
          "Term:": "SBA",
          "Definition:": "Small Business Administration"
      },
      {
          "Term:": "SMP",
          "Definition:": "Special Milk Program"
      },
      {
          "Term:": "Snack",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Snack Food such as Cookies, Candy, Crackers, Marshmallows."
      },
      {
          "Term:": "SNAP State Funds",
          "Definition:": "State appropriations to support and/or increase access for the federal Supplemental Nutrition Assistance Program (SNAP), formerly named the Food Stamp Program. Appropriations may be designated for a variety of initiatives that increase support and access to SNAP benefits for eligible participants, some of these initiatives may be to increase the income level for eligibility, to support SNAP outreach efforts and trigger the 50% federal reimbursement, and/or to supplement the benefits that SNAP participants receive.  http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "Social Security History",
          "Definition:": "A social security history confirms that the social security number is assigned to the proper person."
      },
      {
          "Term:": "Socialization Activities",
          "Definition:": "Activities that promote the healthy interaction of children. Examples include life skills training, teamwork, and lessons in etiquette, values, or cultural understanding."
      },
      {
          "Term:": "Solicitation",
          "Definition:": "A request by Feeding America relationship managers to a prospective donor for a gift in support of Feeding America, or  (From the Relationship Management Handbook) Step four in the relationship management cycle. A prospect is considered to be in the solicitation stage if the strategy worksheet outlines that an ask will be made within the current fiscal year."
      },
     
      {
          "Term:": "SOP",
          "Definition:": "Standard Operating Procedure"
      },
      {
          "Term:": "Soup Kitchen",
          "Definition:": "A program that provides prepared meals on-site to clients in need who do not reside at the agency’s premises.  Also known as an emergency kitchen."
      },
      {
          "Term:": "Special Account",
          "Definition:": "An account that a state agency may require a vended sponsor to establish with the state agency or with a federally insured bank. Operating costs payable to the sponsor by the state agency are deposited in the account and disbursement of monies from the account must be authorized by both the sponsor and the food service management company.  See Summer Food Service Program (SFSP).  http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Special Report",
          "Definition:": "A Hunger Study report reflecting a specific and specially-requested area by the participating food bank member."
      },
     
      {
          "Term:": "Special Supplemental Nutrition Program for Women Infants and Children",
          "Definition:": "A federal grant program administered by state health departments or comparable agencies that provides nutritious foods, nutrition counseling, and referrals to health and other social services.  WIC serves low-income pregnant, postpartum, and breastfeeding women, and infants and children up to age 5 who are at nutrition risk.  http://www.fns.usda.gov/wic/"
      },
      {
          "Term:": "WIC",
          "Definition:": "Special Supplemental Nutrition Program for Women Infants and Children. A federal grant program administered by state health departments or comparable agencies that provides nutritious foods, nutrition counseling, and referrals to health and other social services.  WIC serves low-income pregnant, postpartum, and breastfeeding women, and infants and children up to age 5 who are at nutrition risk.  http://www.fns.usda.gov/wic/"
      },
      {
          "Term:": "Specialty License Plates",
          "Definition:": "Revenue generated by specialty license plates can be designated to food banks and/or state associations for hunger relief efforts. Feeding America has retained the services of FCC Matrix, who has contractual rights to the John Lennon “Imagine” image for specialty license plates."
      },
      {
          "Term:": "Sponsor",
          "Definition:": "A public or private nonprofit school food authority, a public or private nonprofit residential summer camp, a unit of local, municipal, county or state government, a public or private nonprofit college or university currently participating in the National Youth Sports Program, or a private nonprofit organization which develops a special summer or other school vacation program providing food service similar to that made available to children during the school year under the National School Lunch and School Breakfast Programs, and which is approved to participate in the program. Sponsors are referred to in the National School Lunch Act as “service institutions.”  http://www.fns.usda.gov/cnd/summer/"
      },
      
      {
          "Term:": "Standard Deduction",
          "Definition:": "In determining income eligibility for the Food Stamp Program, a household of one to three people may deduct $134 from monthly income.  The standard deduction is higher for larger households.  See Food Stamp Program; Supplemental Nutrition Assistance Program (SNAP). http://www.fns.usda.gov/snap/"
      },
      {
          "Term:": "Start up Payments",
          "Definition:": "Financial assistance made available to a sponsor for administrative costs to enable it to effectively plan a summer food service and to establish effective management procedures for such a service. These payments shall be deducted from subsequent administrative cost payments. http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "State",
          "Definition:": "Any of the 50 states, the District of Columbia, the Commonwealth of Puerto Rico, the Virgin Islands of the United States, Guam, American Samoa, the Trust Territory of the Pacific Islands, and the Northern Mariana Islands."
      },
      
      {
          "Term:": "State Agency",
          "Definition:": "The state educational agency or alternate agency that has been designated by the governor or other appropriate executive or legislative authority of the state and which has been approved by the U.S. Department of Agriculture to administer the Summer Food Service Program within the state, or in states where the Food and Nutrition Service administers the program, the Food and Nutrition Service Regional Office. http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "State Associations",
          "Definition:": "State Associations continue to achieve successes in advocacy, food and fund procurement, and disaster relief efforts through statewide collaboration. In some states, the State Association of food banks is the designated entity to receive the state appropriation for hunger relief efforts and may coordinate and manage these efforts on behalf of the members and/or act as the fiscal agent for the state funds."
      },
      
      {
          "Term:": "State Childrens Health Insurance Program (SCHIP)",
          "Definition:": "The State medical assistance program under Title XXI of the Social Security Act."
      },
      {
          "Term:": "SCHIP",
          "Definition:": "State Childrens Health Insurance Program. The State medical assistance program under Title XXI of the Social Security Act."
      },
      {
          "Term:": "State Fiscal Year (SFY)",
          "Definition:": "The State Fiscal Year (SFY) is the start and end of the state’s budget cycle. For 46 states, the SFY is July 1-June 30 (Alabama’s and Michigan’s SFY is October 1-September 30, New York’s SFY is April 1-March 31, and Texas’s SFY is September 1-August 31). The Federal Fiscal Year (FFY) is October 1- September 30."
      },
      {
          "Term:": "SFY",
          "Definition:": "The State Fiscal Year (SFY) is the start and end of the state’s budget cycle. For 46 states, the SFY is July 1-June 30 (Alabama’s and Michigan’s SFY is October 1-September 30, New York’s SFY is April 1-March 31, and Texas’s SFY is September 1-August 31). The Federal Fiscal Year (FFY) is October 1- September 30."
      },
      {
          "Term:": "State Food Purchase Program",
          "Definition:": "State appropriations designated for food purchase. Typically, state food purchase program dollars are restricted to purchasing only food—food grown, produced, and processed in-state. Some states allow more flexibility with state food purchase program dollars in order for those funds to be used for support functions around food purchase (for example, storage and distribution of the food purchased with state funds or capacity building)."
      },
      
      {
          "Term:": "State Report",
          "Definition:": "A Hunger Study state-level report that reflects the results of all members serving each county within a state.  This report is only possible if ALL members that serve the state participate in the Hunger Study.  The state report is an exact replica of the national report except that it is a state- level analysis of all members whose service area is within that state."
      },
      {
          "Term:": "Statute or Contract Language",
          "Definition:": "A statute is a written law enacted by a legislature. A contract is a binding legal agreement that is enforceable in a court of law. Public policies and appropriations are enacted by statute, but may be administered by a public agency (or department) through contractual relationships with private or public entities that agree to operate a program under contract with respect to the intent of the law."
      },
      //////Stewardship
      {
          "Term:": "Stewardship",
          "Definition:": "Gift acknowledgement and continuing management of the relationship between a donor and Feeding America. Specific requirements for stewardship may be outlined in a gift agreement and may include regular reporting about the use of funds. For donors who do not have specific reporting requirements, relationship managers may look for other opportunities to engage the donor on the impact of their donation, or (From the Relationship Management Handbook) Step five in the relationship management cycle:  acknowledging a donor for their support, and providing updates on the impact of their gift and assessing their interests in additional ongoing support in the Feeding America network."
      },
      
      {
          "Term:": "Stock Recovery",
          "Definition:": "The food bank’s removal or correction of a recalled product that has not been distributed or is still under the control of the food bank.   See Recall."
      },
      {
          "Term:": "Stocks for Food Initiative",
          "Definition:": "The U.S. Department of Agriculture (USDA) barters surplus raw commodity stocks in exchange for food products, to supplement its domestic and international food assistance under the July 2007 Stocks-for-Food initiative. USDA’s Commodity Credit Corporation acquires the commodities when producers choose to forfeit the stocks, rather than repay the government for their marketing assistance loans. The bartered foods for domestic programs are distributed through The Emergency Food Assistance Program (TEFAP) and the Commodity Supplemental Food Program (CSFP).  States distribute these products to thousands of local agencies including food banks, food pantries, and soup kitchens.  http://www.usda.gov/wps/portal/usda/usdahome"
      },

      {
          "Term:": "Storage and Distribution Appropriations",
          "Definition:": "State appropriations used to offset food banks’ costs for storing and distributing food to member agencies and mobile food pantries. Funds may be targeted towards distributing emergency food in rural and underserved areas."
      },
      {
          "Term:": "Store Donation Program (SDP)",
          "Definition:": "The recovery of food products primarily from meat, deli, dairy, bakery and produce sections of grocery stories by food banks and/or their agencies. Also known as retail store donation program or retail pick up."
      },
      {
          "Term:": "SDP",
          "Definition:": "Store Donation Program. The recovery of food products primarily from meat, deli, dairy, bakery and produce sections of grocery stories by food banks and/or their agencies. Also known as retail store donation program or retail pick up."
      },
      {
          "Term:": "Straight Truck",
          "Definition:": "A truck that does not swivel between the cab and trailer, as opposed to a tractor-trailer."
      },
      {
          "Term:": "Strategy Worksheet",
          "Definition:": "Detailed outline of the overall relationship management plan for a particular prospect detailing next steps, relationship management team members, timeline for solicitation and target ask amount."
      },
      {
          "Term:": "Subject Matter Experts",
          "Definition:": "Network members, national office staff, consultants, and vendors that have the information and knowledge about key business processes and areas.  These individuals understand a business process or area well enough to answer questions and provide guidance."
      },
      {
          "Term:": "SME",
          "Definition:": "Subject Matter Experts. Network members, national office staff, consultants, and vendors that have the information and knowledge about key business processes and areas.  These individuals understand a business process or area well enough to answer questions and provide guidance."
      },
      {
          "Term:": "Subsidiary Distribution Organization",
          "Definition:": "A nonprofit organization that acts as a local intermediary for a member, serving agencies in part of a member’s service area."
      },
      {
          "Term:": "SDO",
          "Definition:": "Subsidiary Distribution Organization. A nonprofit organization that acts as a local intermediary for a member, serving agencies in part of a member’s service area."
      },
      {
          "Term:": "Summer Food Service Program",
          "Definition:": "Summer Food Service Programs are those that serve meals and snacks to children in the summer months or during school breaks when school is not in session (in California, snacks are served year round, and in areas with year round school, meals can be served between sessions).  If the food bank operates a Summer Program, the national office should have a signed program agreement on file."
      },
      {
          "Term:": "SFSP",
          "Definition:": "Summer Food Service Programs are those that serve meals and snacks to children in the summer months or during school breaks when school is not in session (in California, snacks are served year round, and in areas with year round school, meals can be served between sessions).  If the food bank operates a Summer Program, the national office should have a signed program agreement on file."
      },
      {
          "term:": "Sponsor:",
          "Definition:": "Holds a contract with a state agency to administer the Summer Food Service Program.  Sponsors are reimbursed for meals served through the program.  A sponsor may also be providing the food for a program, so it can be both a sponsor and a vendor."
      },
      
      {
          "term:": "Vendor:",
          "Definition:": "Provides meals or meal components to a Summer Food Service Program sponsor.  A sponsor may also be providing the food for a program, so it can be both a sponsor and a vendor."
      },
     
      {
          "Term:": "Supplements for Federal Nutrition and Hunger Relief Programs",
          "Definition:": "State appropriations used to either offset the costs of administering federal nutrition and hunger relief programs, such as distributing food commodities allocated under The Emergency Food Assistance Program (TEFAP) across the state, or to enhance reimbursement for food items distributed under federally supported nutrition programs. Additionally, states may appropriate funds that trigger a federal reimbursement or match through a federal program that requires a state Maintenance of Effort (MOE) as part of the state’s eligibility to participate in the program."
      },
      {
          "Term:": "Supplemental Nutrition Assistance Program",
          "Definition:": "This program helps low-income people and families buy the food they  need for good health. Clients apply for benefits by completing a state application form. Benefits are provided on an Electronic Benefits Card (EBT) that is used like an ATM card and accepted at most grocery stores.  In some states, SNAP is still called by the name “Food Stamps http://www.fns.usda.gov/snap/.”"
      },
      
      {
          "Term:": "SNAPO",
          "Definition:": "Supplemental Nutrition Assistance Program Outreach; SNAP outreach"
      },
      {
          "Term:": "Supplemental Security Income",
          "Definition:": "Federal cash assistance program for the disabled and elderly poor people, administered by the Social Security Administration. http://www.socialsecurity.gov/ssi/index.htm"
      },
      {
          "Term:": "SSI",
          "Definition:": "Supplemental Security Income. Federal cash assistance program for the disabled and elderly poor people, administered by the Social Security Administration. http://www.socialsecurity.gov/ssi/index.htm"
      },
      {
          "Term:": "Support Letters",
          "Definition:": "Letters of support submitted to a decision-making or influential body from the food bank, agency partners or board members to indicate support for an idea, proposal, or legislative action. Templates, form letters, and letter writing guides are useful tools for agencies to use when writing a letter of support."
      },
      {
          "Term:": "Swell Allowance",
          "Definition:": "A form of reconciliation or an allowance.  Manufacturers pay retailers for their unsaleable products.  This allowance is given when the product is purchased from the manufacturer to cover potential future damages."
      },
      {
          "Term:": "Swells",
          "Definition:": "Processed foods packed in aluminum or glass, rendered unsaleable by swelling of the container or lid due to age, faulty processing or sealing, and/or storage conditions."
      },
     
      {
          "Term:": "Talking Points",
          "Definition:": "Talking points are summaries of key points and information that provide a speaker with an effective and efficient way of communicating with an audience on a particular topic."
      },
      {
          "Term:": "Tangible Property",
          "Definition:": "Includes movable objects (i.e., jewelry, artwork, antiques, clothing, etc.)."
      },
      {
          "Term:": "Tare Weight",
          "Definition:": "The weight of the packaging or container.  Tare weight plus net weight equals gross weight."
      },
      {
          "Term:": "Taste of the Nation",
          "Definition:": "Annual fundraising reception and dinner held in many communities across the United States, under the auspices of Share Our Strength, to raise funds for anti-hunger efforts. Some members receive Taste of the Nation funds."
      },
      {
          "Term:": "Taste of the NFL",
          "Definition:": "A party with a purpose and designed to raise funds for hunger-relief organizations in Super Bowl cities."
      },
      {
          "Term:": "Tax Incentive",
          "Definition:": "Tax incentives can be structured in a variety of ways, and are often geared towards tax credits or deductions for donated food items to nonprofit charitable hunger relief organizations, or specifically to a food bank or food pantry. However, tax incentives may also be designated towards charitable acts like transporting donated food. Another form of tax incentive is the inclusion of a “check-off” on state income tax forms that allows taxpayers to voluntarily donate a portion of their tax returns towards hunger relief activities and/or the food bank."
      },
      {
          "Term:": "Team Nutrition",
          "Definition:": "A program of the Food and Nutrition Service (FNS) at the U.S. Department of Agriculture (USDA) that provides schools with nutrition education materials for children and families; technical assistance materials for school food service directors, managers, and staff; and materials to build school and community support for healthy eating and physical activity. State agency partners provide training and technical assistance to support these programs in local schools.  http://www.fns.usda.gov/fns/"
      },
      
      
      {
          "Term:": "Technical Advisory Group",
          "Definition:": "An independent review team comprised of noted social scientists, including demographers, academics, and statisticians, that will oversee all aspects of the study.  The TAG will review everything from the survey instruments to the analysis plan to the final results.  In addition, TAG members will provide technical assistance to food banks during the report review process."
      },
      {
          "Term:": "TAG",
          "Definition:": "Technical Advisory Group. An independent review team comprised of noted social scientists, including demographers, academics, and statisticians, that will oversee all aspects of the study.  The TAG will review everything from the survey instruments to the analysis plan to the final results.  In addition, TAG members will provide technical assistance to food banks during the report review process."
      },
      {
          "Term:": "TGB",
          "Definition:": "Technology Governance Board"
      },
      {
          "Term:": "Temperature Control for Safety Foods",
          "Definition:": "A class of foods that needs to be stored outside of the temperature danger zone (41 – 135° F), in order to remain safe.  This class of food includes milk and dairy products, meat, poultry, eggs, fish and shellfish.  Refer to ServSafe training materials for a complete list of TCS foods."
      },
      {
          "Term:": "TCS",
          "Definition:": "Temperature Control for Safety (TCS) Foods. A class of foods that needs to be stored outside of the temperature danger zone (41 – 135° F), in order to remain safe.  This class of food includes milk and dairy products, meat, poultry, eggs, fish and shellfish.  Refer to ServSafe training materials for a complete list of TCS foods."
      },
      {
          "Term:": "Temporarily Restricted Net Assets",
          "Definition:": "(As defined by the CFO best practices team on Operating Reserves) Assets whose use has been limited by donor-imposed time or purpose restrictions.  The assets are accounted for and expended per the donor’s restrictions. An example is a donation received to specifically support food stamp outreach efforts or to specifically buy fresh produce. The net assets are not available for general use and are excluded from the reserve calculations except in limited situations. Temporarily-restricted net assets may be added to unrestricted net assets to the extent they will be released from restriction in the next twelve months and used for operating expenses."
      },
      
      {
          "Term:": "Temporary Assistance Pool",
          "Definition:": "Monthly awards to members, upon completing forms, for Choice System shares and/or transportation dollars to provide assistance to members facing food supply and transportation challenges."
      },
      {
          "Term:": "TAP",
          "Definition:": "Temporary Assistance Pool. Monthly awards to members, upon completing forms, for Choice System shares and/or transportation dollars to provide assistance to members facing food supply and transportation challenges."
      },
      {
          "Term:": "Temporary Assistance to Needy Families",
          "Definition:": "Federal block grant that replaced Aid to Families with Dependent Children (AFDC) in 1996.  TANF provides short-term, transitional assistance to needy families with the goal of promoting work and moving families to self- sufficiency.  http://www.acf.hhs.gov/index.html"
      },
      {
          "Term:": "TANF",
          "Definition:": "Temporary Assistance to Needy Families. Federal block grant that replaced Aid to Families with Dependent Children (AFDC) in 1996.  TANF provides short-term, transitional assistance to needy families with the goal of promoting work and moving families to self- sufficiency.  http://www.acf.hhs.gov/index.html"
      },
      {
          "Term:": "Tertiary Market",
          "Definition:": "A discount market for surplus and distressed goods used as an alternative to donating those products.  Products typically originate from reclamation centers and do not include refrigerated or frozen items."
      },
      {
          "Term:": "Banana Box Market",
          "Definition:": "A discount market for surplus and distressed goods used as an alternative to donating those products.  Products typically originate from reclamation centers and do not include refrigerated or frozen items."
      },
      {
          "Term:": "Testimony",
          "Definition:": "Testimony is a person’s account of an event or a state of affairs. Testimony can be either written or verbal and can be given in support or opposition on an issue, or it may be non-partial as information only."
      },
      {
          "Term:": "The Emergency Food Assistance Program ",
          "Definition:": "A program of the Food and Nutrition Service (FNS) at the U.S. Department of Agriculture (USDA) that provides food commodities at no cost to low- income Americans in need of short-term hunger relief.  TEFAP serves the agricultural community by distributing surplus commodities purchased by the USDA from farmers and other producers.  The majority of network food banks distribute TEFAP commodities. http://www.fns.usda.gov/fdd/programs/tefap/"
      },
      {
          "Term:": "TEFAP",
          "Definition:": "The Emergency Food Assistance Program. A program of the Food and Nutrition Service (FNS) at the U.S. Department of Agriculture (USDA) that provides food commodities at no cost to low- income Americans in need of short-term hunger relief.  TEFAP serves the agricultural community by distributing surplus commodities purchased by the USDA from farmers and other producers.  The majority of network food banks distribute TEFAP commodities. http://www.fns.usda.gov/fdd/programs/tefap/"
      },
      {
          "Term:": "Third Party Logistics",
          "Definition:": "The providing of logistics services of certain supply chain and warehouse functions by a company that is not the owner of the goods. Third Party logistics activities can be limited to one function such as warehousing or transportation or can involve many activities provided by one provider."
      },
      {
          "Term:": "3PL",
          "Definition:": "Third Party Logistics. The providing of logistics services of certain supply chain and warehouse functions by a company that is not the owner of the goods. Third Party logistics activities can be limited to one function such as warehousing or transportation or can involve many activities provided by one provider."
      },
      {
          "Term:": "Third Party Warehouse",
          "Definition:": "The providing of logistics services of certain supply chain and warehouse functions by a company that is not the owner of the goods. Third Party logistics activities can be limited to one function such as warehousing or transportation or can involve many activities provided by one provider."
      },
      {
          "Term:": "Thrifty Food Plan",
          "Definition:": "A food plan based upon a food quantity/selection that people of a specific age and gender could consume at home to maintain a healthful diet meeting current dietary standards.  The Thrifty Food Plan is the most economical of four food plans calculated by the U.S. Department of Agriculture (USDA) and is one factor used to determine the amount of a household’s food stamp benefit allotments. http://www.usda.gov/wps/portal/usda/usdahome"
      },
     
      {
          "Term:": "Ti Hi",
          "Definition:": "The stacking pattern of product making up a unit load.  Tie/Ti tells how many units (cases, bags, etc.) are on a layer, while High/Hi tells the number of layers.  For example, a 10x6 tie/high would be 10 cases per layer times 6 layers, or 60 cases."
      },
      {
          "Term:": "Tie High",
          "Definition:": "The stacking pattern of product making up a unit load.  Tie/Ti tells how many units (cases, bags, etc.) are on a layer, while High/Hi tells the number of layers.  For example, a 10x6 tie/high would be 10 cases per layer times 6 layers, or 60 cases."
      },
      {
          "Term:": "High and Tie",
          "Definition:": "The stacking pattern of product making up a unit load.  Tie/Ti tells how many units (cases, bags, etc.) are on a layer, while High/Hi tells the number of layers.  For example, a 10x6 tie/high would be 10 cases per layer times 6 layers, or 60 cases."
      },
      {
          "Term:": "Total residual chlorine",
          "Definition:": "The amount of chlorine in the water, which includes chlorine available and chlorine bound with organic materials."
      },{
          "Term:": "TRC",
          "Definition:": "Total residual chlorine. The amount of chlorine in the water, which includes chlorine available and chlorine bound with organic materials."
      },
      {
          "Term:": "Trace Procedure",
          "Definition:": "The process used to identify and isolate product at any point during the time period when the food bank controls the product."
      },
      {
          "Term:": "Traceability",
          "Definition:": "The identification of any suspect product and its initial shipment location."
      },
      {
          "Term:": "Tractor Trailer",
          "Definition:": "A variety of heavy automotive vehicles designed for transporting loads of product from one location to another.  Most vehicles can carry a load of 40,000 pounds or 22 pallets of product when the truck is full."
      },
      {
          "Term:": "Transportation Appropriations",
          "Definition:": "State appropriations for transportation may come in a variety of forms, such as reimbursement, subsidy, or allocations. Transportation appropriations can be: Designated for transporting food from the vendor, farm, fishery, etc. Designated for transporting food from the food bank to member agencies, or Used flexibly, as determined by the food bank"
      },
     
      {
          "Term:": "TSA",
          "Definition:": "Transitional Shelter Assistance"
      },
      {
          "Term:": "Truckload",
          "Definition:": "The term used for a shipment that weighs at least the minimum necessary for the application of the truckload rate."
      },
      {
          "Term:": "TL",
          "Definition:": "The term used for a shipment that weighs at least the minimum necessary for the application of the truckload rate."
      },
      {
          "Term:": "Trust",
          "Definition:": "An arrangement whereby property (including real, tangible and intangible) is held by an individual or institution for the benefit of others."
      },
      {
          "Term:": "Trustee",
          "Definition:": "The party legally responsible for carrying out the terms and performance of a trust."
      },
      {
          "Term:": "Turnover Rate",
          "Definition:": "The frequency with which total inventory or a specific class of inventory is completely replaced.  It is generally stated as the number of turns per year or per month."
      },
      {
          "Term:": "Umbrella Organization",
          "Definition:": "A 501(c)(3) organization with various programs that may include members. Examples of umbrella organizations may include: a Community Action Program, American Red Cross, Catholic Charities, or Lutheran Social Services."
      },
      {
          "Term:": "Unduplicated Clients",
          "Definition:": "The measurement of the number of different individuals who access the emergency food system of Feeding America at any time in a year or week.  That is, it is an estimate of the number of people ever served at least once in a typical week and the number served at least once in the past year.  Unduplicated counts are not comparable to meals served or client visits, as a client may be served more than once in a given week."
      },
      
      {
          "Term:": "USC",
          "Definition:": "United States Code"
      },
      {
          "Term:": "United States Department of Agriculture",
          "Definition:": "This federal agency is responsible for, among other things, ensuring the safety of meat, poultry, and egg products and administering federal nutrition programs including: The Supplemental Nutrition Assistance Program (SNAP), The National School Lunch Program (NSLP), The School Breakfast Program (SBP), The Emergency Food Assistance Program (TEFAP), The Commodity Supplemental Food Program (CSFP), The Special Supplemental Nutrition Program for Women, Infants and Children (WIC)."
      },
      {
          "Term:": "USDA",
          "Definition:": "United States Department of Agriculture. This federal agency is responsible for, among other things, ensuring the safety of meat, poultry, and egg products and administering federal nutrition programs including: The Supplemental Nutrition Assistance Program (SNAP), The National School Lunch Program (NSLP), The School Breakfast Program (SBP), The Emergency Food Assistance Program (TEFAP), The Commodity Supplemental Food Program (CSFP), The Special Supplemental Nutrition Program for Women, Infants and Children (WIC)."
      },
      {
          "Term:": "Department of Health and Human Services",
          "Definition:": "The federal agency responsible for administration of health and social service programs at the federal level.  HHS also administers the Elderly Nutrition Program and the Nutrition Services Incentive Program. http://www.hhs.gov/"
      },
      {
          "Term:": "HHS",
          "Definition:": "Department of Health and Human Services. The federal agency responsible for administration of health and social service programs at the federal level.  HHS also administers the Elderly Nutrition Program and the Nutrition Services Incentive Program. http://www.hhs.gov/"
      },
      {
          "Term:": "Universal Product Code",
          "Definition:": "A unique 12 digit bar code that identifies every item produced by a manufacturer for use in a retail environment.  See Scanner."
      },
      {
          "Term:": "UPC",
          "Definition:": "Universal Product Code. A unique 12 digit bar code that identifies every item produced by a manufacturer for use in a retail environment.  See Scanner."
      },
      {
          "Term:": "Universal School Breakfast",
          "Definition:": "School breakfast programs which provide breakfast at no cost to all students."
      },
      {
          "Term:": "Unrestricted Gift",
          "Definition:": "A gift for which a donor has not specified the conditions or purpose. Feeding America (the national office?) has full variance power over the use and distribution of transferred assets and may designate the funds for any purpose in support of the mission of the organization."
      },
      {
          "Term:": "Unrestricted Net Assets",
          "Definition:": "Assets that have not been restricted by the donor or by law.  Unrestricted net assets can be designated for a specific purpose by the Board or remain undesignated."
      },
      {
          "Term:": "Unsaleable",
          "Definition:": "Product that cannot be sold through the primary retail channels or other primary customers.  There are downstream (damaged at the plant or warehouse level) unsaleables and upstream (damages from a reclamation center) unsaleables.  Unsaleables can be sold to secondary or tertiary markets, donated, dumped, or held for company inspection and possible return."
      },
      
      {
          "Term:": "Value Added Processing",
          "Definition:": "The processing of raw donated goods by Feeding America, manufacturers, or members, for later distribution to agencies."
      },
      {
          "Term:": "VAP",
          "Definition:": "Value Added Processing. The processing of raw donated goods by Feeding America, manufacturers, or members, for later distribution to agencies. For example, the labor and materials involved in repackaging bulk beans into smaller bags would be value added processing.  Feeding America has and continues to develop rules on the handling and distribution of VAP goods.  Manufacturers may donate the raw product, but they frequently need to recoup the packaging costs."
      },
      
      {
          "Term:": "Variable Income",
          "Definition:": "Payments received on a regular basis that are subject to change (not fixed)."
      },
      {
          "Term:": "Variance Power",
          "Definition:": "Variance Power: As noted by KPMG (Feeding America’s independent auditor) on September 17, 2009; FAS 136 (paragraph 12) contains the key guidance for when a recipient organization recognizes contribution revenue versus recognizing a liability in an agency capacity (i.e., pass- through).  In order for a recipient organization to recognize revenue, the donor must explicitly grant the recipient organization variance power over the use and distribution of transferred assets.  FAS 136 defines variance power as the unilateral power to redirect the use of transferred assets to another beneficiary.  FAS 136 provides further clarification that “unilateral power means that the recipient organizations can override the donor’s instructions without approval from the donor, specified beneficiary, or other interested party.”  If the donor has a right to review and approve (or veto) Feeding America’s determination of who gets the funds, then Feeding America cannot demonstrate it has unilateral power as defined above.  Furthermore, please note that the standard requires the donor to give explicit variance rights in order to demonstrate variance power.  In other words, Feeding America has a positive “burden of proof” to demonstrate it has, in fact, been granted such explicit power.  If the donor agreements are silent on this point, Feeding America would not be able to positively demonstrate that it does have explicit variance power. The accounting standard sets the bar high for revenue recognition, ergo the rules that explicit rights exist.  The existence of implicit rights demonstrated by historical practice, verbal representations, and other informal understandings are not sufficient bases upon which to assert that explicit rights exist  (approved 10/26/09)."
      },
      
      {
          "Term:": "Vegetables",
          "Definition:": "(Choice System/Quarterly Poundage Report) Product type code for Canned and Frozen Vegetables."
      },
      {
          "Term:": "Vended Sponsor",
          "Definition:": "A sponsor that purchases from a food service management company the unitized meals, with or without milk, which it will serve at its site(s), or a sponsor that purchases management services from a food service management company.  See Summer Food Service Program (SFSP), Sponsor.  http://www.fns.usda.gov/cnd/summer/"
      },
      
      {
          "Term:": "Vendor",
          "Definition:": "Provides meals or meal components to a Summer Food Service Program sponsor.  See Summer Food Service Program (SFSP); Sponsor. http://www.fns.usda.gov/cnd/summer/"
      },
      {
          "Term:": "Very Low Food Security",
          "Definition:": "Food insecurity in the household reached levels of severity great enough that one or more household members were hungry at least some time during the year because they could not afford enough food."
      },
      {
          "Term:": "Food Insecurity with Hunger",
          "Definition:": "Food insecurity in the household reached levels of severity great enough that one or more household members were hungry at least some time during the year because they could not afford enough food."
      },
      {
          "Term:": "Voluntary Organizations Active in Disasters (VOAD)",
          "Definition:": "Similar in scope and practice to the National Volunteer Organizations Active in Disaster (NVOAD), but functions at the state, county or local level. See National Volunteer Organizations Active in Disasters (NVOAD)."
      },
      {
          "Term:": "Volunteers in Service to America",
          "Definition:": "Federal volunteer program similar to the Peace Corps, however the volunteers work in the United States."
      },
      {
          "Term:": "VISTA",
          "Definition:": "Volunteers in Service to America. Federal volunteer program similar to the Peace Corps, however the volunteers work in the United States."
      },
      {
          "Term:": "White Mail",
          "Definition:": "Unsolicited gifts received by Feeding America."
      },
      {
          "Term:": "Wholesale Grocer",
          "Definition:": "A person who buys merchandise for resale to retailers and other merchants, and/or to industrial, institutional, and commercial users."
      },
      {
          "Term:": "Wholesaler",
          "Definition:": "A merchant middleman who sells chiefly to retailers on behalf of a manufacturer."
      },
      {
          "Term:": "Will",
          "Definition:": "A legal instrument disposing of a person’s property at the time of his or her death."
      },
      {
          "Term:": "Withdrawal",
          "Definition:": "A food bank’s removal or correction of a distributed product that involves a minor violation and would not warrant legal action by the regulatory authority."
      },
      {
          "Term:": "Working Capital",
          "Definition:": "Liquid assets of the organization primarily used to fund planned or normal operations.  It also refers to the cash available for day-to-day operations and is calculated as current assets minus current liabilities."
      },
      {
          "Term:": "Yellow Receipt",
          "Definition:": "The receipt that members fill out and submit to Feeding America to track nationally coordinated donations that are allocated through the Choice System or by direct offer.  Also known as a national receipt."
      },
      {
          "Term:": "YMCA",
          "Definition:": "Young Men’s Christian Association"
      },
      {
          "Term:": "YWCA",
          "Definition:": "Young Women’s Christian Association"
      },
      {
          "Term:": "Yogurt",
          "Definition:": "Commercially prepared coagulated milk products obtained by the fermentation of specific bacteria, that meet milk fat or milk solid requirements and to which flavoring foods or ingredients may be added. These products are covered by the Food and Drug Administration’s Standard of Identity for yogurt, low-fat yogurt, and nonfat yogurt, respectively."
      },
      
      
      {
          "Term:": "ABAWDs",
          "Definition:": "Able-Bodied Adults Without Dependents"
      },
      {
          "Term:": "ACPN",
          "Definition:": "Agency Capacity, Programs and Nutrition Conference"
      },
      {
          "Term:": "AHPC",
          "Definition:": "Anti-Hunger Policy Conference"
      },
      {
          "Term:": "AMI",
          "Definition:": "American Meat Institute"
      },
      {
          "Term:": "APHIS",
          "Definition:": "Animal and Plant Health Inspection Service"
      },
      {
          "Term:": "APHSA",
          "Definition:": "American Public Human Services Association"
      },
      {
          "Term:": "APR",
          "Definition:": "Annual Poundage Report"
      },
      {
          "Term:": "ARC",
          "Definition:": "American Red Cross"
      },
      {
          "Term:": "BL",
          "Definition:": "Bill of Lading"
      },
      {
          "Term:": "BOL",
          "Definition:": "Bill of Lading"
      },
      {
          "Term:": "CACFP",
          "Definition:": "Child and Adult Care Food Program"
      },
      {
          "Term:": "CBO",
          "Definition:": "Community-Based Organization"
      },
      {
          "Term:": "CBPP",
          "Definition:": "Center on Budget and Policy Priorities"
      },
      {
          "Term:": "CDC",
          "Definition:": "Centers for Disease Control and Prevention"
      },
      {
          "Term:": "CFNP",
          "Definition:": "Community Food and Nutrition Program"
      },
      {
          "Term:": "CFR",
          "Definition:": "Code of Federal Regulations or Certified in Food Resources"
      },
      {
          "Term:": "CGA",
          "Definition:": "Charitable Gift Annuity"
      },
      {
          "Term:": "CIT",
          "Definition:": "Corporate Inspection Team"
      },
      {
          "Term:": "CLT",
          "Definition:": "Charitable Lead Trust"
      },
      {
          "Term:": "CoP",
          "Definition:": "Communities of Practice"
      },
      {
          "Term:": "COV",
          "Definition:": "Council On Volunteerism"
      },
      {
          "Term:": "CPG",
          "Definition:": "Consumer Packaged Goods"
      },
      {
          "Term:": "CRAP",
          "Definition:": "Central Region All-Star Players"
      },
      {
          "Term:": "CRC",
          "Definition:": "Campaign Resource Center"
      },
      {
          "Term:": "CRM",
          "Definition:": "Constituent Relationship Management"
      },
     
      
      {
          "Term:": "DC",
          "Definition:": "Distribution Center"
      },
      {
          "Term:": "DEA",
          "Definition:": "Drug Enforcement Administration"
      },
      {
          "Term:": "DRS",
          "Definition:": "Damage Recovery System"
      },
     
      {
          "Term:": "DSD",
          "Definition:": "Direct Store Delivery"
      },
      {
          "Term:": "D SNAP",
          "Definition:": "Disaster Supplemental Nutrition Assistance Program"
      },
      {
          "Term:": "EBT",
          "Definition:": "Electronic Benefits Transfer"
      },
      {
          "Term:": "EFNEP",
          "Definition:": "Expanded Food and Nutrition Education Program A nutrition education program administered through the Cooperative State Research, Education, and Extension agency (CSREES) at the U.S. Department of Agriculture (USDA), which provides low-income individuals with the knowledge and skills to improve their nutritional well-being on a limited budget.   http://www.usda.gov/wps/portal/usda/usdahome"
      },
      {
          "Term:": "EFSP",
          "Definition:": "Emergency Food and Shelter Program"
      },
      {
          "Term:": "EIN",
          "Definition:": "(Federal) Employer Identification Number"
      },
      {
          "Term:": "EITC",
          "Definition:": "Earned Income Tax Credit"
      },
      
      {
          "Term:": "ERP",
          "Definition:": "Enterprise Resource Planning"
      },
      {
          "Term:": "ERS",
          "Definition:": "Economic Research Service"
      },
     
      {
          "Term:": "ETA",
          "Definition:": "Estimated Time of Arrival"
      },
      {
          "Term:": "FB",
          "Definition:": "Freight Bill"
      },
      {
          "Term:": "FA",
          "Definition:": "Feeding America"
      },
      {
          "Term:": "FANS",
          "Definition:": "Feeding America Network Summit"
      },
      {
          "Term:": "FAU",
          "Definition:": "Feeding America University"
      },
      {
          "Term:": "FB",
          "Definition:": "Food Bank"
      },
      {
          "Term:": "FBO",
          "Definition:": "Faith-Based Organization"
      },
     
      {
          "Term:": "FDPIR",
          "Definition:": "Food Distribution Program on Indian Reservations"
      },
     
      {
          "Term:": "FFY",
          "Definition:": "Federal Fiscal Year"
      },
      {
          "Term:": "FIFO",
          "Definition:": "First In First Out"
      },
      {
          "Term:": "FIN",
          "Definition:": "Federal Employer Identification Number"
      },
      {
          "Term:": "FMCE",
          "Definition:": "Food Manufacturing Channel Expansion"
      },
      {
          "Term:": "FMI",
          "Definition:": "Food Marketing Institute"
      },
      {
          "Term:": "FMNV",
          "Definition:": "Foods of Minimal Nutritional Value"
      },
      {
          "Term:": "FMV",
          "Definition:": "Fair Market Value"
      },
      {
          "Term:": "FNS",
          "Definition:": "Food and Nutrition Service"
      },
      {
          "Term:": "FNSRO",
          "Definition:": "Food and Nutrition Service Regional Office"
      },
     
      {
          "Term:": "FOB",
          "Definition:": "Free on Board or Freight on Board"
      },
      {
          "Term:": "FPL",
          "Definition:": "Federal Poverty Level"
      },
      {
          "Term:": "FRAC",
          "Definition:": "Food Research and Action Center"
      },
      {
          "Term:": "FRO",
          "Definition:": "Food Rescue Organization"
      },
      {
          "Term:": "FSC",
          "Definition:": "Food Safety Council or Food Sharing Cooperative"
      },
      {
          "Term:": "FSMC",
          "Definition:": "Food Service Management Company"
      },
      {
          "Term:": "FSNE",
          "Definition:": "Food Stamp Nutrition Education"
      },
      {
          "Term:": "FSOP",
          "Definition:": "Food Sourcing and Operations Conference"
      },
      {
          "Term:": "FTHR",
          "Definition:": "Finance, Technology and Human Resources Conference"
      },
      {
          "Term:": "GA",
          "Definition:": "General Assistance"
      },
      {
          "Term:": "GF",
          "Definition:": "Goal Factor"
      },
      {
          "Term:": "GIK",
          "Definition:": "Gifts in Kind"
      },
      {
          "Term:": "GIS",
          "Definition:": "Geographic Information Systems"
      },
      {
          "Term:": "GMA",
          "Definition:": "Grocery Manufacturers Association"
      },
      {
          "Term:": "GMP",
          "Definition:": "Good Manufacturing Practices"
      },
      {
          "Term:": "GPO",
          "Definition:": "United States Government Printing Office"
      },
      {
          "Term:": "GRAS",
          "Definition:": "Generally Recognized as Safe"
      },
      {
          "Term:": "GSA",
          "Definition:": "General Service Administration"
      },
      {
          "Term:": "HACCP",
          "Definition:": "Hazard Analysis and Critical Control Point"
      },
      {
          "Term:": "HHS",
          "Definition:": "United States Department of Health and Human Services"
      },
      {
          "Term:": "HAM",
          "Definition:": "Hunger Action Month"
      },
      {
          "Term:": "HVAC",
          "Definition:": "Heating, Ventilation, and Air Conditioning"
      },
      {
          "Term:": "IA",
          "Definition:": "Individual Assistance"
      },
      {
          "Term:": "IFB",
          "Definition:": "Invitation for Bid"
      },
      {
          "Term:": "ILI",
          "Definition:": "Influenza-Like Illness"
      },
      {
          "Term:": "IPM",
          "Definition:": "Integrated Pest Control Management"
      },
      {
          "Term:": "IQF",
          "Definition:": "Individually Quick Frozen"
      },
      {
          "Term:": "IT",
          "Definition:": "Information Technology"
      },
      {
          "Term:": "JFO",
          "Definition:": "Joint Field Office"
      },
      {
          "Term:": "JIT",
          "Definition:": "Just In Time"
      },
      {
          "Term:": "LMS",
          "Definition:": "Learning Management System"
      },
      
      {
          "Term:": "LTL",
          "Definition:": "Less than Truckload"
      },
      {
          "Term:": "MAC",
          "Definition:": "Member Advisory Committee"
      },
      {
          "Term:": "MCEA",
          "Definition:": "Mass Care/Emergency Assistance"
      },
      {
          "Term:": "MCS",
          "Definition:": "Master Cleaning Schedule"
      },
      {
          "Term:": "MMG",
          "Definition:": "Map the Map Gap"
      },
      {
          "Term:": "MOE",
          "Definition:": "Maintenance of Effort"
      },
      {
          "Term:": "MOU",
          "Definition:": "Memorandum of Understanding"
      },
      {
          "Term:": "MPR",
          "Definition:": "Monthly Poundage Report"
      },
      {
          "Term:": "MSDS",
          "Definition:": "Material Safety Data Sheets"
      },
      {
          "Term:": "MTP",
          "Definition:": "Mobilizing the Public Conference"
      },
      {
          "Term:": "NAC",
          "Definition:": "National Council"
      },
      {
          "Term:": "NAHO",
          "Definition:": "National Anti-Hunger Organizations"
      },
      {
          "Term:": "NAR",
          "Definition:": "Network Activity Report"
      },
      {
          "Term:": "NAV",
          "Definition:": "Navision"
      },
      {
          "Term:": "NCMEC",
          "Definition:": "National Center for Missing and Exploited Children"
      },
      {
          "Term:": "NECLC",
          "Definition:": "National Emergency Child Locator Center"
      },
      {
          "Term:": "NEFRLS",
          "Definition:": "National Emergency Family Registry and Locator System"
      },
      {
          "Term:": "NEMIS",
          "Definition:": "National Emergency Management Information System"
      },
      {
          "Term:": "NFPA",
          "Definition:": "National Fire Protection Association"
      },
      {
          "Term:": "NGO",
          "Definition:": "Non-Government Organization"
      },
      {
          "Term:": "NPSC",
          "Definition:": "National Processing Service Center"
      },
      {
          "Term:": "NRF",
          "Definition:": "National Response Framework"
      },
      {
          "Term:": "NSLP",
          "Definition:": "National School Lunch Program"
      },
      {
          "Term:": "NSS",
          "Definition:": "National Shelter System"
      },
      {
          "Term:": "NVOAD",
          "Definition:": "National Volunteer Organizations Active in Disaster"
      },
      {
          "Term:": "NYSP",
          "Definition:": "National Youth Sports Program"
      },
      {
          "Term:": "OSHA",
          "Definition:": "Occupational Safety and Health Act/Administration"
      },
      {
          "Term:": "OTC",
          "Definition:": "Over the Counter"
      },
      {
          "Term:": "OVS",
          "Definition:": "Offer Versus Serve"
      },
      {
          "Term:": "PCO",
          "Definition:": "Pest Control Operator"
      },
      {
          "Term:": "PDO",
          "Definition:": "Partner Distribution Organization"
      },
      
      {
          "Term:": "PEAC",
          "Definition:": "Policy Engagement Advocacy Committee"
      },
      {
          "Term:": "PIO",
          "Definition:": "Public Information Officer"
      },
      {
          "Term:": "POD",
          "Definition:": "Point of Distribution"
      },
      {
          "Term:": "POP",
          "Definition:": "Point of Purchase"
      },
      {
          "Term:": "POS",
          "Definition:": "Point of Sale"
      },
      {
          "Term:": "PPA",
          "Definition:": "Phenylpropanolamine"
      },
      {
          "Term:": "PPE",
          "Definition:": "Personnel Protective Equipment"
      },
      {
          "Term:": "PPIP",
          "Definition:": "Pounds per Person in Poverty"
      },
      {
          "Term:": "PSA",
          "Definition:": "Public Service Announcement or Partner State Association"
      },
     
      {
          "Term:": "QC",
          "Definition:": "Quality Control Program"
      },
      {
          "Term:": "QPR",
          "Definition:": "Quarterly Poundage Report"
      },
      {
          "Term:": "RCCI",
          "Definition:": "Residential Child Care Institution"
      },
      {
          "Term:": "RDC",
          "Definition:": "Regional Distribution Center"
      },
      {
          "Term:": "RDO",
          "Definition:": "Redistribution Organization"
      },
      {
          "Term:": "RFP",
          "Definition:": "Request for Proposal"
      },
      {
          "Term:": "ROI",
          "Definition:": "Return on Investment"
      },
      {
          "Term:": "SBA",
          "Definition:": "Small Business Administration"
      },
      {
          "Term:": "SBP",
          "Definition:": "School Breakfast Program"
      },
      {
          "Term:": "SCHIP",
          "Definition:": "State Children’s Health Insurance Program"
      },
      {
          "Term:": "SDO",
          "Definition:": "Subsidiary Distribution Organization"
      },
      {
          "Term:": "SDP",
          "Definition:": "Store Donation Program"
      },
      {
          "Term:": "SFSP",
          "Definition:": "Summer Food Service Program"
      },
      {
          "Term:": "SFY",
          "Definition:": "State Fiscal Year"
      },
      {
          "Term:": "SME",
          "Definition:": "Subject Matter Expert"
      },
      {
          "Term:": "SMF",
          "Definition:": "Shared Maintenance Fee"
      },
      {
          "Term:": "SMP",
          "Definition:": "Special Milk Program"
      },
      {
          "Term:": "SNAP",
          "Definition:": "Supplemental Nutrition Assistance Program"
      },
      {
          "Term:": "SNAPO",
          "Definition:": "Supplemental Nutrition Assistance Program Outreach; SNAP outreach"
      },
      {
          "Term:": "SOP",
          "Definition:": "Standard Operating Procedure"
      },
      {
          "Term:": "SSI",
          "Definition:": "Supplemental Security Income"
      },
     
      {
          "Term:": "TAG",
          "Definition:": "Technical Advisory Group"
      },
      {
          "Term:": "TANF",
          "Definition:": "Temporary Assistance to Needy Families"
      },
      {
          "Term:": "TAP",
          "Definition:": "Temporary Assistance Pool"
      },
      {
          "Term:": "TCS",
          "Definition:": "Temperature Control for Safety Foods"
      },
      {
          "Term:": "TEFAP",
          "Definition:": "The Emergency Food Assistance Program"
      },
      {
          "Term:": "TGB",
          "Definition:": "Technology Governance Board"
      },
      {
          "Term:": "TL",
          "Definition:": "Truckload"
      },
      {
          "Term:": "TRC",
          "Definition:": "Total Residual Chlorine"
      },
      {
          "Term:": "TSA",
          "Definition:": "Transitional Shelter Assistance"
      },
      {
          "Term:": "UPC",
          "Definition:": "Universal Product Code"
      },
      {
          "Term:": "USC",
          "Definition:": "United States Code"
      },
      {
          "Term:": "USDA",
          "Definition:": "United States Department of Agriculture"
      },
      {
          "Term:": "VAP",
          "Definition:": "Value Added Processing"
      },
      {
          "Term:": "VISTA",
          "Definition:": "Volunteers in Service to America"
      },
      {
          "Term:": "VOAD",
          "Definition:": "Voluntary Organizations Active in Disasters"
      },
      {
          "Term:": "WIC",
          "Definition:": "Special Supplemental Nutrition Program for Women Infants and Children"
      },
      {
          "Term:": "YMCA",
          "Definition:": "Young Men’s Christian Association"
      },
      {
          "Term:": "YWCA",
          "Definition:": "Young Women’s Christian Association"
      }
  ]
}





